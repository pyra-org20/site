import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.JWT_SECRET ??= 'x'.repeat(40);
process.env.DB_HOST ??= 'localhost'; process.env.DB_USER ??= 'u'; process.env.DB_NAME ??= 'd';
process.env.UPLOAD_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'up-'));
const { requireAuth, requirePermission } = await import('../src/middlewares/auth.js');
const { saveUpload } = await import('../src/middlewares/upload.js');
const { errorHandler } = await import('../src/middlewares/errors.js');
const { eventSchema } = await import('../src/validators/schemas.js');

const run = (mw, req) => new Promise((resolve) => mw(req, {}, (e) => resolve(e)));
const user = (perms = []) => ({ id: 1, csrf: 'a'.repeat(48), permissions: new Set(perms) });

test('sem login: 401', async () => assert.equal((await run(requireAuth, { method: 'GET' })).status, 401));
test('POST sem token CSRF: 403', async () => assert.equal((await run(requireAuth, { method: 'POST', user: user(), get: () => '' })).status, 403));
test('POST com token CSRF correto passa', async () => assert.equal(await run(requireAuth, { method: 'POST', user: user(), get: () => 'a'.repeat(48) }), undefined));
test('permissão ausente: 403', async () => assert.equal((await run(requirePermission('users.delete'), { user: user(['users.read']) })).status, 403));
test('permissão presente passa', async () => assert.equal(await run(requirePermission('users.read'), { user: user(['users.read']) }), undefined));

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32)]);
test('PNG válido é salvo com nome aleatório', async () => {
  const url = await saveUpload({ buffer: PNG, mimetype: 'image/png', originalname: 'foto.png' });
  assert.match(url, /^\/uploads\/[a-f0-9]{32}\.png$/);
});
test('script renomeado para .png é rejeitado', async () =>
  assert.rejects(saveUpload({ buffer: Buffer.from('<script>alert(1)</script>'.repeat(3)), mimetype: 'image/png', originalname: 'x.png' }), { status: 415 }));
test('MIME divergente do conteúdo é rejeitado', async () =>
  assert.rejects(saveUpload({ buffer: PNG, mimetype: 'image/jpeg', originalname: 'x.jpg' }), { status: 415 }));
test('SVG é rejeitado', async () =>
  assert.rejects(saveUpload({ buffer: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'), mimetype: 'image/svg+xml', originalname: 'x.svg' }), { status: 415 }));

test('erro de validação vira 422 com campos', () => {
  let out; const res = { status(c) { out = { c }; return this; }, json(b) { out.b = b; } };
  try { eventSchema.parse({ title: 'x' }); } catch (e) { errorHandler(e, {}, res, () => {}); }
  assert.equal(out.c, 422); assert.ok(out.b.fields.length > 0);
});
test('imagem de evento só aceita /uploads ou https', () => {
  assert.throws(() => eventSchema.parse({ title: 'Roda', event_date: '2026-12-01', cover_image_url: 'javascript:alert(1)' }));
  assert.ok(eventSchema.parse({ title: 'Roda', event_date: '2026-12-01', cover_image_url: '/uploads/' + 'a'.repeat(32) + '.jpg' }));
});

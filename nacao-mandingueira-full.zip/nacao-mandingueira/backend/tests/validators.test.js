import test from 'node:test';
import assert from 'node:assert/strict';
process.env.JWT_SECRET ??= 'x'.repeat(40);
const { eventSchema, registerSchema, contactSchema, pageSchema } = await import('../src/validators/schemas.js');
const { slugify } = await import('../src/utils/http.js');

test('slugify remove acentos', () => assert.equal(slugify('Batizado & Troca de Cordas 2026!'), 'batizado-troca-de-cordas-2026'));
test('evento exige data válida', () => assert.throws(() => eventSchema.parse({ title: 'Roda aberta', event_date: '13/11/2026' })));
test('evento válido e HTML removido', () => {
  const e = eventSchema.parse({ title: '<b>Roda</b> aberta', event_date: '2026-12-05', description: '' });
  assert.equal(e.title, 'Roda aberta'); assert.equal(e.description, null); assert.equal(e.is_published, false);
});
test('senha fraca é rejeitada', () => assert.throws(() => registerSchema.parse({ name: 'Ana', email: 'a@b.com', password: 'abc' })));
test('contato exige mensagem mínima', () => assert.throws(() => contactSchema.parse({ name: 'Ana', email: 'a@b.com', message: 'oi' })));
test('página remove script', () => {
  const p = pageSchema.parse({ title: 'Teste', content: '<p>ok</p><script>alert(1)</script><a href="javascript:x">l</a>' });
  assert.ok(!p.content.includes('script')); assert.ok(!p.content.includes('javascript'));
});

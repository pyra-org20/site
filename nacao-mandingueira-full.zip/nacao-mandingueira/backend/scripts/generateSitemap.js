// Gera frontend/sitemap.xml com a página inicial. Uso: npm run sitemap
import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const base = (process.env.FRONTEND_URL || '').replace(/\/$/, '');
if (!/^https:\/\//.test(base)) { console.error('Defina FRONTEND_URL com https:// para gerar o sitemap.'); process.exit(1); }
const out = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../frontend/sitemap.xml');
fs.writeFileSync(out, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${base}/</loc><changefreq>weekly</changefreq></url>\n</urlset>\n`);
console.log('Gerado:', out);

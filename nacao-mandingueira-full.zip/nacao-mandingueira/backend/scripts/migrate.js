import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';
const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../database');
const c = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT) || 3306, user: process.env.DB_USER,
  password: process.env.DB_PASSWORD, database: process.env.DB_NAME, multipleStatements: true, charset: 'utf8mb4',
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: true } : undefined });
for (const f of ['schema.sql', 'seeds.sql']) { await c.query(fs.readFileSync(path.join(dir, f), 'utf8')); console.log('Aplicado:', f); }
await c.end();

import 'dotenv/config';
import { createUser } from '../src/services/authService.js';
import { registerSchema } from '../src/validators/schemas.js';
import { db } from '../src/config/db.js';
const d = registerSchema.parse({ name: process.env.SUPERADMIN_NAME, email: process.env.SUPERADMIN_EMAIL, password: process.env.SUPERADMIN_PASSWORD });
const id = await createUser({ ...d, roleSlug: 'superadministrador' });
console.log(`Superadministrador criado (id ${id}). Apague SUPERADMIN_PASSWORD do .env.`);
await db.end();

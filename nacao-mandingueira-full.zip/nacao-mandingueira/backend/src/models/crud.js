import { db } from '../config/db.js';
// Colunas vêm do código (confiável); valores sempre parametrizados.
export function crudModel({ table, order = 'id DESC' }) {
  return {
    async list({ published = false, where = [], params = [], order: o = order } = {}) {
      const w = [...where]; if (published) w.push('is_published = 1');
      const [rows] = await db.query(`SELECT * FROM ?? ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY ${o} LIMIT 500`, [table, ...params]);
      return rows;
    },
    async find(key, { published = false } = {}) {
      const col = /^\d+$/.test(String(key)) ? 'id' : 'slug';
      const [[row]] = await db.query(`SELECT * FROM ?? WHERE ?? = ? ${published ? 'AND is_published = 1' : ''} LIMIT 1`, [table, col, key]);
      return row || null;
    },
    async create(data) { const [r] = await db.query('INSERT INTO ?? SET ?', [table, data]); return r.insertId; },
    async update(id, data) {
      if (!Object.keys(data).length) return 0;
      const [r] = await db.query('UPDATE ?? SET ? WHERE id = ?', [table, data, id]); return r.affectedRows;
    },
    async remove(id) { const [r] = await db.query('DELETE FROM ?? WHERE id = ?', [table, id]); return r.affectedRows; },
  };
}

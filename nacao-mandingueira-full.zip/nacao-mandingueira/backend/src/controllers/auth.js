import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../config/db.js';
import { env, googleEnabled } from '../config/env.js';
import { ah, AppError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { authLimiter } from '../middlewares/rateLimits.js';
import { issueSession, clearSession, requireAuth } from '../middlewares/auth.js';
import * as svc from '../services/authService.js';
import { registerSchema, loginSchema, forgotSchema, resetSchema, changePasswordSchema, profileSchema } from '../validators/schemas.js';

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, roles: u.roles, permissions: [...u.permissions] });
const r = Router();

r.post('/register', authLimiter, ah(async (req, res) => {
  const d = registerSchema.parse(req.body);
  const id = await svc.createUser(d);
  req.user = { id }; await audit(req, 'user.register', 'user', id);
  res.status(201).json({ message: 'Cadastro realizado. Faça login para entrar.' });
}));
r.post('/login', authLimiter, ah(async (req, res) => {
  const { email, password } = loginSchema.parse(req.body);
  const id = await svc.verifyLogin(email, password);
  const csrfToken = issueSession(res, id);
  req.user = { id }; await audit(req, 'user.login', 'user', id);
  res.json({ csrfToken });
}));
r.post('/logout', (_req, res) => { clearSession(res); res.status(204).end(); });
r.get('/me', ah(async (req, res) => {
  if (!req.user) return res.json({ user: null });
  res.json({ user: publicUser(req.user), csrfToken: req.user.csrf });
}));
r.post('/forgot-password', authLimiter, ah(async (req, res) => {
  await svc.requestReset(forgotSchema.parse(req.body).email);
  res.json({ message: 'Se o e-mail estiver cadastrado, enviaremos as instruções.' });
}));
r.post('/reset-password', authLimiter, ah(async (req, res) => {
  const { token, password } = resetSchema.parse(req.body);
  await svc.resetPassword(token, password);
  res.json({ message: 'Senha alterada. Faça login com a nova senha.' });
}));
r.post('/change-password', requireAuth, authLimiter, ah(async (req, res) => {
  const d = changePasswordSchema.parse(req.body);
  await svc.changePassword(req.user.id, d.currentPassword, d.newPassword);
  await audit(req, 'user.change_password', 'user', req.user.id);
  const csrfToken = issueSession(res, req.user.id); // mantém esta sessão; as demais são encerradas
  res.json({ message: 'Senha alterada. Outras sessões foram encerradas.', csrfToken });
}));
r.put('/profile', requireAuth, ah(async (req, res) => {
  const d = profileSchema.parse(req.body);
  await db.query('UPDATE users SET name = ?, phone = ? WHERE id = ?', [d.name, d.phone, req.user.id]);
  res.json({ message: 'Perfil atualizado.' });
}));

// ---- Google OAuth 2.0 (só existe se as credenciais estiverem configuradas) ----
const stateCookie = { httpOnly: true, secure: env.cookieSecure, sameSite: 'lax', maxAge: 10 * 60 * 1000, path: '/api/auth/google' };
r.get('/google', (req, res, next) => {
  if (!googleEnabled) return next(new AppError(404, 'Login com Google não está configurado.'));
  const state = crypto.randomBytes(16).toString('hex');
  res.cookie('g_state', state, stateCookie);
  const q = new URLSearchParams({ client_id: env.google.id, redirect_uri: env.google.redirect, response_type: 'code', scope: 'openid email profile', state });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${q}`);
});
r.get('/google/callback', ah(async (req, res) => {
  if (!googleEnabled) throw new AppError(404, 'Login com Google não está configurado.');
  if (!req.query.state || req.query.state !== req.cookies?.g_state || !req.query.code) throw new AppError(400, 'Falha na validação do login Google.');
  res.clearCookie('g_state', { path: '/api/auth/google' });
  const tok = await (await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ code: String(req.query.code), client_id: env.google.id, client_secret: env.google.secret, redirect_uri: env.google.redirect, grant_type: 'authorization_code' }) })).json();
  if (!tok.access_token) throw new AppError(400, 'Falha ao autenticar com o Google.');
  const info = await (await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tok.access_token}` } })).json();
  if (!info.email || info.email_verified !== true) throw new AppError(400, 'E-mail do Google não verificado.');
  const email = String(info.email).toLowerCase();
  let [[u]] = await db.query('SELECT id, status FROM users WHERE google_id = ? OR email = ? LIMIT 1', [info.sub, email]);
  if (!u) u = { id: await svc.createUser({ name: info.name || email, email, googleId: info.sub }), status: 'ativo' };
  else await db.query('UPDATE users SET google_id = COALESCE(google_id, ?), last_login_at = UTC_TIMESTAMP() WHERE id = ?', [info.sub, u.id]);
  if (u.status !== 'ativo') throw new AppError(403, 'Conta suspensa.');
  issueSession(res, u.id);
  res.redirect(env.frontendUrl || '/');
}));
export default r;

import { Router } from 'express';
import { db } from '../config/db.js';
import { requireAuth, requirePermission } from '../middlewares/auth.js';
import { contactLimiter } from '../middlewares/rateLimits.js';
import { receive, saveUpload, removeUpload } from '../middlewares/upload.js';
import { ah, AppError, sha256 } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { env } from '../config/env.js';
import { z } from 'zod';
import { scheduleSchema, eventImageSchema, galleryImageSchema, contactSchema, settingsSchema } from '../validators/schemas.js';

export const upload = Router();
upload.post('/', requireAuth, (req, res, next) => (req.user.permissions.has('events.write') || req.user.permissions.has('gallery.write')
  || req.user.permissions.has('teachers.write') || req.user.permissions.has('settings.write')) ? next() : next(new AppError(403, 'Sem permissão para enviar arquivos.')),
receive, ah(async (req, res) => {
  const url = await saveUpload(req.file);
  await audit(req, 'upload.create', 'upload', url);
  res.status(201).json({ url });
}));

// Imagens filhas (eventos, galeria) e horários
function childRoutes(r, { path, parentTable, table, schema, perm, urlCol, name }) {
  r.post(`/${path}/:id(\\d+)/images`, requireAuth, requirePermission(perm), ah(async (req, res) => {
    const d = schema.parse(req.body);
    const [[p]] = await db.query('SELECT id FROM ?? WHERE id = ?', [parentTable, req.params.id]);
    if (!p) throw new AppError(404, 'Registro não encontrado.');
    const [ins] = await db.query('INSERT INTO ?? SET ?', [table, { ...d, [name]: req.params.id, ...(table === 'gallery_images' && { uploaded_by: req.user.id }) }]);
    await audit(req, `${table}.create`, table, ins.insertId);
    res.status(201).json({ id: ins.insertId });
  }));
  r.put(`/${table}/:id(\\d+)`, requireAuth, requirePermission(perm), ah(async (req, res) => {
    const d = schema.partial().omit({ image_url: true }).parse(req.body);
    if (Object.keys(d).length) await db.query('UPDATE ?? SET ? WHERE id = ?', [table, d, req.params.id]);
    res.json({ message: 'Atualizado.' });
  }));
  r.delete(`/${table}/:id(\\d+)`, requireAuth, requirePermission(perm), ah(async (req, res) => {
    const [[row]] = await db.query('SELECT image_url FROM ?? WHERE id = ?', [table, req.params.id]);
    if (!row) throw new AppError(404, 'Imagem não encontrada.');
    await db.query('DELETE FROM ?? WHERE id = ?', [table, req.params.id]);
    await removeUpload(row.image_url);
    await audit(req, `${table}.delete`, table, req.params.id);
    res.status(204).end();
  }));
}
export const adminExtras = Router();
childRoutes(adminExtras, { path: 'events', parentTable: 'events', table: 'event_images', schema: eventImageSchema, perm: 'events.write', name: 'event_id' });
childRoutes(adminExtras, { path: 'albums', parentTable: 'gallery_albums', table: 'gallery_images', schema: galleryImageSchema, perm: 'gallery.write', name: 'album_id' });

adminExtras.post('/classes/:id(\\d+)/schedules', requireAuth, requirePermission('classes.write'), ah(async (req, res) => {
  const d = scheduleSchema.parse(req.body);
  const [ins] = await db.query('INSERT INTO class_schedules SET ?', [{ ...d, class_id: req.params.id }]);
  await audit(req, 'schedule.create', 'class_schedule', ins.insertId);
  res.status(201).json({ id: ins.insertId });
}));
adminExtras.put('/schedules/:id(\\d+)', requireAuth, requirePermission('classes.write'), ah(async (req, res) => {
  await db.query('UPDATE class_schedules SET ? WHERE id = ?', [scheduleSchema.parse(req.body), req.params.id]);
  await audit(req, 'schedule.update', 'class_schedule', req.params.id);
  res.json({ message: 'Horário atualizado.' });
}));
adminExtras.delete('/schedules/:id(\\d+)', requireAuth, requirePermission('classes.write'), ah(async (req, res) => {
  await db.query('DELETE FROM class_schedules WHERE id = ?', [req.params.id]);
  await audit(req, 'schedule.delete', 'class_schedule', req.params.id);
  res.status(204).end();
}));

// Contato
export const contact = Router();
contact.post('/', contactLimiter, ah(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ message: 'Mensagem enviada.' }); // honeypot (bots)
  const d = contactSchema.parse(req.body);
  await db.query('INSERT INTO contact_messages (name, email, phone, message, ip_hash) VALUES (?,?,?,?,?)',
    [d.name, d.email, d.phone, d.message, sha256(req.ip + env.jwtSecret)]);
  res.status(201).json({ message: 'Mensagem enviada. Obrigado pelo contato!' });
}));
adminExtras.get('/messages', requireAuth, requirePermission('messages.read'), ah(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 200');
  res.json({ data: rows });
}));
adminExtras.patch('/messages/:id(\\d+)', requireAuth, requirePermission('messages.read'), ah(async (req, res) => {
  const { status } = z.object({ status: z.enum(['nova', 'lida', 'respondida', 'arquivada']) }).parse(req.body);
  await db.query('UPDATE contact_messages SET status = ? WHERE id = ?', [status, req.params.id]);
  res.json({ message: 'Atualizada.' });
}));
adminExtras.delete('/messages/:id(\\d+)', requireAuth, requirePermission('messages.read'), ah(async (req, res) => {
  await db.query('DELETE FROM contact_messages WHERE id = ?', [req.params.id]);
  await audit(req, 'message.delete', 'contact_message', req.params.id);
  res.status(204).end();
}));

// Configurações
const KEYS = new Set(['group_name', 'tagline', 'city', 'whatsapp', 'instagram', 'address', 'map_embed_url', 'emblem_url', 'seo_title', 'seo_description']);
export const settingsPublic = Router();
settingsPublic.get('/', ah(async (_req, res) => {
  const [rows] = await db.query('SELECT setting_key k, setting_value v FROM site_settings');
  res.json({ data: Object.fromEntries(rows.map((x) => [x.k, x.v])) });
}));
adminExtras.put('/settings', requireAuth, requirePermission('settings.write'), ah(async (req, res) => {
  const d = settingsSchema.parse(req.body);
  const bad = Object.keys(d).filter((k) => !KEYS.has(k));
  if (bad.length) throw new AppError(422, `Chaves não permitidas: ${bad.join(', ')}`);
  for (const [k, v] of Object.entries(d))
    await db.query('INSERT INTO site_settings (setting_key, setting_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)', [k, v, req.user.id]);
  await audit(req, 'settings.update', 'settings', null, { keys: Object.keys(d) });
  res.json({ message: 'Configurações salvas.' });
}));

// Dashboard
adminExtras.get('/stats', requireAuth, ah(async (req, res) => {
  if (!req.user.permissions.has('users.read') && !req.user.permissions.has('messages.read')) throw new AppError(403, 'Sem permissão.');
  const c = async (t, w = '') => (await db.query(`SELECT COUNT(*) n FROM ${t} ${w}`))[0][0].n;
  const [recent] = await db.query(`SELECT a.action, a.entity, a.created_at, u.name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 15`);
  res.json({ data: { users: await c('users'), students: await c('students', "WHERE status='ativo'"), events: await c('events'),
    photos: await c('gallery_images'), messages: await c('contact_messages'), newMessages: await c('contact_messages', "WHERE status='nova'"), recent } });
}));
adminExtras.get('/audit', requireAuth, requirePermission('audit.read'), ah(async (_req, res) => {
  const [rows] = await db.query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200');
  res.json({ data: rows });
}));

import { Router } from 'express';
import { db } from '../config/db.js';
import { crudModel } from '../models/crud.js';
import { requireAuth, requirePermission } from '../middlewares/auth.js';
import { ah, AppError, uniqueSlug } from '../utils/http.js';
import { audit } from '../utils/audit.js';

// Gera rotas públicas (somente publicados) e administrativas (autenticadas + permissão no backend).
export function makeResource({ name, table, schema, perm, slugFrom, order, createdBy = false, child, listHook }) {
  const m = crudModel({ table, order });
  const pub = Router(), adm = Router();
  const attach = async (row) => {
    if (!row || !child) return row;
    const [kids] = await db.query(`SELECT * FROM ?? WHERE ?? = ? ORDER BY ${child.order}`, [child.table, child.fk, row.id]);
    return { ...row, [child.key]: kids };
  };

  pub.get('/', ah(async (req, res) => {
    const extra = listHook ? listHook(req) : {};
    const rows = await m.list({ published: true, ...extra });
    res.json({ data: child?.inList ? await Promise.all(rows.map(attach)) : rows });
  }));
  pub.get('/:key', ah(async (req, res) => {
    const row = await m.find(req.params.key, { published: true });
    if (!row) throw new AppError(404, 'Não encontrado.');
    res.json({ data: await attach(row) });
  }));

  adm.use(requireAuth, requirePermission(perm));
  adm.get('/', ah(async (_req, res) => res.json({ data: await m.list() })));
  adm.get('/:id(\\d+)', ah(async (req, res) => {
    const row = await m.find(req.params.id);
    if (!row) throw new AppError(404, 'Não encontrado.');
    res.json({ data: await attach(row) });
  }));
  adm.post('/', ah(async (req, res) => {
    const data = schema.parse(req.body);
    if (slugFrom) data.slug = data.slug || await uniqueSlug(db, table, data[slugFrom]);
    if (createdBy) data.created_by = req.user.id;
    const id = await m.create(data);
    await audit(req, `${name}.create`, name, id);
    res.status(201).json({ data: await m.find(id) });
  }));
  adm.put('/:id(\\d+)', ah(async (req, res) => {
    const data = schema.partial().parse(req.body);
    if (data.slug === null) delete data.slug;
    if (!(await m.find(req.params.id))) throw new AppError(404, 'Não encontrado.');
    await m.update(req.params.id, data);
    await audit(req, `${name}.update`, name, req.params.id);
    res.json({ data: await m.find(req.params.id) });
  }));
  adm.patch('/:id(\\d+)/publish', ah(async (req, res) => {
    const pubd = req.body?.is_published === true;
    if (!(await m.update(req.params.id, { is_published: pubd }))) throw new AppError(404, 'Não encontrado.');
    await audit(req, `${name}.${pubd ? 'publish' : 'unpublish'}`, name, req.params.id);
    res.json({ data: await m.find(req.params.id) });
  }));
  adm.delete('/:id(\\d+)', ah(async (req, res) => {
    if (!(await m.remove(req.params.id))) throw new AppError(404, 'Não encontrado.');
    await audit(req, `${name}.delete`, name, req.params.id);
    res.status(204).end();
  }));
  return { pub, adm };
}

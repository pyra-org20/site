import { Router } from 'express';
import { z } from 'zod';
import { db } from '../config/db.js';
import { requireAuth, requirePermission } from '../middlewares/auth.js';
import { ah, AppError } from '../utils/http.js';
import { audit } from '../utils/audit.js';

const r = Router();
r.use(requireAuth);

// Regra: só se gerencia quem tem nível MENOR que o seu; nunca a si mesmo.
async function target(req) {
  const [[u]] = await db.query(`SELECT u.id, u.email, u.status, COALESCE(MAX(r.level),0) level FROM users u
    LEFT JOIN user_roles ur ON ur.user_id = u.id LEFT JOIN roles r ON r.id = ur.role_id WHERE u.id = ? GROUP BY u.id`, [req.params.id]);
  if (!u) throw new AppError(404, 'Usuário não encontrado.');
  if (u.id === req.user.id) throw new AppError(403, 'Você não pode fazer isso na própria conta.');
  if (u.level >= req.user.level) throw new AppError(403, 'Você não pode gerenciar um usuário de nível igual ou superior ao seu.');
  return u;
}

r.get('/', requirePermission('users.read'), ah(async (req, res) => {
  const q = `%${String(req.query.q || '').slice(0, 80)}%`;
  const limit = Math.min(Number(req.query.limit) || 25, 100), offset = (Math.max(Number(req.query.page) || 1, 1) - 1) * limit;
  const [rows] = await db.query(`SELECT u.id, u.name, u.email, u.status, u.created_at, u.last_login_at, GROUP_CONCAT(r.slug) roles
    FROM users u LEFT JOIN user_roles ur ON ur.user_id = u.id LEFT JOIN roles r ON r.id = ur.role_id
    WHERE u.name LIKE ? OR u.email LIKE ? GROUP BY u.id ORDER BY u.id DESC LIMIT ? OFFSET ?`, [q, q, limit, offset]);
  res.json({ data: rows.map((u) => ({ ...u, roles: u.roles ? u.roles.split(',') : [] })) });
}));
r.get('/:id(\\d+)', requirePermission('users.read'), ah(async (req, res) => {
  const [[u]] = await db.query(`SELECT u.id, u.name, u.email, u.phone, u.status, u.created_at, u.last_login_at, s.graduation, s.nickname
    FROM users u LEFT JOIN students s ON s.user_id = u.id WHERE u.id = ?`, [req.params.id]);
  if (!u) throw new AppError(404, 'Usuário não encontrado.');
  res.json({ data: u });
}));
r.put('/:id(\\d+)/role', requirePermission('users.write'), ah(async (req, res) => {
  const { role } = z.object({ role: z.enum(['aluno', 'administrador', 'superadministrador']) }).parse(req.body);
  await target(req);
  const [[nr]] = await db.query('SELECT id, level FROM roles WHERE slug = ?', [role]);
  if (nr.level >= req.user.level) throw new AppError(403, 'Você não pode conceder um nível igual ou superior ao seu.');
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    await conn.query('DELETE FROM user_roles WHERE user_id = ?', [req.params.id]);
    await conn.query('INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES (?,?,?)', [req.params.id, nr.id, req.user.id]);
    if (role === 'aluno') await conn.query('INSERT IGNORE INTO students (user_id) VALUES (?)', [req.params.id]);
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  await audit(req, 'user.set_role', 'user', req.params.id, { role });
  res.json({ message: 'Permissão alterada.' });
}));
r.patch('/:id(\\d+)/status', requirePermission('users.write'), ah(async (req, res) => {
  const { status } = z.object({ status: z.enum(['ativo', 'suspenso']) }).parse(req.body);
  await target(req);
  await db.query('UPDATE users SET status = ? WHERE id = ?', [status, req.params.id]);
  await audit(req, status === 'ativo' ? 'user.reactivate' : 'user.suspend', 'user', req.params.id);
  res.json({ message: status === 'ativo' ? 'Conta reativada.' : 'Conta suspensa.' });
}));
r.delete('/:id(\\d+)', requirePermission('users.delete'), ah(async (req, res) => {
  const { confirmEmail } = z.object({ confirmEmail: z.string() }).parse(req.body);
  const u = await target(req);
  if (confirmEmail.trim().toLowerCase() !== u.email) throw new AppError(422, 'Digite o e-mail da conta para confirmar a exclusão.');
  await db.query('DELETE FROM users WHERE id = ?', [u.id]);
  await audit(req, 'user.delete', 'user', u.id, { email: u.email });
  res.status(204).end();
}));
export default r;

import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { env } from '../config/env.js';
import { AppError } from '../utils/http.js';

export const uploadDir = path.resolve(env.uploadDir);
const ALLOWED = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };
export const receive = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 5 } }).single('file');

// Identifica o tipo real pelos bytes iniciais (não confia na extensão nem no MIME enviados).
function sniff(b) {
  if (b.length > 12 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length > 12 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  return null;
}
export async function saveUpload(file) {
  if (!file) throw new AppError(400, 'Envie um arquivo no campo "file".');
  const real = sniff(file.buffer);
  const declaredExt = path.extname(file.originalname).slice(1).toLowerCase().replace('jpeg', 'jpg');
  if (!real || ALLOWED[real] !== file.mimetype || declaredExt !== real)
    throw new AppError(415, 'Arquivo inválido. Envie JPG, PNG ou WebP.');
  const name = `${crypto.randomBytes(16).toString('hex')}.${real}`;
  await fs.mkdir(uploadDir, { recursive: true });
  await fs.writeFile(path.join(uploadDir, name), file.buffer, { flag: 'wx', mode: 0o644 });
  return `/uploads/${name}`;
}
export async function removeUpload(url) {
  const m = /^\/uploads\/([a-f0-9]{32}\.(jpg|png|webp))$/.exec(url || '');
  if (!m) return;
  try { await fs.unlink(path.join(uploadDir, m[1])); } catch (e) { if (e.code !== 'ENOENT') console.error(e.message); }
}

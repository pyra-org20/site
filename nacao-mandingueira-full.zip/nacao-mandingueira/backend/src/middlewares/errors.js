import { ZodError } from 'zod';
import { env } from '../config/env.js';
export const notFound = (_req, res) => res.status(404).json({ error: 'Rota não encontrada.' });
export function errorHandler(err, _req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(422).json({ error: 'Dados inválidos.', fields: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) });
  }
  if (err.status && err.expose !== false && err.name !== 'MulterError') return res.status(err.status).json({ error: err.message, details: err.details });
  if (err.name === 'MulterError') return res.status(err.code === 'LIMIT_FILE_SIZE' ? 413 : 400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Arquivo maior que 5 MB.' : 'Falha no upload.' });
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Já existe um registro com esse valor.' });
  if (err.code === 'ER_NO_REFERENCED_ROW_2') return res.status(422).json({ error: 'Referência inválida.' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.' });
  console.error(err);
  res.status(500).json({ error: 'Erro interno do servidor.', ...(env.nodeEnv !== 'production' && { debug: err.message }) });
}

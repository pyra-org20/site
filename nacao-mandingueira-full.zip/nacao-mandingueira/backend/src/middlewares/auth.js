import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { db } from '../config/db.js';
import { env } from '../config/env.js';
import { AppError } from '../utils/http.js';

const SAFE = new Set(['GET', 'HEAD', 'OPTIONS']);

export function issueSession(res, userId) {
  const csrf = crypto.randomBytes(24).toString('hex');
  const token = jwt.sign({ sub: userId, csrf }, env.jwtSecret, { expiresIn: `${env.sessionDays}d` });
  res.cookie('session', token, { httpOnly: true, secure: env.cookieSecure, sameSite: env.cookieSameSite,
    maxAge: env.sessionDays * 86400000, path: '/' });
  return csrf;
}
export const clearSession = (res) => res.clearCookie('session', { httpOnly: true, secure: env.cookieSecure, sameSite: env.cookieSameSite, path: '/' });

// Carrega o usuário e as permissões SEMPRE do banco (nunca confia no token para papéis).
export async function loadSession(req, _res, next) {
  const token = req.cookies?.session;
  if (!token) return next();
  try {
    const p = jwt.verify(token, env.jwtSecret);
    const [[u]] = await db.query('SELECT id, name, email, phone, status, password_changed_at FROM users WHERE id = ?', [p.sub]);
    const changed = u?.password_changed_at ? Date.parse(u.password_changed_at.replace(' ', 'T') + 'Z') : 0;
    if (u && u.status === 'ativo' && p.iat * 1000 >= Math.floor(changed / 1000) * 1000) {
      const [roles] = await db.query('SELECT r.slug, r.level FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?', [u.id]);
      const [perms] = await db.query(`SELECT DISTINCT p.slug FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id
        JOIN permissions p ON p.id = rp.permission_id WHERE ur.user_id = ?`, [u.id]);
      req.user = { ...u, roles: roles.map((r) => r.slug), level: Math.max(0, ...roles.map((r) => r.level)),
        permissions: new Set(perms.map((x) => x.slug)), csrf: p.csrf };
    }
  } catch { /* token inválido/expirado: segue como visitante */ }
  next();
}

export function requireAuth(req, _res, next) {
  if (!req.user) return next(new AppError(401, 'Faça login para continuar.'));
  if (!SAFE.has(req.method)) { // proteção CSRF: o header deve igualar o valor assinado no token
    const sent = String(req.get('x-csrf-token') || '');
    const ok = sent.length === req.user.csrf.length && crypto.timingSafeEqual(Buffer.from(sent), Buffer.from(req.user.csrf));
    if (!ok) return next(new AppError(403, 'Token CSRF ausente ou inválido.'));
  }
  next();
}
export const requirePermission = (slug) => (req, _res, next) =>
  req.user?.permissions.has(slug) ? next() : next(new AppError(403, 'Você não tem permissão para esta ação.'));

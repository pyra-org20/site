import rateLimit from 'express-rate-limit';
const base = { standardHeaders: true, legacyHeaders: false, message: { error: 'Muitas tentativas. Tente novamente em alguns minutos.' } };
export const apiLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 600 });
export const authLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 10 });
export const contactLimiter = rateLimit({ ...base, windowMs: 60 * 60 * 1000, limit: 5 });

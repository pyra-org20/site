import { z } from 'zod';
import sanitizeHtml from 'sanitize-html';
import { text, optText, optDate, optTime, optImage, bool, email, password, nul } from './common.js';

const html = (max) => z.string().max(max).transform((s) => sanitizeHtml(s, {
  allowedTags: ['p', 'h2', 'h3', 'h4', 'strong', 'em', 'ul', 'ol', 'li', 'blockquote', 'a', 'br', 'img', 'figure', 'figcaption'],
  allowedAttributes: { a: ['href', 'title'], img: ['src', 'alt'] },
  allowedSchemes: ['https', 'mailto'], allowedSchemesByTag: { img: ['https'] },
  transformTags: { a: sanitizeHtml.simpleTransform('a', { rel: 'noopener noreferrer', target: '_blank' }) },
}));
const optHtml = (max) => nul(html(max));
const slug = nul(z.string().max(140).regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Slug inválido'));

export const eventSchema = z.object({
  title: text(160, 3), description: optText(5000), event_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (AAAA-MM-DD)'),
  start_time: optTime, end_time: optTime, location: optText(200), cover_image_url: optImage,
  extra_info: optText(3000), is_published: bool,
});
export const teacherSchema = z.object({
  name: text(120, 2), graduation: optText(80), specialty: optText(120), bio: optText(8000),
  experience_years: nul(z.coerce.number().int().min(0).max(100)), extra_info: optText(3000),
  photo_url: optImage, sort_order: z.coerce.number().int().min(-1000).max(1000).default(0), is_published: bool,
});
export const pageSchema = z.object({
  slug, title: text(160, 2), content: optHtml(100000), seo_title: optText(160), seo_description: optText(300), is_published: bool,
});
export const albumSchema = z.object({
  title: text(160, 2), category: z.enum(['evento', 'treino', 'roda', 'apresentacao', 'historico', 'outro']).default('outro'),
  description: optText(3000), cover_image_url: optImage, is_published: bool,
});
export const classSchema = z.object({
  name: text(120, 2), description: optText(5000), beginner_info: optText(3000), student_info: optText(3000),
  how_to_join: optText(3000), location: optText(200), is_published: bool,
});
export const scheduleSchema = z.object({
  weekday: z.coerce.number().int().min(1).max(7), start_time: z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/),
  end_time: z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/), teacher_id: nul(z.coerce.number().int().positive()), location: optText(200),
}).refine((s) => s.end_time > s.start_time, { message: 'O fim deve ser depois do início', path: ['end_time'] });
export const eventImageSchema = z.object({ image_url: z.string().max(255).regex(/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/), caption: optText(200), sort_order: z.coerce.number().int().default(0) });
export const galleryImageSchema = z.object({ image_url: z.string().max(255).regex(/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/), description: optText(300), sort_order: z.coerce.number().int().default(0) });

export const registerSchema = z.object({ name: text(120, 2), email, password, phone: optText(30) });
export const loginSchema = z.object({ email, password: z.string().min(1).max(200) });
export const forgotSchema = z.object({ email });
export const resetSchema = z.object({ token: z.string().length(64).regex(/^[a-f0-9]+$/), password });
export const changePasswordSchema = z.object({ currentPassword: z.string().min(1).max(200), newPassword: password });
export const profileSchema = z.object({ name: text(120, 2), phone: optText(30) });
export const contactSchema = z.object({
  name: text(120, 2), email, phone: optText(30), message: text(3000, 10), website: z.string().max(0).optional(),
});
export const settingsSchema = z.record(z.string().regex(/^[a-z_]{2,80}$/), z.string().max(2000).transform((s) => s.replace(/<[^>]*>/g, '').trim()));

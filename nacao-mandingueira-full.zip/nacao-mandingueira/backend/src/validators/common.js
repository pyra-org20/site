import { z } from 'zod';
const strip = (s) => s.replace(/<[^>]*>/g, '').trim();
export const text = (max, min = 0) => z.string().max(max * 2).transform(strip).pipe(z.string().min(min).max(max));
const nul = (schema) => z.preprocess((v) => (v === '' || v === undefined ? null : v), schema.nullable());
export const optText = (max) => nul(text(max));
export const optDate = nul(z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (AAAA-MM-DD)'));
export const optTime = nul(z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/, 'Horário inválido (HH:MM)'));
export const optImage = nul(z.string().max(255).regex(/^(\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)|https:\/\/[^\s]+)$/, 'URL de imagem inválida'));
export const bool = z.preprocess((v) => v === true || v === 1 || v === '1' || v === 'true', z.boolean());
export const email = z.string().trim().toLowerCase().email().max(190);
export const password = z.string().min(10, 'Mínimo de 10 caracteres').max(72, 'Máximo de 72 caracteres')
  .regex(/[A-Za-z]/, 'Inclua ao menos uma letra').regex(/\d/, 'Inclua ao menos um número');
export { nul };

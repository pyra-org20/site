import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import { env } from './config/env.js';
import { apiLimiter } from './middlewares/rateLimits.js';
import { loadSession } from './middlewares/auth.js';
import { uploadDir } from './middlewares/upload.js';
import { notFound, errorHandler } from './middlewares/errors.js';
import routes from './routes/index.js';

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(compression());
app.use(cors({
  origin: (origin, cb) => cb(null, !origin || env.corsOrigins.includes(origin)),
  credentials: true, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], allowedHeaders: ['Content-Type', 'X-CSRF-Token'],
}));
app.use(express.json({ limit: '200kb' }));
app.use(cookieParser());
app.use('/uploads', express.static(uploadDir, { index: false, dotfiles: 'deny', maxAge: '30d', immutable: true,
  setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff') }));
app.use('/api', apiLimiter, loadSession, routes);
app.use(notFound);
app.use(errorHandler);
export default app;

import { db } from '../config/db.js';
import { env } from '../config/env.js';
import { sha256 } from './http.js';
export async function audit(req, action, entity = null, entityId = null, details = null) {
  try {
    await db.query('INSERT INTO audit_logs (user_id, action, entity, entity_id, details, ip_hash) VALUES (?,?,?,?,?,?)',
      [req.user?.id ?? null, action, entity, entityId == null ? null : String(entityId),
       details ? JSON.stringify(details) : null, sha256(req.ip + env.jwtSecret)]);
  } catch (e) { console.error('Falha ao gravar auditoria:', e.message); }
}

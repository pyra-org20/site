import crypto from 'node:crypto';
export class AppError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}
export const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
export const slugify = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 100) || 'item';
export async function uniqueSlug(db, table, base) {
  let slug = slugify(base);
  for (let i = 0; i < 5; i++) {
    const [r] = await db.query('SELECT 1 FROM ?? WHERE slug = ? LIMIT 1', [table, slug]);
    if (!r.length) return slug;
    slug = `${slugify(base).slice(0, 90)}-${crypto.randomBytes(2).toString('hex')}`;
  }
  return slug;
}
export const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

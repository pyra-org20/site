import { env } from '../config/env.js';
export async function sendMail({ to, subject, text }) {
  if (!env.smtp.host) { console.log(`[e-mail não configurado] Para: ${to}\nAssunto: ${subject}\n${text}`); return; }
  const { default: nodemailer } = await import('nodemailer');
  const t = nodemailer.createTransport({ host: env.smtp.host, port: env.smtp.port, secure: env.smtp.port === 465,
    auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.pass } : undefined });
  await t.sendMail({ from: env.smtp.from || env.smtp.user, to, subject, text });
}

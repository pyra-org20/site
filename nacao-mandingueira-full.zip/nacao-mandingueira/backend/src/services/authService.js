import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { db } from '../config/db.js';
import { env } from '../config/env.js';
import { AppError, sha256 } from '../utils/http.js';
import { sendMail } from './mailer.js';

const COST = 12;
const DUMMY = bcrypt.hashSync('dummy-password-for-timing', COST);
export const hashPassword = (p) => bcrypt.hash(p, COST);

export async function createUser({ name, email, password = null, phone = null, googleId = null, roleSlug = 'aluno' }) {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const hash = password ? await hashPassword(password) : null;
    const [r] = await conn.query('INSERT INTO users (name, email, password_hash, phone, google_id) VALUES (?,?,?,?,?)', [name, email, hash, phone, googleId]);
    await conn.query('INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = ?', [r.insertId, roleSlug]);
    if (roleSlug === 'aluno') await conn.query('INSERT INTO students (user_id) VALUES (?)', [r.insertId]);
    await conn.commit();
    return r.insertId;
  } catch (e) {
    await conn.rollback();
    if (e.code === 'ER_DUP_ENTRY') throw new AppError(409, 'Este e-mail já está cadastrado.');
    throw e;
  } finally { conn.release(); }
}

export async function verifyLogin(email, password) {
  const [[u]] = await db.query('SELECT id, password_hash, status FROM users WHERE email = ?', [email]);
  const ok = await bcrypt.compare(password, u?.password_hash || DUMMY);
  if (!u || !u.password_hash || !ok) throw new AppError(401, 'E-mail ou senha incorretos.');
  if (u.status !== 'ativo') throw new AppError(403, 'Conta suspensa. Entre em contato com o grupo.');
  await db.query('UPDATE users SET last_login_at = UTC_TIMESTAMP() WHERE id = ?', [u.id]);
  return u.id;
}

export async function changePassword(userId, current, next) {
  const [[u]] = await db.query('SELECT password_hash FROM users WHERE id = ?', [userId]);
  if (!u?.password_hash || !(await bcrypt.compare(current, u.password_hash))) throw new AppError(401, 'Senha atual incorreta.');
  await db.query('UPDATE users SET password_hash = ?, password_changed_at = UTC_TIMESTAMP() WHERE id = ?', [await hashPassword(next), userId]);
}

export async function requestReset(email) {
  const [[u]] = await db.query("SELECT id, name FROM users WHERE email = ? AND status = 'ativo'", [email]);
  if (!u) return; // não revela se o e-mail existe
  const token = crypto.randomBytes(32).toString('hex');
  await db.query('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 1 HOUR))', [u.id, sha256(token)]);
  await sendMail({ to: email, subject: 'Recuperação de senha — Nação Mandingueira',
    text: `Olá, ${u.name}.\n\nPara criar uma nova senha, abra o link (vale por 1 hora):\n${env.frontendUrl}/redefinir-senha?token=${token}\n\nSe não foi você, ignore esta mensagem.` });
}

export async function resetPassword(token, password) {
  const [[r]] = await db.query('SELECT id, user_id FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP()', [sha256(token)]);
  if (!r) throw new AppError(400, 'Link inválido ou expirado. Solicite um novo.');
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    await conn.query('UPDATE users SET password_hash = ?, password_changed_at = UTC_TIMESTAMP() WHERE id = ?', [await hashPassword(password), r.user_id]);
    await conn.query('UPDATE password_resets SET used_at = UTC_TIMESTAMP() WHERE user_id = ? AND used_at IS NULL', [r.user_id]);
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}

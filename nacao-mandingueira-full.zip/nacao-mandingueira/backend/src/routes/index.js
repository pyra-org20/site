import { Router } from 'express';
import auth from '../controllers/auth.js';
import users from '../controllers/users.js';
import { makeResource } from '../controllers/resource.js';
import { upload, adminExtras, contact, settingsPublic } from '../controllers/extras.js';
import * as S from '../validators/schemas.js';

const events = makeResource({ name: 'event', table: 'events', schema: S.eventSchema, perm: 'events.write', slugFrom: 'title', createdBy: true,
  order: 'event_date DESC, start_time DESC', child: { table: 'event_images', fk: 'event_id', key: 'images', order: 'sort_order, id' },
  listHook: (req) => req.query.when === 'upcoming' ? { where: ['event_date >= CURDATE()'], order: 'event_date ASC, start_time ASC' }
    : req.query.when === 'past' ? { where: ['event_date < CURDATE()'] } : {} });
const teachers = makeResource({ name: 'teacher', table: 'teachers', schema: S.teacherSchema, perm: 'teachers.write', slugFrom: 'name', order: 'sort_order, name' });
const pages = makeResource({ name: 'page', table: 'pages', schema: S.pageSchema, perm: 'content.write', slugFrom: 'title', createdBy: true, order: 'title' });
const albums = makeResource({ name: 'album', table: 'gallery_albums', schema: S.albumSchema, perm: 'gallery.write', slugFrom: 'title', order: 'created_at DESC',
  child: { table: 'gallery_images', fk: 'album_id', key: 'images', order: 'sort_order, id' } });
const classes = makeResource({ name: 'class', table: 'classes', schema: S.classSchema, perm: 'classes.write', order: 'name',
  child: { table: 'class_schedules', fk: 'class_id', key: 'schedules', order: 'weekday, start_time', inList: true } });

const api = Router();
api.get('/health', (_req, res) => res.json({ ok: true }));
api.use('/auth', auth);
api.use('/events', events.pub); api.use('/teachers', teachers.pub); api.use('/pages', pages.pub);
api.use('/gallery/albums', albums.pub); api.use('/classes', classes.pub);
api.use('/settings', settingsPublic); api.use('/contact', contact);

const admin = Router();
admin.use('/events', events.adm); admin.use('/teachers', teachers.adm); admin.use('/pages', pages.adm);
admin.use('/albums', albums.adm); admin.use('/classes', classes.adm); admin.use('/users', users);
admin.use('/uploads', upload); admin.use('/', adminExtras);
api.use('/admin', admin);
export default api;

import app from './app.js';
import { env } from './config/env.js';
import { db } from './config/db.js';
await db.query('SELECT 1'); // falha cedo se o banco estiver inacessível
const server = app.listen(env.port, () => console.log(`API em http://localhost:${env.port} (${env.nodeEnv})`));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close(async () => { await db.end(); process.exit(0); }));

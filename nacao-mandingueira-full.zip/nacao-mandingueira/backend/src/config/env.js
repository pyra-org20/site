import 'dotenv/config';
const need = (k) => { const v = process.env[k]; if (!v) throw new Error(`Variável de ambiente ausente: ${k}`); return v; };
const sameSite = (process.env.COOKIE_SAMESITE || 'lax').toLowerCase();
if (!['lax', 'strict', 'none'].includes(sameSite)) throw new Error('COOKIE_SAMESITE inválido');
const jwtSecret = need('JWT_SECRET');
if (jwtSecret.length < 32) throw new Error('JWT_SECRET deve ter ao menos 32 caracteres');
export const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 3000,
  db: { host: need('DB_HOST'), port: Number(process.env.DB_PORT) || 3306, user: need('DB_USER'),
        password: process.env.DB_PASSWORD || '', database: need('DB_NAME'), ssl: process.env.DB_SSL === 'true' },
  jwtSecret,
  sessionDays: Number(process.env.SESSION_DAYS) || 7,
  corsOrigins: (process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  frontendUrl: (process.env.FRONTEND_URL || '').replace(/\/$/, ''),
  cookieSameSite: sameSite,
  cookieSecure: process.env.COOKIE_SECURE === 'true' || sameSite === 'none' || process.env.NODE_ENV === 'production',
  uploadDir: process.env.UPLOAD_DIR || './uploads',
  google: { id: process.env.GOOGLE_CLIENT_ID, secret: process.env.GOOGLE_CLIENT_SECRET, redirect: process.env.GOOGLE_REDIRECT_URI },
  smtp: { host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT) || 587, user: process.env.SMTP_USER, pass: process.env.SMTP_PASS, from: process.env.SMTP_FROM },
};
export const googleEnabled = Boolean(env.google.id && env.google.secret && env.google.redirect);

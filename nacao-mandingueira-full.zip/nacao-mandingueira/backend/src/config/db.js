import mysql from 'mysql2/promise';
import { env } from './env.js';
export const db = mysql.createPool({
  ...env.db, ssl: env.db.ssl ? { rejectUnauthorized: true } : undefined,
  waitForConnections: true, connectionLimit: 10, charset: 'utf8mb4', timezone: 'Z', dateStrings: true,
});

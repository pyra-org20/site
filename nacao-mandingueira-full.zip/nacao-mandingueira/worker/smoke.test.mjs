// Teste de fumaça local (Node 18+): simula o KV em memória. Uso: node smoke.test.mjs
import assert from 'node:assert/strict';
const worker = (await import('./worker.js')).default;
const mkDB = (store) => ({
  async get(k, t) { const v = store.get(k); if (!v) return null; return t === 'json' ? JSON.parse(v.value) : t === 'arrayBuffer' ? v.value : v.value; },
  async getWithMetadata(k) { const v = store.get(k); return v ? { value: v.value, metadata: v.metadata } : { value: null, metadata: null }; },
  async put(k, value, o = {}) { store.set(k, { value: typeof value === 'string' ? value : value, metadata: o.metadata }); },
  async delete(k) { store.delete(k); },
  async list({ prefix = '' } = {}) { return { keys: [...store.keys()].filter((k) => k.startsWith(prefix)).map((name) => ({ name })), list_complete: true }; },
});
const store = new Map(); const DB = mkDB(store);
let curEnv;
const env = { DB, JWT_SECRET: 'x'.repeat(40), SETUP_KEY: 'codigo-123' };
curEnv = env;
let token = null;
const call = async (method, path, body, form) => {
  const headers = {}; if (token) headers.Authorization = 'Bearer ' + token; if (body) headers['Content-Type'] = 'application/json';
  const r = await worker.fetch(new Request('https://x.test' + path, { method, headers, body: form || (body ? JSON.stringify(body) : undefined) }), curEnv);
  return { status: r.status, data: r.status === 204 ? null : await r.clone().json().catch(() => null), raw: r };
};
assert.equal((await call('GET', '/api/status')).data.needsSetup, true);
assert.equal((await call('POST', '/api/setup', { name: 'Ana', email: 'a@b.com', password: 'senhaforte123', setupKey: 'errado' })).status, 403);
assert.equal((await call('POST', '/api/setup', { name: 'Ana', email: 'a@b.com', password: 'fraca', setupKey: 'codigo-123' })).status, 422);
assert.equal((await call('POST', '/api/setup', { name: 'Ana', email: 'A@b.com', password: 'senhaforte123', setupKey: 'codigo-123' })).status, 201);
assert.equal((await call('POST', '/api/setup', { name: 'Ana', email: 'x@b.com', password: 'senhaforte123', setupKey: 'codigo-123' })).status, 403);
assert.equal((await call('GET', '/api/admin/events')).status, 401);
assert.equal((await call('POST', '/api/auth/login', { email: 'a@b.com', password: 'errada12345' })).status, 401);
token = (await call('POST', '/api/auth/login', { email: 'a@b.com', password: 'senhaforte123' })).data.token;
assert.ok(token);
const me = (await call('GET', '/api/auth/me')).data.user; assert.deepEqual(me.roles, ['superadministrador']);
// evento
assert.equal((await call('POST', '/api/admin/events', { title: 'x', event_date: '13/11' })).status, 422);
const ev = (await call('POST', '/api/admin/events', { title: '<b>Roda</b> de Rua', event_date: '2099-01-10', start_time: '19:00', is_published: false })).data.data;
assert.equal(ev.title, 'Roda de Rua'); assert.equal(ev.slug, 'roda-de-rua');
assert.equal((await call('GET', '/api/events')).data.data.length, 0);
await call('PATCH', `/api/admin/events/${ev.id}/publish`, { is_published: true });
assert.equal((await call('GET', '/api/events?when=upcoming')).data.data.length, 1);
assert.equal((await call('GET', '/api/events/roda-de-rua')).status, 200);
// upload + foto
const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, ...new Array(40).fill(0)]);
const fd = new FormData(); fd.append('file', new Blob([png], { type: 'image/png' }), 'a.png');
const up = await call('POST', '/api/admin/uploads', null, fd); assert.equal(up.status, 201); assert.match(up.data.url, /^\/uploads\/[a-f0-9]{32}\.png$/);
const bad = new FormData(); bad.append('file', new Blob(['<script>alert(1)</script>'.repeat(3)], { type: 'image/png' }), 'a.png');
assert.equal((await call('POST', '/api/admin/uploads', null, bad)).status, 415);
assert.equal((await call('POST', `/api/admin/events/${ev.id}/images`, { image_url: up.data.url, caption: 'Foto' })).status, 201);
assert.equal((await call('GET', up.data.url)).raw.headers.get('content-type'), 'image/png');
assert.equal((await call('GET', `/api/admin/events/${ev.id}`)).data.data.images.length, 1);
// aula e horário
const cl = (await call('POST', '/api/admin/classes', { name: 'Capoeira Angola', is_published: true })).data.data;
assert.equal((await call('POST', `/api/admin/classes/${cl.id}/schedules`, { weekday: '3', start_time: '19:00', end_time: '18:00' })).status, 422);
assert.equal((await call('POST', `/api/admin/classes/${cl.id}/schedules`, { weekday: '3', start_time: '18:00', end_time: '19:30' })).status, 201);
assert.equal((await call('GET', '/api/classes')).data.data[0].schedules[0].weekday, 3);
// contato
assert.equal((await call('POST', '/api/contact', { name: 'João', email: 'j@x.com', message: 'Quero treinar capoeira' })).status, 201);
assert.equal((await call('POST', '/api/contact', { name: 'J', email: 'ruim', message: 'curta' })).status, 422);
assert.equal((await call('GET', '/api/admin/messages')).data.data.length, 1);
// usuários e permissões
assert.equal((await call('GET', '/api/admin/stats')).data.data.events, 1);
assert.equal((await call('PUT', '/api/admin/settings', { whatsapp: '85999999999', hack: 'x' })).status, 422);
assert.equal((await call('PUT', '/api/admin/settings', { whatsapp: '85999999999' })).status, 200);
assert.equal((await call('GET', '/api/settings')).data.data.whatsapp, '85999999999');
// excluir evento apaga a foto
await call('DELETE', `/api/admin/events/${ev.id}`);
assert.equal([...store.keys()].some((k) => k.startsWith('up:')), false);

// ---- módulo Sedes, núcleos, turmas e horários ----
const prof = (await call('POST', '/api/admin/teachers', { name: 'Fulano de Tal', nickname: 'Fulano', graduation: 'Contramestre', phone: '85988887777', whatsapp: '85988887777', show_contact: false, is_published: true })).data.data;
const sede = (await call('POST', '/api/admin/units', { name: 'Sede Principal', type: 'sede', address: 'Rua X, 1', neighborhood: 'Centro', city: 'Fortaleza', state: 'CE', responsible_id: prof.id, is_published: true })).data.data;
assert.equal(sede.slug, 'sede-principal');
assert.equal((await call('POST', '/api/admin/units', { name: 'Outra sede', type: 'sede' })).status, 409);
assert.equal((await call('POST', '/api/admin/units', { name: 'Ruim', latitude: '200' })).status, 422);
assert.equal((await call('POST', '/api/admin/units', { name: 'Resp falso', responsible_id: 999 })).status, 422);
const nuc = (await call('POST', '/api/admin/units', { name: 'Núcleo Aldeota', neighborhood: 'Aldeota', latitude: '-3,73', longitude: '-38.5', is_published: true })).data.data;
assert.equal(nuc.type, 'nucleo'); assert.equal(nuc.latitude, -3.73);
const inativa = (await call('POST', '/api/admin/units', { name: 'Núcleo Inativo', is_published: false })).data.data;
assert.equal((await call('GET', '/api/units')).data.data.length, 2);               // inativa não aparece
assert.equal((await call('GET', '/api/units/' + inativa.slug)).status, 404);
assert.equal((await call('GET', '/api/units')).data.data[0].type, 'sede');          // sede primeiro
assert.equal((await call('POST', '/api/admin/classes', { name: 'Sem unidade ok' })).status, 201);
assert.equal((await call('POST', '/api/admin/classes', { name: 'X', unit_id: 999 })).status, 422);
assert.equal((await call('POST', '/api/admin/classes', { name: 'X', teacher_ids: [999] })).status, 422);
const infantil = (await call('POST', '/api/admin/classes', { name: 'Infantil', unit_id: sede.id, age_group: 'Infantil', level: 'Iniciante', teacher_ids: [prof.id], is_published: true })).data.data;
const r1 = await call('POST', `/api/admin/classes/${infantil.id}/schedules`, { weekday: 2, start_time: '18:00', end_time: '19:00' });
assert.equal(r1.status, 201); assert.equal(r1.data.warnings.length, 0);
const r2 = await call('POST', `/api/admin/classes/${infantil.id}/schedules`, { weekday: 2, start_time: '18:30', end_time: '19:30', notes: 'teste' });
assert.equal(r2.status, 201); assert.ok(r2.data.warnings.length >= 1);              // aviso, não bloqueio
const dup = await call('POST', `/api/admin/schedules/${r1.data.id}/duplicate`, { weekday: 4 }); assert.equal(dup.status, 201);
assert.equal((await call('PUT', `/api/admin/schedules/${dup.data.id}`, { start_time: '20:00', end_time: '19:00' })).status, 422);
assert.equal((await call('PUT', `/api/admin/schedules/${dup.data.id}`, { is_active: false })).status, 200);
const pubUnit = (await call('GET', '/api/units/sede-principal')).data.data;
assert.equal(pubUnit.classes[0].schedules.length, 2);                               // horário inativo não aparece
assert.equal(pubUnit.classes[0].schedules[0].weekday, 2);
assert.equal(pubUnit.classes[0].teachers[0].phone, undefined);                       // contato privado
assert.equal(pubUnit.responsible.whatsapp, undefined);
assert.equal((await call('GET', '/api/teachers')).data.data.find((t) => t.id === prof.id).phone, undefined);
await call('PUT', `/api/admin/teachers/${prof.id}`, { show_contact: true });
assert.equal((await call('GET', '/api/units/sede-principal')).data.data.responsible.whatsapp, '85988887777');
assert.equal((await call('GET', '/api/admin/schedules')).data.data.length, 4); // 3 novos + 1 da aula anterior
// categorias configuráveis
assert.ok((await call('GET', '/api/options')).data.data.age_groups.includes('Infantil'));
assert.equal((await call('PUT', '/api/admin/options', { age_groups: ['Bebês', 'Adulto'], levels: ['Todos'] })).status, 200);
assert.deepEqual((await call('GET', '/api/options')).data.data.age_groups, ['Bebês', 'Adulto']);
// painel
const st = (await call('GET', '/api/admin/stats')).data.data;
assert.equal(st.units, 3); assert.equal(st.nuclei_active, 1); assert.equal(st.teachers, 1); assert.ok(st.upcoming.length >= 1);
// exclusão segura
const d1 = await call('DELETE', `/api/admin/units/${sede.id}`); assert.equal(d1.status, 409); assert.equal(d1.data.fields.classes, 1);
assert.equal((await call('DELETE', `/api/admin/units/${sede.id}?force=1`)).status, 204);
assert.equal((await call('GET', '/api/admin/classes')).data.data.some((k) => k.id === infantil.id), false);
// professor excluído sai dos vínculos
const t2 = (await call('POST', '/api/admin/teachers', { name: 'Beltrano', is_published: true })).data.data;
const k2 = (await call('POST', '/api/admin/classes', { name: 'Adulto', teacher_ids: [t2.id] })).data.data;
await call('PUT', `/api/admin/units/${nuc.id}`, { responsible_id: t2.id });
await call('DELETE', `/api/admin/teachers/${t2.id}`);
assert.deepEqual((await call('GET', `/api/admin/classes/${k2.id}`)).data.data.teacher_ids, []);
assert.equal((await call('GET', `/api/admin/units/${nuc.id}`)).data.data.responsible_id, null);
// permissões: sem token
token = null;
for (const p of ['/api/admin/units', '/api/admin/schedules', '/api/admin/classes']) assert.equal((await call('GET', p)).status, 401);
assert.equal((await call('PUT', '/api/admin/options', { age_groups: ['x'], levels: ['y'] })).status, 401);

// ---- sem JWT_SECRET/SETUP_KEY (configuração mínima) + backup ----
token = (await call('POST', '/api/auth/login', { email: 'a@b.com', password: 'senhaforte123' })).data.token;
const dump = (await call('GET', '/api/admin/export')).data;
assert.equal(dump.version, 1); assert.ok(dump.items.length > 0); assert.ok(!dump.items.some((i) => i.k === 'c:users'));
const env2 = { DB: mkDB(new Map()) }; curEnv = env2; token = null;
assert.equal((await call('GET', '/api/status')).data.needsKey, false);
assert.equal((await call('POST', '/api/setup', { name: 'Bia', email: 'bia@x.com', password: 'outrasenha99' })).status, 201);
token = (await call('POST', '/api/auth/login', { email: 'bia@x.com', password: 'outrasenha99' })).data.token; assert.ok(token);
assert.equal((await call('GET', '/api/units')).data.data.length, 0);
assert.equal((await call('POST', '/api/admin/import', { version: 1, items: [{ k: 'c:users', v: '{}' }] })).status, 422);   // usuários não entram por backup
assert.equal((await call('POST', '/api/admin/import', dump)).status, 200);
assert.equal((await call('GET', '/api/units')).data.data.length, 1);                                                      // núcleo publicado veio no backup
assert.equal((await call('GET', '/api/auth/me')).data.user.email, 'bia@x.com');                                           // admin local preservado

// ---- alunos, graduações, histórico e área do aluno ----
const adminTok = token;
const g1 = (await call('POST', '/api/admin/graduations', { name: 'Corda Verde', position: 1, is_published: true })).data.data;
const g2 = (await call('POST', '/api/admin/graduations', { name: 'Corda Amarela', position: 2, is_published: true })).data.data;
assert.deepEqual((await call('GET', '/api/admin/graduations')).data.data.map((g) => g.name), ['Corda Verde', 'Corda Amarela']);
const al = (await call('POST', '/api/admin/students', { name: 'João da Silva', nickname: 'Joãozinho', phone: '85999990000', birth_date: '2010-05-01', entry_date: '2024-02-01', graduation_id: g1.id, notes: 'interno' })).data.data;
assert.equal(al.status, 'ativo'); assert.equal(al.history.length, 2);
const dupl = await call('POST', '/api/admin/students', { name: '  joao DA silva ' }); assert.equal(dupl.status, 409); assert.equal(dupl.data.fields.duplicate.id, al.id);
assert.equal((await call('POST', '/api/admin/students', { name: 'João da Silva', birth_date: '2012-01-01' })).status, 201);   // outra pessoa (nascimento diferente)
assert.equal((await call('POST', '/api/admin/students?force=1', { name: 'João da Silva' })).status, 201);                    // confirmação manual
assert.equal((await call('POST', '/api/admin/students', { name: 'X', graduation_id: 999 })).status, 422);
const gr = await call('POST', `/api/admin/students/${al.id}/graduate`, { graduation_id: g2.id, date: '2025-03-01', note: 'Batizado' });
assert.equal(gr.status, 200); assert.equal(gr.data.data.history.at(-1).title, 'Corda Verde → Corda Amarela'); assert.equal(gr.data.data.graduation_id, g2.id);
assert.equal((await call('PUT', `/api/admin/students/${al.id}`, { graduation_id: g1.id })).status, 422);                      // graduação só pelo registro
assert.equal((await call('POST', `/api/admin/students/${al.id}/history`, { type: 'observacao', title: 'Atrasos frequentes', note: 'conversar' })).status, 201);
assert.equal((await call('POST', `/api/admin/students/${al.id}/history`, { type: 'evento', title: 'Roda de aniversário do grupo' })).status, 201);
assert.equal((await call('POST', `/api/admin/students/${al.id}/history`, { type: 'inventado', title: 'x' })).status, 422);
assert.equal((await call('PATCH', `/api/admin/students/${al.id}/status`, { status: 'inativo', note: 'viagem' })).data.data.status, 'inativo');
assert.equal((await call('PATCH', `/api/admin/students/${al.id}/status`, { status: 'ativo' })).data.data.status, 'ativo');
assert.equal((await call('DELETE', `/api/admin/students/${al.id}`)).status, 404);                                            // aluno não é apagado
assert.equal((await call('DELETE', `/api/admin/graduations/${g1.id}`)).status, 409);                                          // graduação em uso
const g3 = (await call('POST', '/api/admin/graduations', { name: 'Sem uso', position: 9 })).data.data;
assert.equal((await call('DELETE', `/api/admin/graduations/${g3.id}`)).status, 204);
// acesso do aluno
assert.equal((await call('POST', `/api/admin/students/${al.id}/access`, { email: 'joao@x.com', password: 'fraca' })).status, 422);
assert.equal((await call('POST', `/api/admin/students/${al.id}/access`, { email: 'joao@x.com', password: 'senhaaluno1' })).status, 201);
assert.equal((await call('POST', `/api/admin/students/${al.id}/access`, { email: 'outro@x.com', password: 'senhaaluno1' })).status, 409);
assert.equal((await call('GET', `/api/admin/students/${al.id}`)).data.data.access_email, 'joao@x.com');
token = (await call('POST', '/api/auth/login', { email: 'joao@x.com', password: 'senhaaluno1' })).data.token; assert.ok(token);
const mine = (await call('GET', '/api/me/student')).data.data;
assert.equal(mine.name, 'João da Silva'); assert.equal(mine.graduation.name, 'Corda Amarela');
assert.equal(mine.notes, undefined); assert.equal(mine.history.some((h) => h.title === 'Atrasos frequentes' || h.type === 'situacao'), false);   // só o que é visível
assert.ok(mine.history.some((h) => h.title === 'Roda de aniversário do grupo'));
assert.equal((await call('GET', '/api/admin/students')).status, 403);                                                         // aluno não acessa outros alunos
assert.equal((await call('POST', `/api/admin/students/${al.id}/graduate`, { graduation_id: g1.id })).status, 403);
assert.equal((await call('GET', '/api/admin/users')).status, 403);
// professor: somente leitura, sem dados sensíveis
token = adminTok;
const uid = (await call('GET', '/api/admin/users')).data.data.find((u) => u.email === 'joao@x.com').id;
assert.equal((await call('PUT', `/api/admin/users/${uid}/role`, { role: 'professor' })).status, 200);
token = (await call('POST', '/api/auth/login', { email: 'joao@x.com', password: 'senhaaluno1' })).data.token;
const lista = (await call('GET', '/api/admin/students')).data.data;
assert.ok(lista.length >= 1); assert.equal(lista[0].phone, undefined); assert.equal(lista[0].notes, undefined); assert.equal(lista[0].history, undefined);
assert.equal((await call('POST', '/api/admin/students', { name: 'Novo' })).status, 403);
assert.equal((await call('GET', '/api/admin/graduations')).status, 200);
// redefinir senha derruba a sessão antiga
token = adminTok;
assert.equal((await call('PUT', `/api/admin/students/${al.id}/access`, { password: 'novasenha22' })).status, 200);
assert.equal((await call('GET', '/api/admin/stats')).data.data.students_total, 3);
console.log('Todos os testes de fumaça passaram.');

# Guia: colocar o sistema no ar só pelo Cloudflare (pelo celular)

Os nomes dos menus do Cloudflare podem mudar um pouco; o caminho é este.

## 1. Criar o armazenamento (KV)
Cloudflare → **Workers e Pages** → **KV** → **Criar namespace** → nome `nacao-db`.

## 2. Criar o Worker da API
1. **Workers e Pages** → **Criar** → **Criar Worker** → nome exatamente **`nacao-api`** → **Implantar**.
2. **Editar código** → apague tudo → cole o conteúdo do arquivo `worker.js` → **Implantar**.

## 3. Ligar o armazenamento
Worker `nacao-api` → **Configurações** → **Associações (Bindings)** → **Adicionar** → **Namespace KV**:
- Nome da variável: **`DB`** (maiúsculo, exatamente assim)
- Namespace: `nacao-db`

## 4. Segredos e variáveis
Worker → **Configurações** → **Variáveis e segredos** → adicionar:
| Nome | Tipo | Valor |
|---|---|---|
| `JWT_SECRET` | Segredo | texto aleatório longo (40+ caracteres) |
| `SETUP_KEY` | Segredo | um código que você inventa (só usa no primeiro acesso) |
| `ALLOWED_ORIGINS` | Texto | `https://capoeira.sereronildes6.workers.dev` |

## 5. Atualizar o site
O endereço do seu Worker deve ser `https://nacao-api.sereronildes6.workers.dev` (já está no `frontend/config.js`). Se o seu for diferente, edite o `config.js`. Depois envie de novo a pasta `frontend` ao seu site.

## 6. Primeiro acesso
Abra `https://capoeira.sereronildes6.workers.dev/admin/`. Aparece **Primeiro acesso**: informe nome, e-mail, senha (10+ caracteres, letra e número) e o `SETUP_KEY`.

## 7. Cadastrar o conteúdo
- **Páginas** → Novo → título "Nossa História", endereço `nossa-historia`, marque **Publicada**.
- **Aulas**, **Professores**, **Eventos**, **Galeria**: crie, adicione fotos/horários e use **Publicar**.
- **Configurações**: WhatsApp, Instagram, endereço e mapa.
- **Usuários**: mude a permissão de quem tiver cadastro; use "Nova senha" para quem esquecer.

## Observações
- Fotos são reduzidas no celular (1600 px) antes do envio; o limite é 1,5 MB por foto.
- O KV pode levar até cerca de 1 minuto para uma mudança aparecer em outras regiões.
- Se o login der erro 1102 ("CPU time"), o plano gratuito está limitando o cálculo da senha: reduza `ITER` no `worker.js` (ex.: 20000) e crie o admin de novo, ou use o plano pago.
- Confira os limites atuais do plano gratuito do KV no site do Cloudflare.
- Teste local (opcional): `node worker/smoke.test.mjs`.
- Não há cadastro público de alunos nesta versão; administradores gerenciam usuários.

## Atualizações
Sempre que receber um novo `worker.js`, repita o passo 2 (colar e **Implantar**); as configurações e os dados continuam. Para o site, reenvie a pasta `frontend`. Para o módulo de unidades, veja `docs/UNIDADES-E-HORARIOS.md`.

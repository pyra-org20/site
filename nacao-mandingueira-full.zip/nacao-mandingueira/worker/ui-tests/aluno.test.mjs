import assert from 'node:assert/strict';
class Txt { constructor(t) { this.nodeType = 3; this.text = String(t); } }
class El { constructor(t) { this.tagName = t.toUpperCase(); this.attrs = {}; this.children = []; this.style = {}; this.listeners = {}; this.value = ''; this.className = ''; }
  get nodeType() { return 1; } setAttribute(k, v) { this.attrs[k] = String(v); } getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
  append(...k) { for (const c of k) this.children.push(typeof c === 'string' ? new Txt(c) : c); } replaceChildren(...k) { this.children = []; this.append(...k); }
  addEventListener(t, f) { (this.listeners[t] ||= []).push(f); } set textContent(v) { this.children = [new Txt(v)]; }
  get textContent() { return this.children.map((c) => (c.nodeType === 3 ? c.text : c.textContent)).join(' '); } }
const main = new El('main'); globalThis.window = globalThis;
globalThis.document = { createElement: (t) => new El(t), createTextNode: (t) => new Txt(t), getElementById: () => main, body: new El('body'), querySelector: () => null };
const mem = new Map(); globalThis.localStorage = { get length() { return mem.size; }, key: (i) => [...mem.keys()][i], getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
globalThis.MutationObserver = class { observe() {} }; window.APP_CONFIG = { API_URL: 'local' };
await import('../../frontend/src/local.js');
const call = async (m, p, b, tok) => { const r = await fetch('https://local.nacao' + p, { method: m, headers: { ...(b ? { 'Content-Type': 'application/json' } : {}), ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: b ? JSON.stringify(b) : undefined }); return { s: r.status, d: r.status === 204 ? null : await r.json() }; };
await call('POST', '/api/setup', { name: 'Ana', email: 'a@b.com', password: 'senhaforte123' });
const T = (await call('POST', '/api/auth/login', { email: 'a@b.com', password: 'senhaforte123' })).d.token;
const g1 = (await call('POST', '/api/admin/graduations', { name: 'Corda Verde', position: 1, is_published: true }, T)).d.data;
const st = (await call('POST', '/api/admin/students', { name: 'João da Silva', nickname: 'Joãozinho', notes: 'SEGREDO-INTERNO' }, T)).d.data;
await call('POST', `/api/admin/students/${st.id}/graduate`, { graduation_id: g1.id }, T);
await call('POST', `/api/admin/students/${st.id}/history`, { type: 'observacao', title: 'NOTA-PRIVADA' }, T);
await call('POST', `/api/admin/students/${st.id}/history`, { type: 'evento', title: 'Roda de formatura' }, T);
await call('POST', `/api/admin/students/${st.id}/access`, { email: 'joao@x.com', password: 'senhaaluno1' }, T);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
await import('../../frontend/src/aluno.js'); await sleep(200);
assert.match(main.textContent, /Área do aluno/);
const walk = (n, f) => { f(n); (n.children || []).forEach((c) => walk(c, f)); };
let form; walk(main, (n) => { if (n.tagName === 'FORM') form = n; });
walk(main, (n) => { if (n.tagName === 'INPUT' && n.attrs.type === 'email') n.value = 'joao@x.com'; if (n.tagName === 'INPUT' && n.attrs.type === 'password') n.value = 'senhaaluno1'; });
for (const f of form.listeners.submit) await f({ preventDefault() {} }); await sleep(400);
const t = main.textContent; console.log(t.replace(/\s+/g, ' ').slice(0, 300));
assert.match(t, /João da Silva/); assert.match(t, /Corda Verde/); assert.match(t, /Roda de formatura/); assert.match(t, /Entrada no grupo/);
assert.ok(!t.includes('SEGREDO-INTERNO') && !t.includes('NOTA-PRIVADA') && !/desativado/i.test(t));
console.log('AREA DO ALUNO OK');

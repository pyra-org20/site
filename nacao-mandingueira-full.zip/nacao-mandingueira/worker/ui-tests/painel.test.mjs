import assert from 'node:assert/strict';
// --- DOM falso mínimo, só para executar o código do painel ---
class Txt { constructor(t) { this.nodeType = 3; this.text = String(t); } }
class El {
  constructor(tag) { this.tagName = tag.toUpperCase(); this.attrs = {}; this.children = []; this.style = {}; this.listeners = {}; this.value = ''; this.checked = false; this.hidden = false; this.className = ''; this.files = []; }
  get nodeType() { return 1; }
  setAttribute(k, v) { this.attrs[k] = String(v); if (k === 'value') this.value = String(v); if (k === 'checked') this.checked = true; }
  getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
  append(...k) { for (const c of k) this.children.push(typeof c === 'string' ? new Txt(c) : c); }
  replaceChildren(...k) { this.children = []; this.append(...k); }
  addEventListener(t, f) { (this.listeners[t] ||= []).push(f); }
  scrollIntoView() {} remove() {} click() {} showModal() { this.open = true; } close() { this.open = false; }
  set textContent(v) { this.children = [new Txt(v)]; }
  get textContent() { return this.children.map((c) => (c.nodeType === 3 ? c.text : c.textContent)).join(' '); }
}
const app = new El('div'), dlg = new El('dialog'), toasts = new El('div');
globalThis.window = globalThis;
globalThis.document = { createElement: (t) => new El(t), createTextNode: (t) => new Txt(t), getElementById: (id) => ({ app, dlg, toasts }[id]), body: new El('body'), querySelector: () => null };
const mem = new Map();
globalThis.localStorage = { get length() { return mem.size; }, key: (i) => [...mem.keys()][i], getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
globalThis.MutationObserver = class { observe() {} };
let hc; globalThis.addEventListener = (t, f) => { if (t === 'hashchange') hc = f; };
globalThis.location = { hash: '', replace(h) { this.hash = h; hc && hc(); } };
globalThis.scrollTo = () => {};
const errors = []; process.on('unhandledRejection', (e) => errors.push(e));
window.APP_CONFIG = { API_URL: 'local' };
await import('../../frontend/src/local.js');
const call = async (m, p, b, tok) => { const r = await fetch('https://local.nacao' + p, { method: m, headers: { ...(b ? { 'Content-Type': 'application/json' } : {}), ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: b ? JSON.stringify(b) : undefined }); return { s: r.status, d: r.status === 204 ? null : await r.json() }; };
await call('POST', '/api/setup', { name: 'Ana', email: 'a@b.com', password: 'senhaforte123' });
const tok = (await call('POST', '/api/auth/login', { email: 'a@b.com', password: 'senhaforte123' })).d.token; localStorage.setItem('nm_token', tok);
const g = (await call('POST', '/api/admin/graduations', { name: 'Corda Verde', position: 1, is_published: true }, tok)).d.data;
const st = (await call('POST', '/api/admin/students', { name: 'João da Silva', nickname: 'Joãozinho', graduation_id: g.id }, tok)).d.data;
const tc = (await call('POST', '/api/admin/teachers', { name: 'Mestre Teste', is_published: true }, tok)).d.data;
const un = (await call('POST', '/api/admin/units', { name: 'Sede Principal', type: 'sede', is_published: true }, tok)).d.data;
const cl = (await call('POST', '/api/admin/classes', { name: 'Infantil', unit_id: un.id, teacher_ids: [tc.id], is_published: true }, tok)).d.data;
await call('POST', `/api/admin/classes/${cl.id}/schedules`, { weekday: 2, start_time: '18:00', end_time: '19:00' }, tok);
await call('POST', '/api/admin/events', { title: 'Roda de teste', event_date: '2099-01-01' }, tok);
await import('../../frontend/admin/admin.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
await sleep(400);
const walk = (n, f) => { f(n); (n.children || []).forEach((c) => walk(c, f)); };
const find = (root, text, tag = 'BUTTON') => { let hit; walk(root, (n) => { if (!hit && n.tagName === tag && n.textContent.includes(text)) hit = n; }); return hit; };
const fire = async (el) => { for (const f of el.listeners.click || []) await f(); if (el.onclick) await el.onclick(); await sleep(250); };
const BAD = /not defined|is not a function|Cannot read|undefined|NaN|\[object/;
const visit = async (h) => { location.hash = h; await hc(); await sleep(350); const t = app.textContent; console.log(h.padEnd(18), '→', t.replace(/\s+/g, ' ').slice(0, 110)); { const m = BAD.exec(t); assert.ok(!m, `Erro de tela em ${h}: …${t.slice(Math.max(0, m?.index - 80), (m?.index || 0) + 80)}…`); }; return t; };
for (const h of ['#/dashboard', '#/students', '#/students/new', `#/students/${st.id}`, '#/graduations', '#/graduations/new', '#/units', `#/units/${un.id}`, '#/classes', `#/classes/${cl.id}`, '#/teachers', `#/teachers/${tc.id}`, '#/events', '#/pages', '#/albums', '#/horarios', '#/options', '#/messages', '#/users', '#/settings', '#/backup']) await visit(h);
// páginas "História" cria a página e abre a edição
await visit('#/historia'); assert.match(location.hash, /^#\/pages\/\d+$/); assert.match(app.textContent, /Editar: Páginas/);
// interações no aluno: registrar graduação, histórico, desativar, criar acesso
await visit(`#/students/${st.id}`);
await fire(find(app, 'Registrar graduação'));
let t = await visit(`#/students/${st.id}`); assert.match(t, /Corda Verde/);
const tit = find(app, '', 'INPUT'); // primeiro input qualquer
let hit; walk(app, (n) => { if (n.tagName === 'INPUT' && n.attrs.placeholder === 'Título') hit = n; }); hit.value = 'Roda de formatura'; await fire(find(app, 'Adicionar ao histórico'));
t = await visit(`#/students/${st.id}`); assert.match(t, /Roda de formatura/);
walk(app, (n) => { if (n.tagName === 'INPUT' && n.attrs.placeholder === 'E-mail do aluno') n.value = 'joao@x.com'; if (n.tagName === 'INPUT' && String(n.attrs.placeholder).startsWith('Senha inicial')) n.value = 'senhaaluno1'; });
await fire(find(app, 'Criar acesso'));
t = await visit(`#/students/${st.id}`); assert.match(t, /Acesso ativo/); assert.match(t, /joao@x.com/);
const r = await call('POST', '/api/auth/login', { email: 'joao@x.com', password: 'senhaaluno1' }); assert.equal(r.s, 200);
// diálogo de confirmação ao desativar
const press = (el) => { for (const f of el.listeners.click || []) f(); if (el.onclick) el.onclick(); return sleep(300); };
await press(find(app, 'Desativar aluno')); assert.ok(dlg.open); await press(find(dlg, 'Desativar')); await sleep(300);
t = await visit(`#/students/${st.id}`); assert.match(t, /Inativo/);
assert.deepEqual(errors, []);
console.log('PAINEL OK');

# API — Nação Mandingueira (resumo)
Base: /api. Sessão por cookie HttpOnly. Em POST/PUT/PATCH/DELETE autenticados, enviar o header X-CSRF-Token (valor vem de /auth/login ou /auth/me).

Público: GET /events (?when=upcoming|past), /events/:slug, /teachers, /pages/:slug, /gallery/albums, /gallery/albums/:slug, /classes, /settings; POST /contact
Auth: POST /auth/register, /login, /logout, /forgot-password, /reset-password, /change-password; GET /auth/me; PUT /auth/profile; GET /auth/google (só com credenciais)
Admin (/api/admin, permissão checada no backend): events, teachers, pages, albums, classes (CRUD + PATCH :id/publish); POST /uploads; imagens de eventos/álbuns; horários; users (lista, papel, status, exclusão com confirmação por e-mail); messages; settings; stats; audit

# Segurança — o que está implementado e o que falta

Implementado: senhas com bcrypt (custo 12); sessão em cookie HttpOnly/Secure/SameSite; CSRF por token assinado; permissões lidas do banco a cada requisição; suspensão efetiva na hora; troca/redefinição de senha encerra as outras sessões; limite de requisições (geral, login, contato); Helmet; CORS por lista; consultas parametrizadas (SQL Injection); texto limpo de tags e HTML sanitizado no servidor e no navegador; upload validado pelos bytes, 5 MB, nome aleatório, sem SVG; auditoria de ações administrativas; CSP e cabeçalhos no frontend (`_headers`).

Antes de publicar: JWT_SECRET longo e único; HTTPS; COOKIE_SECURE=true; usuário do MySQL só com acesso ao banco do projeto; backup do banco e da pasta uploads; apagar SUPERADMIN_PASSWORD do .env; trocar api.SEUDOMINIO.com.br no `_headers`.

Limites conhecidos: o cadastro informa quando o e-mail já existe; não há verificação de e-mail no cadastro; não há 2FA; as dimensões das imagens não são validadas; o site público carrega o conteúdo por JavaScript (SEO limitado); testes de integração com banco real não foram escritos.

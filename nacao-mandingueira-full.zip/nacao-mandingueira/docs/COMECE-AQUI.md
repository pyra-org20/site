# Comece aqui (pelo celular, sem servidor)

## 1. Colocar no ar o painel funcionando
Reenvie a pasta **frontend** (a do zip) para o seu site no Cloudflare, do mesmo jeito que você já fez.

## 2. Abrir o painel
No navegador, abra: **https://capoeira.sereronildes6.workers.dev/admin/**
Na primeira vez aparece **Primeiro acesso**: coloque seu nome, e-mail e uma senha (10 ou mais caracteres, com letras e números). **Anote o e-mail e a senha.**
Depois, entre com eles.

## 3. Cadastrar tudo (menus do painel)
- **História**: abre direto a página Nossa História. Escreva o texto (separe parágrafos com uma linha em branco) e marque **Publicada**.
- **Professores** → depois **Unidades** (sede e núcleos) → **Categorias** → **Turmas** → dentro da turma, os **horários**.
- **Eventos**, **Galeria** e **Configurações** (WhatsApp, Instagram, endereço).
- Passo a passo detalhado: `docs/UNIDADES-E-HORARIOS.md`.

## ⚠ Muito importante: modo teste
Do jeito que está, os dados ficam **somente neste celular/navegador**. Os visitantes do site **não veem** o que você cadastrou, e se limpar os dados do navegador, perde tudo.
- **Baixe um backup** de vez em quando: menu **Backup → Baixar backup**.
- Use sempre o **mesmo navegador** e não limpe os dados dele.
- As fotos são guardadas no navegador, que tem pouco espaço (poucas dezenas de fotos).

## Publicar para todos verem (quando quiser)
Isso exige o servidor (Worker do Cloudflare). Ficou mais simples: não precisa mais de segredos nem de código de instalação.
1. Cloudflare → **KV** → criar namespace `nacao-db`.
2. **Workers** → criar Worker `nacao-api` → **Editar código** → colar `worker/worker.js` → **Implantar**.
3. No Worker → **Configurações → Associações** → KV, variável **`DB`** → namespace `nacao-db`.
4. Em `frontend/config.js`, troque `'local'` por `'https://nacao-api.sereronildes6.workers.dev'` e reenvie a pasta `frontend`.
5. Abra `/admin/`, crie o administrador (agora no servidor), vá em **Backup → Restaurar** e escolha o backup baixado do modo teste.

## Para quem mantém o código
`frontend/local/worker.js` é uma cópia de `worker/worker.js`. Ao atualizar um, copie para o outro.

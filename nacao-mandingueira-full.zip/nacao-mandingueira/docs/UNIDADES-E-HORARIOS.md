# Sedes, núcleos, turmas e horários — guia para quem não programa

Tudo é feito no painel: `seusite/admin/`. Nada precisa de código. O site público fica em `seusite/unidades/`.

## Antes de começar: atualizar o sistema (uma vez)
1. Cloudflare → Worker `nacao-api` → **Editar código** → apague tudo → cole o novo `worker/worker.js` → **Implantar**.
2. Reenvie a pasta `frontend` do zip para o seu site.
Os dados que você já cadastrou continuam como estão.

## Ordem recomendada de cadastro
1. **Professores** (menu *Professores*) → Novo: nome, apelido, graduação, foto, biografia.
   Telefone e WhatsApp do professor ficam **privados**. Só aparecem no site se você marcar "O professor autorizou mostrar telefone e WhatsApp".
2. **Unidades** (menu *Unidades*) → Novo.
   - **Sede principal:** em *Tipo* escolha "Sede principal". Só pode haver uma; ela aparece em destaque.
   - **Núcleo:** em *Tipo* escolha "Núcleo". Pode cadastrar quantos quiser.
   - Preencha endereço, bairro, cidade, estado, CEP e ponto de referência. Latitude e longitude são opcionais; se ficarem vazias, o mapa usa o endereço.
   - Escolha o **Responsável** e envie a fotografia. Marque **Ativa** para aparecer no site. Depois de salvar, você pode adicionar mais fotos.
3. **Categorias** (menu *Categorias*): edite as faixas etárias e os níveis (uma por linha). Elas aparecem nas turmas e nos filtros do site.
4. **Turmas** (menu *Turmas*) → Nova: nome, unidade, faixa etária, nível, modalidade, capacidade (opcional) e professores responsáveis. Marque **Ativa**.
5. **Horários:** abra a turma → seção *Dias e horários*: escolha o dia, o início e o fim → *Adicionar horário*.
   - **Editar:** toque em *Editar*, altere e toque em *Salvar alteração*.
   - **Duplicar em outro dia:** escolha o dia no seletor e toque em *Duplicar* no horário desejado.
   - **Ativar/Desativar:** um horário inativo some do site, mas fica guardado.
   - **Conflitos:** se dois horários se sobrepõem (mesma turma, mesma unidade ou mesmo professor), aparece um **aviso**. O horário é salvo mesmo assim, pois pode ser legítimo.
6. Menu *Horários* mostra a **grade da semana** com todas as turmas e marca os conflitos.

## Alterar, ativar e desativar
- Em cada lista, use **Editar**, **Publicar/Despublicar** (ativa ou desativa na hora) e **Excluir**.
- Unidade desativada, turma desativada ou professor desativado **não aparecem** no site.

## Excluir uma unidade
Se ela tiver turmas, o painel avisa quantas turmas e horários serão apagados junto. Só continua se você confirmar. Se preferir manter o histórico, **desative** em vez de excluir.
Ao excluir um professor, ele é retirado das turmas e deixa de ser responsável de unidades (nada mais é apagado).

## O que o visitante vê (seusite/unidades/)
Pesquisa por núcleo, professor, turma ou bairro; filtros por bairro, unidade, dia, período do dia, faixa etária, nível e professor; sede em destaque; cartões com endereço, horários e botões *Ver unidade*, *Como chegar* e *WhatsApp*. Cada unidade tem mapa, turmas e grade semanal. O endereço de cada unidade é `.../unidades/#nome-da-unidade`.

## Erros comuns
- **"Já existe uma sede principal"**: mude a sede atual para *Núcleo* antes de definir outra.
- **"Unidade inexistente"** ao salvar turma: a unidade foi excluída; escolha outra.
- **Unidade não aparece no site**: confira se está marcada como *Ativa*.
- **Mapa vazio**: preencha o endereço (ou latitude e longitude).
- **Horário recusado**: o fim precisa ser depois do início.
- **A mudança demora a aparecer**: aguarde cerca de 1 minuto e atualize a página.
- **Texto "Não foi possível carregar"**: o Worker está fora do ar ou o endereço no `config.js` está errado.

## Informações técnicas (para quem mantém)
- Armazenamento: Cloudflare KV (JSON), sem tabelas SQL. As turmas reaproveitam a coleção *Aulas* já existente (ganharam unidade, faixa, nível, modalidade, capacidade e professores). Os professores reaproveitam *Professores* (ganharam apelido e contato opcional).
- Rotas novas: `GET /api/units`, `GET /api/units/:slug`, `GET /api/options`; administrativas: `/api/admin/units`, `/api/admin/units/:id/images`, `/api/admin/schedules` (+ `PUT`, `DELETE`, `POST …/duplicate`), `PUT /api/admin/options`. Turmas e professores usam as rotas já existentes (`/api/admin/classes`, `/api/admin/teachers`).
- A versão MySQL/VPS (pasta `backend/`) **não** recebeu este módulo.
- Teste local: `node worker/smoke.test.mjs`.

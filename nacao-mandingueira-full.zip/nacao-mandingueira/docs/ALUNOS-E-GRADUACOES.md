# Alunos e graduações — guia para quem não programa

Tudo no painel (`seusite/admin/`). Menus: **Graduações** e **Alunos**.

## 1. Defina as graduações do grupo (uma vez)
Menu **Graduações** → Novo. Cadastre as graduações do **seu** sistema, uma a uma:
- **Nome** (como o grupo chama).
- **Ordem**: um número que define a sequência (1, 2, 3…). Cada grupo monta a sua; o sistema não impõe cores nem nomes.
- Cor e descrição são opcionais. Deixe **Ativa** marcada.
Graduação que já aparece no histórico de algum aluno **não pode ser excluída**; use **Desativar**.

## 2. Cadastre um aluno
Menu **Alunos** → Novo: nome, apelido, graduação inicial, data de entrada, nascimento, telefone, responsável (se menor), foto e **observações internas** (o aluno nunca vê).
- Se já existir alguém com o mesmo nome, o painel avisa. Se for outra pessoa, confirme "Cadastrar mesmo assim". Alunos com datas de nascimento diferentes não geram aviso.
- Ao salvar, o histórico já recebe "Entrada no grupo".

## 3. Evolução do aluno
Abra o aluno (botão **Editar**):
- **Registrar graduação**: escolha a nova graduação e a data. Fica gravado "de → para", a data e quem registrou. A graduação **só muda por aqui**, para não perder o histórico.
- **Histórico de evolução**: adicione eventos, trocas de corda, participações ou observações. Marque se o **aluno vê** ou se é **interno**.
- **Desativar / Reativar**: o aluno some das listas de ativos, mas **nada é apagado**. Não existe botão de excluir aluno.

## 4. Pesquisar e filtrar
Na lista de alunos: pesquise por **nome ou apelido**, filtre por **graduação** e por **situação** (ativos/inativos). **Baixar lista (CSV)** gera uma planilha do que está na tela.

## 5. Dar acesso ao aluno (Área do aluno)
Na página do aluno → **Acesso do aluno ao site**: informe e-mail e uma senha inicial (10+ caracteres, letras e números) → **Criar acesso**. Passe ao aluno (ou ao responsável). Ele entra em `seusite/aluno/`, vê **somente os próprios dados** (graduação, data de entrada e o histórico marcado como visível), e pode trocar a senha.
Se esquecer a senha: **Definir nova senha** na mesma página.

## 6. Professores (somente consulta)
Em **Usuários**, mude a permissão de alguém para **professor**. Ele passa a ver a lista de alunos (nome, apelido, graduação, situação), **sem** telefone, nascimento, observações ou histórico, e **não pode alterar nada**.

## Quem pode o quê
| | Aluno | Professor | Administrador | Superadmin |
|---|---|---|---|---|
| Ver o próprio cadastro | ✔ | | | |
| Ver lista de alunos (limitada) | | ✔ | ✔ | ✔ |
| Cadastrar/editar alunos e graduações | | | ✔ | ✔ |
| Dados completos dos alunos | | | ✔ | ✔ |
| Mudar permissões de usuários | | | | ✔ |
Tudo é verificado no servidor, não só escondido na tela.

## Cuidados com dados pessoais
- Há dados de pessoas e de **menores de idade**. Cadastre só o necessário e dê acesso apenas a quem precisa.
- Use sempre o endereço `https://`. Não passe senhas em grupos abertos.
- O arquivo de **backup contém os dados dos alunos**: guarde em local seguro e não compartilhe. (Os logins dos alunos não entram no backup; depois de restaurar, crie o acesso de novo.)
- Em **modo teste** os dados ficam só no seu navegador. Antes de usar com alunos de verdade, coloque o servidor no ar (`docs/COMECE-AQUI.md`).
- Isto é orientação técnica, não consultoria jurídica; para a LGPD, consulte um profissional.

## O que ainda não existe (próximas fases)
Frequência (chamada), financeiro, comunicados e relatórios em PDF. A área do aluno ainda mostra só cadastro e evolução.

## Erros comuns
- **"Já existe um aluno chamado…"**: é aviso de duplicidade; confirme só se for outra pessoa.
- **"Use Registrar graduação"**: a graduação não se altera pelo formulário principal.
- **"Graduação consta no histórico…"**: desative em vez de excluir.
- **Aluno não consegue entrar**: confirme se o acesso foi criado e se o e-mail e a senha estão certos; defina nova senha.
- **"Seu acesso ainda não está ligado a um cadastro"**: aconteceu após restaurar um backup; recrie o acesso na página do aluno.

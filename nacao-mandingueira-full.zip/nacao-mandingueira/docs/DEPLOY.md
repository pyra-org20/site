# Publicação

Arquitetura recomendada: **site e painel no Cloudflare Pages** (gratuito) e **API + MySQL + fotos em um VPS**. Use o mesmo domínio: `seudominio.com.br` (site) e `api.seudominio.com.br` (API). Confira preços atuais nos provedores antes de contratar.

## 1. VPS (Ubuntu 22.04/24.04)
```bash
sudo apt update && sudo apt install -y mysql-server nginx certbot python3-certbot-nginx git
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
sudo mysql_secure_installation
```
Crie o banco e o usuário (veja o README, passo 1). Aponte o DNS `api.seudominio.com.br` para o IP do VPS.

## 2. Backend
```bash
sudo adduser --system --group nacao && cd /opt
sudo git clone SEU_REPOSITORIO nacao && sudo chown -R nacao:nacao nacao
cd nacao/backend && sudo -u nacao npm ci --omit=dev
sudo -u nacao cp .env.example .env && sudo -u nacao nano .env && sudo chmod 600 .env
sudo -u nacao npm run db:migrate && sudo -u nacao npm run admin:create
```
Valores de produção no `.env`: `NODE_ENV=production`, `CORS_ORIGINS=https://seudominio.com.br`, `FRONTEND_URL=https://seudominio.com.br`, `COOKIE_SAMESITE=lax`, `COOKIE_SECURE=true`, `UPLOAD_DIR=/var/lib/nacao/uploads` (crie com `sudo mkdir -p /var/lib/nacao/uploads && sudo chown nacao:nacao /var/lib/nacao/uploads`). Depois apague `SUPERADMIN_PASSWORD`.

Serviço `/etc/systemd/system/nacao-api.service`:
```ini
[Unit]
Description=API Nação Mandingueira
After=network.target mysql.service

[Service]
User=nacao
WorkingDirectory=/opt/nacao/backend
ExecStart=/usr/bin/node src/server.js
Restart=always
EnvironmentFile=/opt/nacao/backend/.env

[Install]
WantedBy=multi-user.target
```
`sudo systemctl enable --now nacao-api` · logs: `journalctl -u nacao-api -f`

## 3. Nginx e HTTPS
`/etc/nginx/sites-available/nacao-api`:
```nginx
server {
  server_name api.seudominio.com.br;
  client_max_body_size 6m;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/nacao-api /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d api.seudominio.com.br
```
Libere só as portas 22, 80 e 443 no firewall. O MySQL deve aceitar conexões apenas locais.

## 4. Frontend no Cloudflare Pages
1. Edite `frontend/config.js` → `API_URL: 'https://api.seudominio.com.br'`.
2. Em `frontend/_headers`, troque `api.SEUDOMINIO.com.br` pelo endereço da API.
3. Envie o projeto ao GitHub (o `.env` não vai: está no `.gitignore`).
4. Cloudflare Pages → Create project → conectar o repositório. **Build command:** vazio. **Output directory:** `frontend`.
5. Adicione o domínio `seudominio.com.br` ao projeto.
6. Gere o sitemap (`npm run sitemap` no backend, com `FRONTEND_URL` correto), faça commit e ative a linha `Sitemap:` do `robots.txt`.

Se preferir GitHub Pages para o frontend, funciona igual (é só arquivo estático), mas o arquivo `_headers` não é lido por ele.

## 5. Atualizar e fazer backup
Atualizar: `cd /opt/nacao && sudo -u nacao git pull && cd backend && sudo -u nacao npm ci --omit=dev && sudo systemctl restart nacao-api`.

Backup diário (crontab): `mysqldump -u nacao -p'SENHA' nacao_mandingueira | gzip > /var/backups/nacao-$(date +\%F).sql.gz` e cópia da pasta de uploads. Guarde cópias **fora** do VPS e teste a restauração.

## 6. Checklist final
- [ ] HTTPS ativo no site e na API
- [ ] `JWT_SECRET` forte; `.env` com permissão 600; `SUPERADMIN_PASSWORD` apagada
- [ ] Login, saída e criação de evento testados no celular
- [ ] Formulário de contato gravando e a mensagem aparecendo no painel
- [ ] Backup do banco e das fotos funcionando

# Grupo Nação Mandingueira — Site oficial

Site institucional do Grupo Nação Mandingueira (capoeira, Fortaleza, Ceará) com painel administrativo, API REST e banco MySQL.

## Como o projeto é organizado
```
nacao-mandingueira/
  frontend/   site público (HTML/CSS/JS) e painel em /admin
  backend/    API Node.js + Express
  database/   schema.sql e seeds.sql
  docs/       API.md, SEGURANCA.md, DEPLOY.md
```
Frontend, backend e banco são independentes: cada um pode ficar em um lugar diferente. O GitHub Pages **não** roda Node nem MySQL; por isso o backend e o banco precisam de outro serviço (veja `docs/DEPLOY.md`).

## Tecnologias
Node.js 18+ · Express 4 · MySQL 8+ · mysql2 · bcrypt (bcryptjs) · JWT em cookie HttpOnly · Zod · Helmet · HTML, CSS e JavaScript puros no frontend.

## Requisitos
Node.js 18 ou superior, MySQL 8 ou superior e Git.

## Instalação local
1. **MySQL.** Crie o banco e um usuário:
   ```sql
   CREATE DATABASE nacao_mandingueira CHARACTER SET utf8mb4;
   CREATE USER 'nacao'@'localhost' IDENTIFIED BY 'TROQUE_ESTA_SENHA';
   GRANT ALL PRIVILEGES ON nacao_mandingueira.* TO 'nacao'@'localhost';
   ```
2. **Backend.**
   ```bash
   cd backend
   cp .env.example .env      # preencha DB_USER, DB_PASSWORD e JWT_SECRET
   npm install
   npm run db:migrate        # cria as tabelas e os dados iniciais
   ```
   Gere o `JWT_SECRET` com `openssl rand -hex 32`.
3. **Primeiro administrador.** No `.env`, preencha `SUPERADMIN_NAME`, `SUPERADMIN_EMAIL` e `SUPERADMIN_PASSWORD` (mínimo 10 caracteres, com letra e número), depois:
   ```bash
   npm run admin:create
   ```
   Em seguida **apague `SUPERADMIN_PASSWORD` do `.env`**.
4. **Rodar a API.** `npm run dev` (http://localhost:3000). Teste em http://localhost:3000/api/health.
5. **Frontend.** Em outro terminal: `python3 -m http.server 5173 -d frontend` (ou `npx serve frontend -l 5173`).
   - Site: http://localhost:5173
   - Painel: http://localhost:5173/admin/

## Variáveis de ambiente (backend/.env)
| Variável | Para que serve |
|---|---|
| `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `DB_SSL` | Conexão com o MySQL |
| `JWT_SECRET` | Segredo da sessão (mínimo 32 caracteres) |
| `SESSION_DAYS` | Duração do login |
| `CORS_ORIGINS` | Endereços do site que podem chamar a API |
| `FRONTEND_URL` | Endereço público do site (links de e-mail e sitemap) |
| `COOKIE_SAMESITE`, `COOKIE_SECURE` | `lax` se site e API estão no mesmo domínio; `none` com HTTPS se estiverem em domínios diferentes |
| `UPLOAD_DIR` | Pasta das imagens (use disco persistente) |
| `GOOGLE_*` | Login Google; vazio = desativado |
| `SMTP_*` | E-mail de recuperação de senha; vazio = o link aparece só no log |

## Comandos
`npm run dev` · `npm start` · `npm run db:migrate` · `npm run admin:create` · `npm run sitemap` · `npm test`

## Depois de instalar: primeiros passos no painel
1. Entre em `/admin/` com o superadministrador.
2. Em **Configurações**, preencha nome, WhatsApp, Instagram, endereço e mapa.
3. Cadastre professores, aulas e horários, eventos e fotos.
4. Em **Páginas**, edite "Nossa História" e publique. Escreva apenas fatos confirmados pelo grupo.

## Login com Google (opcional)
Crie as credenciais OAuth 2.0 no Google Cloud Console, informe a URL de retorno `https://api.SEUDOMINIO/api/auth/google/callback` e preencha `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` e `GOOGLE_REDIRECT_URI`. Sem os três, a rota responde "não configurado".

## Deploy
Veja `docs/DEPLOY.md`.

## Solução de problemas
- **"Variável de ambiente ausente"**: falta preencher algo no `.env`.
- **A API não sobe e fala do banco**: confira usuário, senha e se o MySQL está ativo.
- **Erro de CORS no navegador**: o endereço do site precisa estar em `CORS_ORIGINS`, sem barra no final.
- **Login funciona mas o painel volta para o login**: cookie bloqueado. Com site e API em domínios diferentes, use `COOKIE_SAMESITE=none`, HTTPS e `COOKIE_SECURE=true`.
- **"Token CSRF ausente"**: recarregue o painel; o token é renovado no login.
- **Imagem não aparece**: confira se `API_URL` em `frontend/config.js` está correto e se a pasta de uploads existe.
- **Upload recusado**: só JPG, PNG e WebP até 5 MB, e o arquivo precisa ser mesmo uma imagem.
- **Banco já criado antes da Fase 7**: adicione a coluna com `ALTER TABLE users ADD COLUMN password_changed_at DATETIME NULL;`.

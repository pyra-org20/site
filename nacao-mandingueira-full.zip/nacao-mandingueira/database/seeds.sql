-- Dados iniciais. Sem senhas, sem contatos e sem história inventada.
-- O primeiro superadministrador é criado por script do backend (Fase 3/4).
SET NAMES utf8mb4;

INSERT INTO roles (slug, name, level) VALUES
 ('aluno','Aluno',10),
 ('administrador','Administrador',50),
 ('superadministrador','Superadministrador',100)
ON DUPLICATE KEY UPDATE name = VALUES(name), level = VALUES(level);

INSERT INTO permissions (slug, description) VALUES
 ('profile.read','Ver o próprio perfil'),
 ('profile.write','Editar o próprio perfil'),
 ('content.write','Criar, editar, publicar e excluir páginas'),
 ('events.write','Gerenciar eventos'),
 ('gallery.write','Gerenciar álbuns e fotografias'),
 ('teachers.write','Gerenciar mestres e professores'),
 ('classes.write','Gerenciar aulas e horários'),
 ('messages.read','Ler mensagens de contato'),
 ('users.read','Listar e ver usuários'),
 ('users.write','Alterar permissões, suspender e reativar contas'),
 ('users.delete','Excluir contas'),
 ('settings.write','Alterar configurações do site'),
 ('audit.read','Ver logs administrativos')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- Aluno
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
WHERE r.slug='aluno' AND p.slug IN ('profile.read','profile.write');

-- Administrador
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
WHERE r.slug='administrador' AND p.slug IN
 ('profile.read','profile.write','content.write','events.write','gallery.write',
  'teachers.write','classes.write','messages.read','users.read');

-- Superadministrador: todas
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.slug='superadministrador';

-- Configurações: só o que é certo. Contatos ficam vazios até serem informados.
INSERT INTO site_settings (setting_key, setting_value) VALUES
 ('group_name','Grupo Nação Mandingueira'),
 ('tagline','Capoeira, tradição e comunidade em Fortaleza, Ceará.'),
 ('city','Fortaleza, Ceará, Brasil'),
 ('whatsapp',''),
 ('instagram',''),
 ('address',''),
 ('map_embed_url',''),
 ('emblem_url',''),
 ('seo_title','Grupo Nação Mandingueira — Capoeira em Fortaleza, Ceará'),
 ('seo_description','Site oficial do Grupo Nação Mandingueira, grupo de capoeira de Fortaleza, Ceará.')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- Páginas-base em rascunho, para o administrador preencher.
INSERT INTO pages (slug, title, content, is_published) VALUES
 ('nossa-historia','Nossa História',NULL,0)
ON DUPLICATE KEY UPDATE slug = slug;

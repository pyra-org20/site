const API = window.APP_CONFIG.API_URL.replace(/\/$/, '');
export const imgUrl = (u) => (u && u.startsWith('/uploads') ? API + u : u && u.startsWith('https://') ? u : '');
export async function get(path) {
  const r = await fetch(`${API}/api${path}`);
  if (!r.ok) throw new Error(String(r.status));
  return (await r.json()).data;
}
export async function post(path, body) {
  const r = await fetch(`${API}/api${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(data.error || 'Erro ao enviar.'), { fields: data.fields });
  return data;
}

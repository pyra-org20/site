import { get, imgUrl } from './api.js';
import { h, whatsappLink } from './safe.js';

const main = document.getElementById('main');
const DAYS = ['', 'Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const ORDER = [2, 3, 4, 5, 6, 7, 1];
const hm = (t) => { const [H, M] = t.split(':'); return M === '00' ? `${+H}h` : `${+H}h${M}`; };
const range = (s) => `${hm(s.start_time)}–${hm(s.end_time)}`;
const norm = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const tName = (t) => (t.nickname ? `${t.name} (${t.nickname})` : t.name);
const period = (t) => { const H = +t.split(':')[0]; return H < 12 ? 'manha' : H < 18 ? 'tarde' : 'noite'; };
const PERIODS = [['manha', 'Manhã (até 12h)'], ['tarde', 'Tarde (12h às 18h)'], ['noite', 'Noite (a partir de 18h)']];
let units = [], F = { q: '', bairro: '', unidade: '', dia: '', periodo: '', faixa: '', nivel: '', prof: '' };

// ---------- links de mapa e contato (só a partir de valores validados) ----------
function mapQuery(u) {
  const lat = Number(u.latitude), lng = Number(u.longitude);
  if (u.latitude != null && u.longitude != null && Number.isFinite(lat) && Number.isFinite(lng)) return `${lat},${lng}`;
  const a = [u.address, u.neighborhood, u.city, u.state].filter(Boolean).join(', ');
  return a || null;
}
const mapLink = (u) => { const q = mapQuery(u); return q ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}` : null; };
const routeLink = (u) => { const q = mapQuery(u); return q ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(q)}` : null; };
const embedSrc = (u) => { const q = mapQuery(u); return q ? `https://www.google.com/maps?q=${encodeURIComponent(q)}&output=embed` : null; };
const telLink = (v) => { const d = String(v || '').replace(/[^\d+]/g, ''); return /^\+?\d{8,15}$/.test(d) ? `tel:${d}` : null; };
const addr = (u) => [u.address, u.neighborhood, [u.city, u.state].filter(Boolean).join('/')].filter(Boolean).join(' · ');
const setMeta = (title, desc) => {
  document.title = title;
  for (const [sel, v] of [['meta[name=description]', desc], ['meta[property="og:title"]', title]]) { const m = document.querySelector(sel); if (m && v) m.content = v; }
};
const msg = (t, d) => h('div', { class: 'vazio' }, h('h3', {}, t), h('p', {}, d));
const link = (cls, href, text, ext = true) => (href ? h('a', { class: cls, href, ...(ext ? { target: '_blank', rel: 'noopener noreferrer' } : {}) }, text) : '');

// ---------- listagem ----------
const classMatches = (k, s) => (!F.faixa || k.age_group === F.faixa) && (!F.nivel || k.level === F.nivel) && (!F.prof || k.teachers.some((t) => String(t.id) === F.prof))
  && (!F.dia || String(s.weekday) === F.dia) && (!F.periodo || period(s.start_time) === F.periodo);
const classFilters = () => F.faixa || F.nivel || F.prof || F.dia || F.periodo;
function results() {
  const toks = norm(F.q).split(/\s+/).filter(Boolean), out = [];
  for (const u of units) {
    if (F.bairro && u.neighborhood !== F.bairro) continue;
    if (F.unidade && String(u.id) !== F.unidade) continue;
    const rows = [];
    for (const k of u.classes) for (const s of k.schedules) if (classMatches(k, s)) rows.push({ k, s });
    if (classFilters() && !rows.length) continue;
    const hay = norm([u.name, u.neighborhood, u.city, u.address, u.reference, u.responsible && tName(u.responsible), ...u.classes.flatMap((k) => [k.name, k.modality, ...k.teachers.map(tName)])].join(' '));
    if (toks.some((t) => !hay.includes(t))) continue;
    out.push({ u, rows: rows.sort((a, b) => ORDER.indexOf(a.s.weekday) - ORDER.indexOf(b.s.weekday) || a.s.start_time.localeCompare(b.s.start_time)) });
  }
  return out;
}
function card({ u, rows }) {
  const sede = u.type === 'sede', shown = rows.slice(0, 6);
  const profs = [...new Map([...(u.responsible ? [u.responsible] : []), ...u.classes.flatMap((k) => k.teachers)].map((t) => [t.id, t])).values()];
  return h('article', { class: 'ucard' + (sede ? ' sede' : '') },
    imgUrl(u.image_url) ? h('img', { src: imgUrl(u.image_url), alt: `Fotografia de ${u.name}`, loading: 'lazy' }) : h('div', { class: 'noimg', 'aria-hidden': 'true' }),
    h('div', { class: 'body' },
      h('p', { class: 'badges' }, h('span', { class: 'badge' + (sede ? ' gold' : '') }, sede ? 'Sede principal' : 'Núcleo'), h('span', { class: 'badge ok' }, 'Em funcionamento')),
      h('h3', {}, h('a', { href: '#' + u.slug }, u.name)),
      addr(u) ? h('p', { class: 'small' }, addr(u)) : '', u.reference ? h('p', { class: 'small' }, 'Referência: ' + u.reference) : '',
      profs.length ? h('p', { class: 'small' }, 'Professores: ' + profs.map(tName).join(', ')) : '',
      shown.length ? h('ul', { class: 'sched' }, shown.map(({ k, s }) => h('li', {}, h('b', {}, DAYS[s.weekday]), ` ${range(s)} · ${k.name}`)), rows.length > shown.length ? h('li', {}, `+ ${rows.length - shown.length} horários`) : '')
        : h('p', { class: 'small' }, u.classes.length ? 'Veja os horários na página da unidade.' : 'Horários ainda não publicados.'),
      h('div', { class: 'btns left' }, h('a', { class: 'btn cheio', href: '#' + u.slug }, 'Ver unidade'), link('btn', routeLink(u), 'Como chegar'), link('btn', whatsappLink(u.whatsapp), 'WhatsApp'))));
}
function listView() {
  setMeta('Onde treinar capoeira? Sedes e horários — Grupo Nação Mandingueira', 'Encontre a sede e os núcleos do Grupo Nação Mandingueira: endereços, turmas, horários e professores.');
  const uniq = (a) => [...new Set(a.filter(Boolean))].sort((x, y) => x.localeCompare(y));
  const bairros = uniq(units.map((u) => u.neighborhood)), faixas = uniq(units.flatMap((u) => u.classes.map((k) => k.age_group))), niveis = uniq(units.flatMap((u) => u.classes.map((k) => k.level)));
  const profs = [...new Map(units.flatMap((u) => [u.responsible, ...u.classes.flatMap((k) => k.teachers)]).filter(Boolean).map((t) => [t.id, t])).values()].sort((a, b) => a.name.localeCompare(b.name));
  const days = ORDER.filter((d) => units.some((u) => u.classes.some((k) => k.schedules.some((s) => s.weekday === d))));
  const list = h('div', { class: 'ugrid' }), count = h('p', { class: 'small', 'aria-live': 'polite' });
  const render = () => {
    const r = results(); count.textContent = r.length ? `${r.length} ${r.length === 1 ? 'unidade encontrada' : 'unidades encontradas'}` : '';
    list.replaceChildren(...(r.length ? r.map(card) : [h('div', { class: 'vazio' }, h('h3', {}, 'Nenhum resultado'), h('p', {}, 'Tente outro nome, bairro ou remova alguns filtros.'),
      h('button', { class: 'btn', type: 'button', onclick: clear }, 'Limpar filtros'))]));
  };
  const sel = (key, label, opts) => { const s = h('select', { id: 'f_' + key }, [h('option', { value: '' }, 'Todos'), ...opts.map(([v, l]) => h('option', { value: v }, l))]); s.value = F[key]; s.onchange = () => { F[key] = s.value; render(); }; return h('label', {}, label, s); };
  const q = h('input', { type: 'search', placeholder: 'Núcleo, professor, turma ou bairro', 'aria-label': 'Pesquisar', autocomplete: 'off' }); q.value = F.q; q.oninput = () => { F.q = q.value; render(); };
  const clear = () => { F = { q: '', bairro: '', unidade: '', dia: '', periodo: '', faixa: '', nivel: '', prof: '' }; listView(); };
  main.replaceChildren(h('div', { class: 'wrap sec' }, h('h1', {}, 'Onde treinar capoeira?'),
    h('p', { class: 'lead' }, 'Encontre a sede e os núcleos do Grupo Nação Mandingueira, com endereços, turmas, horários e professores.'),
    h('div', { class: 'filters' }, h('label', { class: 'wide' }, 'Pesquisar', q), sel('bairro', 'Bairro', bairros.map((b) => [b, b])), sel('unidade', 'Unidade', units.map((u) => [u.id, u.name])),
      sel('dia', 'Dia da semana', days.map((d) => [d, DAYS[d]])), sel('periodo', 'Horário', PERIODS), sel('faixa', 'Faixa etária', faixas.map((f) => [f, f])), sel('nivel', 'Nível', niveis.map((n) => [n, n])),
      sel('prof', 'Professor', profs.map((t) => [t.id, tName(t)])), h('button', { class: 'btn', type: 'button', onclick: clear }, 'Limpar filtros')), count, list));
  render();
}

// ---------- unidade ----------
async function detailView(slug) {
  main.replaceChildren(h('div', { class: 'wrap sec' }, h('p', { class: 'load' }, 'Carregando…')));
  let u; try { u = await get('/units/' + encodeURIComponent(slug)); } catch (e) {
    main.replaceChildren(h('div', { class: 'wrap sec' }, msg(e.message === '404' ? 'Unidade não encontrada' : 'Não foi possível carregar', 'Volte à lista e escolha outra unidade.'), h('p', {}, h('a', { class: 'btn', href: '#' }, 'Voltar às unidades')))); return;
  }
  setMeta(`${u.name} — Capoeira em ${u.city || 'Fortaleza'} | Grupo Nação Mandingueira`, (u.description || `Endereço, turmas e horários de ${u.name}.`).slice(0, 160));
  const sede = u.type === 'sede', rows = u.classes.flatMap((k) => k.schedules.map((s) => ({ k, s }))).sort((a, b) => ORDER.indexOf(a.s.weekday) - ORDER.indexOf(b.s.weekday) || a.s.start_time.localeCompare(b.s.start_time));
  const tel = telLink(u.phone), em = embedSrc(u);
  const who = (k) => (k.teachers.length ? k.teachers.map(tName).join(', ') : u.responsible ? tName(u.responsible) : '—');
  main.replaceChildren(h('div', { class: 'wrap sec' }, h('p', {}, h('a', { href: '#' }, '← Todas as unidades')),
    h('p', { class: 'badges' }, h('span', { class: 'badge' + (sede ? ' gold' : '') }, sede ? 'Sede principal' : 'Núcleo'), h('span', { class: 'badge ok' }, 'Em funcionamento')),
    h('h1', {}, u.name),
    h('div', { class: 'duas' },
      h('div', {}, imgUrl(u.image_url) ? h('img', { class: 'hero-img', src: imgUrl(u.image_url), alt: `Fotografia de ${u.name}` }) : '', u.description ? h('p', {}, u.description) : '',
        u.responsible ? h('p', {}, h('b', {}, 'Responsável: '), tName(u.responsible), u.responsible.graduation ? ` · ${u.responsible.graduation}` : '') : ''),
      h('div', { class: 'card info' }, h('h2', {}, 'Como chegar'),
        addr(u) ? h('p', {}, addr(u)) : h('p', { class: 'small' }, 'Endereço ainda não informado.'), u.cep ? h('p', { class: 'small' }, 'CEP ' + u.cep) : '', u.reference ? h('p', { class: 'small' }, 'Referência: ' + u.reference) : '',
        h('div', { class: 'btns left' }, link('btn cheio', routeLink(u), 'Como chegar'), link('btn', mapLink(u), 'Abrir no Google Maps'), link('btn', whatsappLink(u.whatsapp), 'WhatsApp'), link('btn', tel, 'Ligar', false)),
        em ? h('iframe', { src: em, title: `Mapa de ${u.name}`, loading: 'lazy', referrerpolicy: 'no-referrer', class: 'map' }) : '')),
    h('h2', {}, 'Turmas'), u.classes.length ? h('div', { class: 'grid' }, u.classes.map((k) => h('article', { class: 'card' }, h('div', { class: 'body' }, h('h3', {}, k.name),
      h('p', { class: 'meta' }, [k.age_group, k.level, k.modality].filter(Boolean).join(' · ')), k.description ? h('p', {}, k.description) : '', k.capacity ? h('p', { class: 'small' }, `Capacidade: ${k.capacity} alunos`) : '',
      h('p', { class: 'small' }, 'Responsável: ' + who(k)))))) : msg('Turmas ainda não publicadas', 'As turmas desta unidade serão exibidas aqui.'),
    h('h2', { style: 'margin-top:2rem' }, 'Grade semanal'),
    rows.length ? h('table', { class: 'grade' }, h('thead', {}, h('tr', {}, ['Dia', 'Horário', 'Turma', 'Responsável'].map((t) => h('th', {}, t)))),
      h('tbody', {}, rows.map(({ k, s }) => h('tr', {}, h('td', { 'data-label': 'Dia' }, DAYS[s.weekday]), h('td', { 'data-label': 'Horário' }, range(s)), h('td', { 'data-label': 'Turma' }, k.name + (s.notes ? ` — ${s.notes}` : '')), h('td', { 'data-label': 'Responsável' }, who(k))))))
      : msg('Horários ainda não publicados', 'Fale com a unidade para saber os dias e horários.'),
    u.images?.length ? [h('h2', { style: 'margin-top:2rem' }, 'Fotografias'), h('div', { class: 'thumbs' }, u.images.map((im) => h('img', { src: imgUrl(im.image_url), alt: im.description || `Fotografia de ${u.name}`, loading: 'lazy' })))] : ''));
  window.scrollTo(0, 0);
}

// ---------- início ----------
async function route() { const slug = decodeURIComponent(location.hash.slice(1)); if (slug) await detailView(slug); else listView(); }
try { units = await get('/units'); } catch { main.replaceChildren(h('div', { class: 'wrap sec' }, h('p', { class: 'fail' }, 'Não foi possível carregar as unidades agora. Tente novamente em instantes.'))); }
if (units.length || !main.querySelector('.fail')) {
  if (!units.length && !location.hash) main.replaceChildren(h('div', { class: 'wrap sec' }, h('h1', {}, 'Onde treinar capoeira?'), msg('Unidades em breve', 'A sede e os núcleos do grupo serão apresentados aqui assim que forem cadastrados.')));
  else route();
}
window.addEventListener('hashchange', route);

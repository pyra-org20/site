import { get, post, imgUrl } from './api.js';
import { h, sanitize, whatsappLink, instagramLink, mapSrc } from './safe.js';

const $ = (id) => document.getElementById(id);
const DAYS = ['', 'Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
const fmtDate = (s) => new Date(s.slice(0, 10) + 'T12:00:00').toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
const hm = (t) => (t ? t.slice(0, 5) : '');
const fail = (el) => el.replaceChildren(h('p', { class: 'fail' }, 'Não foi possível carregar esta seção agora. Tente novamente em instantes.'));
const empty = (el, t, d) => el.replaceChildren(h('div', { class: 'vazio' }, h('h3', {}, t), h('p', {}, d)));
const para = (t) => (t ? h('p', {}, t) : '');

function settings(s) {
  if (s.group_name) { $('gname').textContent = s.group_name; $('navname').textContent = s.group_name; }
  if (s.tagline) $('tagline').textContent = s.tagline;
  if (imgUrl(s.emblem_url)) $('emblem').src = imgUrl(s.emblem_url);
  if (s.seo_title) document.title = s.seo_title;
  if (s.seo_description) document.querySelector('meta[name=description]').content = s.seo_description;
  const box = $('contactinfo'), items = [];
  const wa = whatsappLink(s.whatsapp), ig = instagramLink(s.instagram), map = mapSrc(s.map_embed_url);
  if (wa) items.push(h('p', {}, 'WhatsApp: ', h('a', { href: wa, rel: 'noopener', target: '_blank' }, 'conversar agora')));
  if (ig) items.push(h('p', {}, 'Instagram: ', h('a', { href: ig.url, rel: 'noopener', target: '_blank' }, ig.handle)));
  if (s.address) items.push(h('p', {}, 'Endereço: ', s.address));
  if (map) items.push(h('iframe', { src: map, title: 'Mapa do local', loading: 'lazy', style: 'width:100%;height:260px;border:0', referrerpolicy: 'no-referrer' }));
  box.replaceChildren(...(items.length ? items : [h('p', {}, 'Use o formulário para falar com o grupo.')]));
}
function history(p) {
  const box = $('history');
  if (!p?.content) return empty(box, 'História em breve', 'O texto sobre a fundação, a trajetória e a filosofia do grupo será publicado aqui.');
  const parts = p.content.split(/\n{2,}/).map((x) => x.trim()).filter(Boolean);
  box.replaceChildren(...parts.map((x) => (x.startsWith('# ') ? h('h3', {}, x.slice(2)) : h('p', {}, x))));
}
function classes(list) {
  const box = $('classes');
  if (!list.length) return empty(box, 'Horários ainda não publicados', 'Dias, horários e local das aulas aparecerão aqui. Enquanto isso, fale com o grupo pelo contato.');
  box.replaceChildren(...list.map((c) => h('article', { class: 'classcard' }, h('h3', {}, c.name), para(c.description),
    c.schedules?.length ? h('ul', { class: 'sched' }, c.schedules.map((s) => h('li', {}, `${DAYS[s.weekday]}, ${hm(s.start_time)} às ${hm(s.end_time)}`))) : '',
    c.location ? h('p', { class: 'meta' }, 'Local: ' + c.location) : '',
    c.beginner_info ? h('p', {}, h('b', {}, 'Para iniciantes: '), c.beginner_info) : '', c.student_info ? h('p', {}, h('b', {}, 'Para alunos: '), c.student_info) : '',
    c.how_to_join ? h('p', {}, h('b', {}, 'Como participar: '), c.how_to_join) : '')));
}
function teachers(list) {
  const box = $('teachers');
  if (!list.length) return empty(box, 'Perfis em breve', 'Mestres e professores serão apresentados aqui.');
  box.replaceChildren(...list.map((t) => h('article', { class: 'card' }, imgUrl(t.photo_url) ? h('img', { src: imgUrl(t.photo_url), alt: `Fotografia de ${t.name}`, loading: 'lazy' }) : '',
    h('div', { class: 'body' }, h('h3', {}, t.name), t.graduation ? h('p', { class: 'meta' }, t.graduation) : '', t.specialty ? h('p', { class: 'small' }, 'Especialidade: ' + t.specialty) : '',
      t.experience_years != null ? h('p', { class: 'small' }, `${t.experience_years} anos de experiência`) : '', para(t.bio), para(t.extra_info)))));
}
const eventCard = (e) => h('article', { class: 'card' }, imgUrl(e.cover_image_url) ? h('img', { src: imgUrl(e.cover_image_url), alt: '', loading: 'lazy' }) : '',
  h('div', { class: 'body' }, h('h3', {}, e.title), h('p', { class: 'meta' }, fmtDate(e.event_date) + (e.start_time ? ` · ${hm(e.start_time)}` : '') + (e.end_time ? ` às ${hm(e.end_time)}` : '')),
    e.location ? h('p', { class: 'small' }, 'Local: ' + e.location) : '', para(e.description), para(e.extra_info)));
function events(up, past) {
  up.length ? $('events').replaceChildren(...up.map(eventCard)) : empty($('events'), 'Nenhum evento programado', 'Os próximos eventos aparecerão aqui.');
  if (past.length) { $('past').hidden = false; $('pastlist').replaceChildren(...past.map(eventCard)); }
}

// Galeria com visualização ampliada
const dlg = $('viewer');
const closeBtn = () => h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Fechar');
function openAlbum(a) {
  const imgs = a.images || [];
  const grid = () => dlg.replaceChildren(h('h3', {}, a.title), para(a.description),
    imgs.length ? h('div', { class: 'thumbs' }, imgs.map((im, i) => h('button', { type: 'button', 'aria-label': `Ampliar foto ${i + 1}`, onclick: () => big(i) }, h('img', { src: imgUrl(im.image_url), alt: im.description || '', loading: 'lazy' }))))
      : h('p', { class: 'vazio' }, 'Este álbum ainda não tem fotografias.'), h('div', { class: 'row' }, closeBtn()));
  const big = (i) => {
    const n = (i + imgs.length) % imgs.length;
    dlg.replaceChildren(h('img', { class: 'big', src: imgUrl(imgs[n].image_url), alt: imgs[n].description || '' }), para(imgs[n].description),
      h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => big(n - 1) }, 'Anterior'), h('button', { class: 'btn', type: 'button', onclick: () => big(n + 1) }, 'Próxima'),
        h('button', { class: 'btn', type: 'button', onclick: grid }, 'Voltar ao álbum'), closeBtn()));
    dlg.onkeydown = (e) => { if (e.key === 'ArrowRight') big(n + 1); if (e.key === 'ArrowLeft') big(n - 1); };
  };
  grid(); dlg.showModal();
}
function albums(list) {
  const box = $('albums');
  if (!list.length) return empty(box, 'Nenhuma fotografia publicada', 'Álbuns de treinos, rodas e apresentações serão exibidos aqui.');
  box.replaceChildren(...list.map((a) => h('button', { class: 'card album', type: 'button', onclick: async (ev) => {
    const b = ev.currentTarget; b.disabled = true;
    try { openAlbum(await get(`/gallery/albums/${a.slug}`)); } catch { b.append(h('span', { class: 'body small' }, 'Falha ao abrir. Tente de novo.')); } finally { b.disabled = false; }
  } }, imgUrl(a.cover_image_url) ? h('img', { src: imgUrl(a.cover_image_url), alt: '', loading: 'lazy' }) : '', h('div', { class: 'body' }, h('h3', {}, a.title), h('p', { class: 'meta' }, a.category)))));
}

// Formulário de contato
const form = $('cform');
form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const st = $('cstatus'), btn = form.querySelector('button'); st.className = ''; st.textContent = '';
  form.querySelectorAll('.erro').forEach((e) => (e.textContent = ''));
  const d = Object.fromEntries(new FormData(form));
  const bad = {};
  if (d.name.trim().length < 2) bad.name = 'Informe seu nome.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) bad.email = 'Informe um e-mail válido.';
  if (d.message.trim().length < 10) bad.message = 'Escreva ao menos 10 caracteres.';
  for (const [k, m] of Object.entries(bad)) form.elements[k].parentElement.querySelector('.erro').textContent = m;
  if (Object.keys(bad).length) return;
  btn.disabled = true; btn.textContent = 'Enviando…';
  try { const r = await post('/contact', d); st.className = 'ok'; st.textContent = r.message; form.reset(); }
  catch (e) { st.textContent = e.fields?.map((f) => f.message).join(' ') || e.message; }
  finally { btn.disabled = false; btn.textContent = 'Enviar mensagem'; }
});

// Carrega tudo em paralelo; cada seção falha de forma independente
const run = (p, ok, el) => p.then(ok).catch(() => el && fail(el));
run(get('/settings'), settings);
run(get('/pages/nossa-historia').catch((e) => (e.message === '404' ? null : Promise.reject(e))), history, $('history'));
run(get('/classes'), classes, $('classes'));
run(get('/teachers'), teachers, $('teachers'));
run(Promise.all([get('/events?when=upcoming'), get('/events?when=past')]), ([u, p]) => events(u, p), $('events'));
run(get('/gallery/albums'), albums, $('albums'));

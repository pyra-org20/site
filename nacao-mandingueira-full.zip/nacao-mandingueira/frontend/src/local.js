// MODO TESTE: roda a API do painel dentro do próprio navegador (dados no localStorage).
// Ativado quando config.js tem API_URL: 'local'. Os dados ficam só neste navegador.
import worker from '../local/worker.js';

const cfg = window.APP_CONFIG;
if (cfg && cfg.API_URL === 'local') {
  const ORIGIN = 'https://local.nacao', P = 'nm_kv:', M = 'nm_kvm:';
  let quota = false;
  const toB64 = (v) => { const u = new Uint8Array(v); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
  const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const DB = {
    async get(k, t) { const v = localStorage.getItem(P + k); if (v == null) return null; return t === 'json' ? JSON.parse(v) : t === 'arrayBuffer' ? fromB64(v).buffer : v; },
    async getWithMetadata(k, t) { return { value: await DB.get(k, t), metadata: JSON.parse(localStorage.getItem(M + k) || 'null') }; },
    async put(k, v, o = {}) {
      try { localStorage.setItem(P + k, typeof v === 'string' ? v : toB64(v)); if (o.metadata) localStorage.setItem(M + k, JSON.stringify(o.metadata)); }
      catch (e) { quota = true; throw e; }
    },
    async delete(k) { localStorage.removeItem(P + k); localStorage.removeItem(M + k); },
    async list({ prefix = '' } = {}) {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) { const n = localStorage.key(i); if (n.startsWith(P + prefix)) keys.push({ name: n.slice(P.length) }); }
      return { keys, list_complete: true };
    },
  };
  const realFetch = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const req = new Request(input, init);
    if (new URL(req.url).origin !== ORIGIN) return realFetch(input, init);
    quota = false;
    const res = await worker.fetch(req, { DB });
    if (res.status === 500 && quota) return new Response(JSON.stringify({ error: 'A memória do navegador está cheia. Apague fotos antigas ou baixe um backup.' }), { status: 507, headers: { 'Content-Type': 'application/json' } });
    return res;
  };
  cfg.API_URL = ORIGIN; cfg.local = true;

  // As imagens vêm da API local: troca o endereço por um blob para o navegador exibir.
  const cache = new Map();
  const fix = async (img) => {
    const src = img.getAttribute('src');
    if (!src || !src.startsWith(ORIGIN + '/uploads/')) return;
    try {
      let u = cache.get(src);
      if (!u) { const r = await window.fetch(src); if (!r.ok) return; u = URL.createObjectURL(await r.blob()); cache.set(src, u); }
      if (img.getAttribute('src') === src) img.src = u;
    } catch { /* ignora */ }
  };
  new MutationObserver((ms) => {
    for (const m of ms) {
      if (m.type === 'attributes') fix(m.target);
      else m.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.tagName === 'IMG') fix(n); n.querySelectorAll?.('img').forEach(fix); } });
    }
  }).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ['src'] });
}

// Criação de DOM sem innerHTML e sanitização de HTML vindo do painel (defesa em profundidade).
export const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) { if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v); }
  for (const c of kids.flat(Infinity)) e.append(c?.nodeType ? c : document.createTextNode(c === false || c == null ? '' : c));
  return e;
};
const TAGS = new Set(['P', 'H2', 'H3', 'H4', 'STRONG', 'EM', 'UL', 'OL', 'LI', 'BLOCKQUOTE', 'A', 'BR', 'IMG', 'FIGURE', 'FIGCAPTION']);
export function sanitize(html) {
  const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
  const out = document.createDocumentFragment();
  const walk = (node, parent) => {
    for (const n of [...node.childNodes]) {
      if (n.nodeType === 3) parent.append(n.textContent);
      else if (n.nodeType === 1 && TAGS.has(n.tagName)) {
        const e = document.createElement(n.tagName.toLowerCase());
        if (n.tagName === 'A' && /^(https:|mailto:)/i.test(n.getAttribute('href') || '')) { e.href = n.getAttribute('href'); e.rel = 'noopener noreferrer'; e.target = '_blank'; }
        if (n.tagName === 'IMG' && /^https:/i.test(n.getAttribute('src') || '')) { e.src = n.getAttribute('src'); e.alt = n.getAttribute('alt') || ''; e.loading = 'lazy'; }
        walk(n, e); parent.append(e);
      } else if (n.nodeType === 1 && !['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED'].includes(n.tagName)) walk(n, parent);
    }
  };
  walk(doc.body, out); return out;
}
// Links de contato só são montados a partir de valores validados.
export const whatsappLink = (v) => { const d = String(v || '').replace(/\D/g, ''); return /^\d{10,15}$/.test(d) ? `https://wa.me/${d}` : null; };
export const instagramLink = (v) => { const m = /^(?:https?:\/\/(?:www\.)?instagram\.com\/)?@?([A-Za-z0-9._]{1,30})\/?$/.exec(String(v || '').trim()); return m ? { url: `https://www.instagram.com/${m[1]}/`, handle: '@' + m[1] } : null; };
export const mapSrc = (v) => (/^https:\/\/(www\.google\.com\/maps\/embed|www\.openstreetmap\.org\/export\/embed)/.test(v || '') ? v : null);

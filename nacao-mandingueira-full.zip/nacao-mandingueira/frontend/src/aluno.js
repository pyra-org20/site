import { h } from './safe.js';
import { imgUrl } from './api.js';

const main = document.getElementById('main'), KEY = 'nm_token_aluno';
const API = () => window.APP_CONFIG.API_URL.replace(/\/$/, '');
const tok = { get: () => { try { return localStorage.getItem(KEY); } catch { return null; } }, set: (v) => { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch { /* ignora */ } } };
const fmt = (s) => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');
const TYPES = { entrada: 'Entrada', graduacao: 'Graduação', troca_corda: 'Troca de corda', evento: 'Evento', participacao: 'Participação' };

async function call(path, { method = 'GET', body } = {}) {
  let r;
  try { r = await fetch(`${API()}/api${path}`, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(tok.get() ? { Authorization: 'Bearer ' + tok.get() } : {}) }, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw Object.assign(new Error('Não foi possível conectar ao servidor.'), { status: 0 }); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.fields?.map?.((f) => f.message).join(' ') || d.error || 'Erro inesperado.'), { status: r.status });
  return d;
}
const wrap = (...k) => main.replaceChildren(h('div', { class: 'wrap sec' }, ...k));
const err = (id) => h('p', { class: 'erro', id, role: 'alert' });

function loginView(msg) {
  const email = h('input', { type: 'email', required: true, autocomplete: 'username' }), pass = h('input', { type: 'password', required: true, autocomplete: 'current-password' }), e = err('e1');
  if (msg) e.textContent = msg;
  const btn = h('button', { class: 'btn cheio', type: 'submit' }, 'Entrar');
  wrap(h('h1', {}, 'Área do aluno'), h('p', { class: 'lead' }, 'Entre com o e-mail e a senha que o grupo passou para você.'),
    h('form', { onsubmit: async (ev) => {
      ev.preventDefault(); btn.disabled = true; e.textContent = '';
      try { tok.set((await call('/auth/login', { method: 'POST', body: { email: email.value, password: pass.value } })).token); await load(); } catch (x) { e.textContent = x.message; } finally { btn.disabled = false; }
    } }, h('label', {}, 'E-mail', email), h('label', {}, 'Senha', pass), e, btn),
    h('p', { class: 'small', style: 'margin-top:1rem' }, 'Ainda não tem acesso? Peça ao grupo para criar o seu.'));
}

async function load() {
  let s;
  try { s = (await call('/me/student')).data; }
  catch (x) {
    if (x.status === 401) { tok.set(null); return loginView(); }
    return wrap(h('h1', {}, 'Área do aluno'), h('p', { class: 'fail' }, x.message), h('p', {}, h('button', { class: 'btn', type: 'button', onclick: logout }, 'Sair')));
  }
  const cur = h('input', { type: 'password', required: true, autocomplete: 'current-password' }), nw = h('input', { type: 'password', required: true, autocomplete: 'new-password' }), e = err('e2'), ok = h('p', { class: 'ok', role: 'status' });
  wrap(h('div', { class: 'perfil-aluno' },
    imgUrl(s.photo_url) ? h('img', { class: 'avatar', src: imgUrl(s.photo_url), alt: `Fotografia de ${s.name}` }) : h('img', { class: 'avatar', src: '../assets/emblema.jpg', alt: '' }),
    h('div', {}, h('h1', {}, s.name), s.nickname ? h('p', { class: 'meta' }, s.nickname) : '',
      h('p', { class: 'badges' }, s.graduation ? h('span', { class: 'badge gold' }, s.graduation.name) : h('span', { class: 'badge' }, 'Graduação ainda não registrada'), h('span', { class: 'badge ' + (s.status === 'ativo' ? 'ok' : '') }, s.status === 'ativo' ? 'Ativo' : 'Inativo')),
      s.entry_date ? h('p', { class: 'small' }, 'No grupo desde ' + fmt(s.entry_date)) : '', s.phone ? h('p', { class: 'small' }, 'Telefone cadastrado: ' + s.phone) : '')),
    h('h2', {}, 'Minha evolução'),
    s.history.length ? h('ol', { class: 'timeline' }, s.history.map((x) => h('li', {}, h('b', {}, fmt(x.date)), ` · ${TYPES[x.type] || 'Registro'}: ${x.title}`, x.note ? h('div', { class: 'small' }, x.note) : '')))
      : h('p', { class: 'vazio' }, 'Ainda não há registros no seu histórico.'),
    h('h2', { style: 'margin-top:2rem' }, 'Alterar senha'),
    h('form', { onsubmit: async (ev) => {
      ev.preventDefault(); e.textContent = ''; ok.textContent = '';
      try { const r = await call('/auth/change-password', { method: 'POST', body: { currentPassword: cur.value, newPassword: nw.value } }); tok.set(r.token); cur.value = ''; nw.value = ''; ok.textContent = 'Senha alterada.'; } catch (x) { e.textContent = x.message; }
    } }, h('label', {}, 'Senha atual', cur), h('label', {}, 'Nova senha (10+ caracteres, com letras e números)', nw), e, ok, h('button', { class: 'btn', type: 'submit' }, 'Salvar nova senha')),
    h('p', { style: 'margin-top:2rem' }, h('button', { class: 'btn', type: 'button', onclick: logout }, 'Sair')));
}
function logout() { tok.set(null); loginView(); }

if (tok.get()) load(); else loginView();

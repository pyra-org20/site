'use strict';
const API = window.APP_CONFIG.API_URL.replace(/\/$/, '');
const app = document.getElementById('app');
let me = null;
const tok = { get: () => { try { return localStorage.getItem('nm_token'); } catch { return null; } }, set: (v) => { try { v ? localStorage.setItem('nm_token', v) : localStorage.removeItem('nm_token'); } catch { /* ignora */ } } };

// ---------- utilidades ----------
const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(Infinity)) e.append(c?.nodeType ? c : document.createTextNode(c === false || c == null ? '' : c));
  return e;
};
const imgUrl = (u) => (u && u.startsWith('/uploads') ? API + u : u);
const fmtDate = (s) => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');
const norm = (v) => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const gradName = (v) => LK.graduations.find((g) => g.id === v)?.name || '—';
const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const DAYS = ['', 'Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

function toast(msg, err = false) {
  const t = h('div', { class: 'toast' + (err ? ' err' : '') }, msg);
  document.getElementById('toasts').append(t); setTimeout(() => t.remove(), 4500);
}
async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  if (tok.get()) headers.Authorization = 'Bearer ' + tok.get();
  if (body) headers['Content-Type'] = 'application/json';
  let res;
  try { res = await fetch(`${API}/api${path}`, { method, headers, body: form || (body ? JSON.stringify(body) : undefined) }); }
  catch { throw { message: 'Não foi possível conectar ao servidor.' }; }
  const data = res.status === 204 ? {} : await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, message: data.error || 'Erro inesperado.', fields: data.fields };
  return data;
}
function ask(message, { typed, okLabel = 'Excluir' } = {}) { // substitui confirm() do navegador
  const dlg = document.getElementById('dlg');
  return new Promise((resolve) => {
    const inp = typed ? h('input', { 'aria-label': 'Confirmação', placeholder: typed, autocomplete: 'off' }) : null;
    const ok = h('button', { class: 'btn danger', type: 'button' }, okLabel);
    const no = h('button', { class: 'btn', type: 'button' }, 'Cancelar');
    const done = (v) => { dlg.close(); resolve(v); };
    ok.onclick = () => done(inp ? inp.value : true); no.onclick = () => done(false);
    dlg.replaceChildren(h('p', {}, message), inp || '', h('div', { class: 'row', style: 'margin-top:1rem' }, ok, no));
    dlg.showModal();
  });
}
const showErrors = (box, e) => {
  box.replaceChildren();
  if (e.fields?.length) box.append(h('ul', { class: 'errs' }, e.fields.map((f) => h('li', {}, `${f.field}: ${f.message}`))));
  else if (e.message) box.append(h('p', { class: 'errs' }, e.message));
};

// Listas usadas nos campos de seleção (unidades, professores, categorias).
const LK = { units: [], teachers: [], graduations: [], age_groups: [], levels: [] };
async function loadLookups() {
  const safe = (p, d) => p.catch(() => d);
  const [u, t, o, g] = await Promise.all([safe(api('/admin/units'), { data: [] }), safe(api('/admin/teachers'), { data: [] }), safe(api('/options'), { data: {} }), safe(api('/admin/graduations'), { data: [] })]);
  LK.units = u.data; LK.teachers = t.data; LK.graduations = g.data; LK.age_groups = o.data.age_groups || []; LK.levels = o.data.levels || [];
}

// ---------- configuração dos recursos ----------
const T = { text: 'text', area: 'area', date: 'date', time: 'time', image: 'image', check: 'check', num: 'number' };
const ref = (k, multi = false) => ({ ref: k, multi }), pick = (k) => ({ list: k });
const unitName = (v) => LK.units.find((u) => u.id === v)?.name || '—';
const RES = {
  students: { label: 'Alunos', perm: 'students.read', writePerm: 'students.write', path: '/admin/students', search: true, noPublish: true, noDelete: true, student: true,
    cols: [['name', 'Aluno', (v, r) => (r.nickname ? `${v} (${r.nickname})` : v)], ['graduation_id', 'Graduação', gradName]],
    fields: [['name', 'Nome completo', T.text, 1], ['nickname', 'Apelido / nome de capoeira', T.text], ['graduation_id', 'Graduação inicial', ref('graduations'), 0, 'new'], ['entry_date', 'Data de entrada no grupo', T.date],
      ['birth_date', 'Data de nascimento', T.date], ['phone', 'Telefone', T.text], ['guardian_name', 'Responsável (se menor de idade)', T.text], ['guardian_phone', 'Telefone do responsável', T.text],
      ['photo_url', 'Fotografia', T.image], ['notes', 'Observações internas (o aluno NÃO vê)', T.area]] },
  graduations: { label: 'Graduações', perm: 'graduations.write', path: '/admin/graduations', newChecked: true, states: ['Ativa', 'Desativada'], verbs: ['Ativar', 'Desativar'],
    cols: [['position', 'Ordem'], ['name', 'Graduação']],
    fields: [['name', 'Nome da graduação', T.text, 1], ['position', 'Ordem (número que define a sequência no seu sistema)', T.num], ['color', 'Cor (opcional, ex.: verde)', T.text], ['description', 'Descrição', T.area], ['is_published', 'Ativa', T.check]] },
  units: { label: 'Unidades', perm: 'units.write', path: '/admin/units', cols: [['name', 'Unidade'], ['type', 'Tipo', (v) => (v === 'sede' ? 'Sede principal' : 'Núcleo')], ['neighborhood', 'Bairro']],
    images: { attach: (id) => `/admin/units/${id}/images`, del: (id) => `/admin/unit_images/${id}`, key: 'description', label: 'Descrição' }, linked: 'unit',
    fields: [['name', 'Nome da unidade', T.text, 1], ['type', 'Tipo', [['sede', 'Sede principal'], ['nucleo', 'Núcleo']]], ['description', 'Descrição', T.area], ['image_url', 'Fotografia principal', T.image],
      ['address', 'Endereço (rua e número)', T.text], ['neighborhood', 'Bairro', T.text], ['city', 'Cidade', T.text], ['state', 'Estado (ex.: CE)', T.text], ['cep', 'CEP', T.text], ['reference', 'Ponto de referência', T.text],
      ['latitude', 'Latitude (opcional, ex.: -3.7319)', T.text], ['longitude', 'Longitude (opcional, ex.: -38.5267)', T.text], ['phone', 'Telefone', T.text], ['whatsapp', 'WhatsApp', T.text],
      ['responsible_id', 'Responsável', ref('teachers')], ['founded_at', 'Data de criação', T.date], ['is_published', 'Ativa (aparece no site)', T.check]] },
  classes: { label: 'Turmas', perm: 'classes.write', path: '/admin/classes', cols: [['name', 'Turma'], ['unit_id', 'Unidade', unitName], ['age_group', 'Faixa etária'], ['level', 'Nível']], schedules: true,
    fields: [['name', 'Nome da turma', T.text, 1], ['unit_id', 'Unidade', ref('units')], ['age_group', 'Faixa etária', pick('age_groups')], ['level', 'Nível', pick('levels')], ['modality', 'Modalidade', T.text],
      ['capacity', 'Capacidade máxima (opcional)', T.num], ['teacher_ids', 'Professores responsáveis', ref('teachers', true)], ['description', 'Descrição', T.area], ['location', 'Local (se diferente da unidade)', T.text],
      ['beginner_info', 'Para iniciantes', T.area], ['student_info', 'Para alunos', T.area], ['how_to_join', 'Como participar', T.area], ['is_published', 'Ativa (aparece no site)', T.check]] },
  teachers: { label: 'Professores', perm: 'teachers.write', path: '/admin/teachers', cols: [['name', 'Nome'], ['graduation', 'Graduação']], linked: 'teacher',
    fields: [['name', 'Nome completo', T.text, 1], ['nickname', 'Apelido / nome de capoeira', T.text], ['graduation', 'Graduação', T.text], ['specialty', 'Especialidade', T.text], ['experience_years', 'Anos de experiência', T.num],
      ['bio', 'Biografia', T.area], ['extra_info', 'Informações adicionais', T.area], ['photo_url', 'Fotografia', T.image], ['phone', 'Telefone (privado, a menos que autorizado abaixo)', T.text], ['whatsapp', 'WhatsApp (privado, a menos que autorizado abaixo)', T.text],
      ['show_contact', 'O professor autorizou mostrar telefone e WhatsApp no site', T.check], ['sort_order', 'Ordem de exibição', T.num], ['is_published', 'Ativo (aparece no site)', T.check]] },
  events: { label: 'Eventos', perm: 'events.write', path: '/admin/events', cols: [['title', 'Nome'], ['event_date', 'Data', fmtDate]],
    images: { attach: (id) => `/admin/events/${id}/images`, del: (id) => `/admin/event_images/${id}`, key: 'caption', label: 'Legenda' },
    fields: [['title', 'Nome', T.text, 1], ['event_date', 'Data', T.date, 1], ['start_time', 'Horário de início', T.time], ['end_time', 'Horário de término', T.time],
      ['location', 'Local', T.text], ['description', 'Descrição', T.area], ['extra_info', 'Informações adicionais', T.area], ['cover_image_url', 'Imagem de capa', T.image], ['is_published', 'Publicado', T.check]] },
  pages: { label: 'Páginas', perm: 'content.write', path: '/admin/pages', cols: [['title', 'Título'], ['slug', 'Endereço']],
    fields: [['title', 'Título', T.text, 1], ['slug', 'Endereço (opcional, ex.: nossa-historia)', T.text], ['content', 'Conteúdo (texto; separe parágrafos com uma linha em branco; começar com "# " cria um título)', T.area],
      ['seo_title', 'Título para buscadores', T.text], ['seo_description', 'Descrição para buscadores', T.area], ['is_published', 'Publicada', T.check]] },
  albums: { label: 'Galeria', perm: 'gallery.write', path: '/admin/albums', cols: [['title', 'Álbum'], ['category', 'Categoria']],
    images: { attach: (id) => `/admin/albums/${id}/images`, del: (id) => `/admin/gallery_images/${id}`, key: 'description', label: 'Descrição' },
    fields: [['title', 'Título', T.text, 1], ['category', 'Categoria', ['evento', 'treino', 'roda', 'apresentacao', 'historico', 'outro']], ['description', 'Descrição', T.area],
      ['cover_image_url', 'Capa', T.image], ['is_published', 'Publicado', T.check]] },
};
const SETTINGS = [['group_name', 'Nome do grupo'], ['tagline', 'Frase institucional'], ['city', 'Cidade'], ['whatsapp', 'WhatsApp'], ['instagram', 'Instagram'],
  ['address', 'Endereço'], ['map_embed_url', 'URL do mapa'], ['emblem_url', 'Emblema (caminho /uploads/...)'], ['seo_title', 'Título SEO'], ['seo_description', 'Descrição SEO']];

// Reduz a foto no celular antes de enviar (máx. 1600 px, JPEG).
async function shrink(file, max = window.APP_CONFIG.local ? 1000 : 1600) {
  const bmp = await createImageBitmap(file), k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Imagem inválida.'))), 'image/jpeg', window.APP_CONFIG.local ? 0.72 : 0.82));
}

// ---------- campos de formulário ----------
function buildField([k, label, type, req], val) {
  const id = 'f_' + k; let input, get;
  if (type && type.ref && type.multi) {
    const sel = new Set((val || []).map(Number)), cbs = LK[type.ref].map((i) => { const cb = h('input', { type: 'checkbox', value: i.id }); cb.checked = sel.has(i.id); return [cb, i]; });
    return { el: h('fieldset', { class: 'card' }, h('legend', {}, label), cbs.length ? cbs.map(([cb, i]) => h('label', { class: 'check' }, cb, i.name + (i.nickname ? ` (${i.nickname})` : ''))) : h('p', { class: 'small' }, 'Nenhum cadastrado ainda.')),
      get: () => cbs.filter(([cb]) => cb.checked).map(([, i]) => i.id) };
  }
  if (type && (type.ref || type.list)) {
    const opts = type.ref ? LK[type.ref].map((i) => [i.id, i.name + (i.nickname ? ` (${i.nickname})` : '')]) : LK[type.list].map((x) => [x, x]);
    if (type.list && val && !LK[type.list].includes(val)) opts.push([val, val]); // mantém valor antigo se a categoria foi removida
    input = h('select', { id }, [h('option', { value: '' }, '— não definido —'), ...opts.map(([v, l]) => h('option', { value: v }, l))]); input.value = val ?? ''; get = () => input.value;
  }
  else if (Array.isArray(type)) { input = h('select', { id }, type.map((o) => (Array.isArray(o) ? h('option', { value: o[0] }, o[1]) : h('option', { value: o }, o)))); const last = type[type.length - 1]; input.value = val ?? (Array.isArray(last) ? last[0] : last); get = () => input.value; }
  else if (type === T.area) { input = h('textarea', { id, rows: 6 }); input.value = val ?? ''; get = () => input.value; }
  else if (type === T.check) { input = h('input', { id, type: 'checkbox' }); input.checked = !!Number(val); get = () => input.checked; }
  else if (type === T.image) {
    let cur = val || '';
    const prev = h('img', { class: 'preview', alt: '', hidden: !cur, src: imgUrl(cur) || '' , style: 'max-width:220px'});
    input = h('input', { id, type: 'file', accept: 'image/jpeg,image/png,image/webp' });
    input.onchange = async () => {
      if (!input.files[0]) return;
      try { const fd = new FormData(); fd.append('file', await shrink(input.files[0]), 'foto.jpg'); cur = (await api('/admin/uploads', { method: 'POST', form: fd })).url; prev.src = imgUrl(cur); prev.hidden = false; toast('Imagem enviada.'); }
      catch (e) { toast(e.message, true); input.value = ''; }
    };
    return { el: h('label', { for: id }, label, input, prev), get: () => cur };
  } else { input = h('input', { id, type: type || 'text', required: !!req }); input.value = val ?? ''; get = () => input.value; }
  const el = type === T.check ? h('label', { class: 'check', for: id }, input, label) : h('label', { for: id }, label, input);
  return { el, get };
}

// ---------- telas ----------
async function loginView() {
  let needsSetup = false, needsKey = false;
  try { const st = await api('/status'); needsSetup = st.needsSetup; needsKey = st.needsKey; } catch (e) { return app.replaceChildren(h('p', { class: 'loading errs' }, e.message)); }
  const err = h('div'), inp = (type, ac) => h('input', { type, required: true, autocomplete: ac });
  const name = inp('text', 'name'), email = inp('email', 'username'), pass = inp('password', needsSetup ? 'new-password' : 'current-password'), key = inp('password', 'off');
  const btn = h('button', { class: 'btn fill', type: 'submit' }, needsSetup ? 'Criar administrador' : 'Entrar');
  const f = h('form', { class: 'login card', onsubmit: async (ev) => {
    ev.preventDefault(); btn.disabled = true; err.replaceChildren();
    try {
      if (needsSetup) { await api('/setup', { method: 'POST', body: { name: name.value, email: email.value, password: pass.value, setupKey: key.value } }); toast('Administrador criado. Entre com seu e-mail e senha.'); return loginView(); }
      tok.set((await api('/auth/login', { method: 'POST', body: { email: email.value, password: pass.value } })).token); await boot();
    } catch (e) { showErrors(err, e); } finally { btn.disabled = false; }
  } }, h('h1', {}, needsSetup ? 'Primeiro acesso' : 'Painel Nação Mandingueira'),
    needsSetup ? [h('p', {}, 'Crie o administrador principal.' + (needsKey ? ' Use o código de instalação (SETUP_KEY) que você definiu no Cloudflare.' : ' Anote o e-mail e a senha: é com eles que você entra no painel.')), h('label', {}, 'Seu nome', name)] : '',
    h('label', {}, 'E-mail', email), h('label', {}, 'Senha' + (needsSetup ? ' (mín. 10 caracteres, com letra e número)' : ''), pass),
    needsSetup && needsKey ? h('label', {}, 'Código de instalação', key) : '', err, btn,
    needsSetup ? '' : h('p', { class: 'small' }, 'Esqueceu a senha? Peça a um administrador superior para definir uma nova.'));
  app.replaceChildren(f);
}

function shell(content, current) {
  const has = (p) => me.permissions.includes(p); // só esconde menus; o backend é quem autoriza
  const links = [['dashboard', 'Início', true], ...Object.entries(RES).map(([k, r]) => [k, r.label, has(r.perm)]),
    ['horarios', 'Horários', has('classes.write')], ['options', 'Categorias', has('units.write')], ['historia', 'História', has('content.write')], ['backup', 'Backup', has('settings.write')],
    ['messages', 'Mensagens', has('messages.read')], ['users', 'Usuários', has('users.read')], ['settings', 'Configurações', has('settings.write')]].filter((l) => l[2]);
  app.replaceChildren(h('header', { class: 'bar' }, h('nav', { 'aria-label': 'Painel' }, links.map(([k, l]) => h('a', { href: '#/' + k, 'aria-current': k === current ? 'page' : null }, l))),
    h('button', { class: 'btn sm', onclick: async () => { tok.set(null); me = null; loginView(); } }, 'Sair')),
    h('main', {}, window.APP_CONFIG.local ? h('p', { class: 'banner' }, 'MODO TESTE: o que você cadastrar fica só neste navegador e os visitantes não veem. Para publicar para todos, conecte o servidor (veja docs/COMECE-AQUI.md) e use Backup → Restaurar.') : '', content));
}

async function dashboard() {
  let s = null;
  try { s = (await api('/admin/stats')).data; } catch { /* aluno sem acesso */ }
  const box = (n, l) => h('div', { class: 'card' }, h('b', {}, String(n)), l);
  shell([h('h1', {}, `Olá, ${me.name}`),
    s ? [h('div', { class: 'stats' }, box(s.users, 'Usuários'), box(s.students_total, 'Alunos'), box(s.students, 'Ativos'), box(s.students_inactive, 'Inativos'), box(s.events, 'Eventos'), box(s.photos, 'Fotografias'), box(s.units, 'Unidades'), box(s.nuclei_active, 'Núcleos ativos'), box(s.teachers, 'Professores'), box(s.classes, 'Turmas'), box(s.schedules, 'Horários'), box(s.messages, `Mensagens (${s.newMessages} novas)`)),
      h('h2', {}, 'Próximas aulas'), s.upcoming?.length ? h('div', { class: 'card' }, s.upcoming.map((u) => h('p', { style: 'margin:.2rem 0' }, `${DAYS[u.weekday]} ${u.start_time.slice(0, 5)} · ${u.class_name}${u.unit_name ? ' · ' + u.unit_name : ''}`))) : h('p', { class: 'empty' }, 'Nenhuma aula cadastrada.'),
      h('h2', {}, 'Atividades recentes'), s.recent.length ? h('div', { class: 'card' }, s.recent.map((a) => h('p', { style: 'margin:.2rem 0' }, `${fmtDate(a.created_at)} · ${a.name || 'Sistema'} · ${a.action}`))) : h('p', { class: 'empty' }, 'Nenhuma atividade ainda.')]
      : h('p', { class: 'card' }, 'Use o menu para acessar suas áreas.')], 'dashboard');
}

async function listView(key) {
  const R = RES[key], rows = (await api(R.path)).data, can = me.permissions.includes(R.writePerm || R.perm), st = { q: '', grad: '', status: '' };
  const [on, off] = R.states || ['Publicado', 'Rascunho'], [vOn, vOff] = R.verbs || ['Publicar', 'Despublicar'], box = h('div');
  let shown = rows;
  const situ = (r) => (R.student ? h('span', { class: 'tag ' + (r.status === 'ativo' ? 'on' : 'off') }, r.status === 'ativo' ? 'Ativo' : 'Inativo') : h('span', { class: 'tag ' + (r.is_published ? 'on' : 'off') }, r.is_published ? on : off));
  const run = async (fn, msg) => { try { await fn(); toast(msg); route(); } catch (e) { toast(e.message, true); } };
  const remove = async (r) => {
    if (!(await ask('Excluir este item? Isso não pode ser desfeito.'))) return;
    try { await api(`${R.path}/${r.id}`, { method: 'DELETE' }); toast('Excluído.'); route(); }
    catch (e) {
      if (e.status === 409 && e.fields?.classes) {
        if (await ask(`Esta unidade tem ${e.fields.classes} turma(s) e ${e.fields.schedules} horário(s). Excluir a unidade apaga também essas turmas e horários. Deseja continuar?`)) {
          try { await api(`${R.path}/${r.id}?force=1`, { method: 'DELETE' }); toast('Unidade, turmas e horários excluídos.'); route(); } catch (e2) { toast(e2.message, true); }
        }
      } else toast(e.message, true);
    }
  };
  const table = (list) => h('div', { class: 'scroll card' }, h('table', {}, h('thead', {}, h('tr', {}, R.cols.map((c) => h('th', {}, c[1])), h('th', {}, 'Situação'), h('th', {}, 'Ações'))),
    h('tbody', {}, list.map((r) => h('tr', {}, R.cols.map(([k, , f]) => h('td', {}, f ? f(r[k], r) : r[k] ?? '')), h('td', {}, situ(r)),
      h('td', {}, h('div', { class: 'row' }, h('a', { class: 'btn sm', href: `#/${key}/${r.id}` }, can ? 'Editar' : 'Ver'),
        can && !R.noPublish && h('button', { class: 'btn sm', onclick: () => run(() => api(`${R.path}/${r.id}/publish`, { method: 'PATCH', body: { is_published: !r.is_published } }), r.is_published ? 'Desativado.' : 'Ativado.') }, r.is_published ? vOff : vOn),
        can && R.student && h('button', { class: 'btn sm', onclick: async () => { if (await ask(r.status === 'ativo' ? 'Desativar este aluno? O histórico é mantido.' : 'Reativar este aluno?', { okLabel: r.status === 'ativo' ? 'Desativar' : 'Reativar' })) run(() => api(`${R.path}/${r.id}/status`, { method: 'PATCH', body: { status: r.status === 'ativo' ? 'inativo' : 'ativo' } }), 'Situação alterada.'); } }, r.status === 'ativo' ? 'Desativar' : 'Reativar'),
        can && !R.noDelete && h('button', { class: 'btn sm danger', onclick: () => remove(r) }, 'Excluir'))))))));
  const draw = () => {
    const q = norm(st.q);
    shown = rows.filter((r) => (!q || norm(`${r.name} ${r.nickname || ''}`).includes(q)) && (!st.grad || String(r.graduation_id) === st.grad) && (!st.status || r.status === st.status));
    box.replaceChildren(shown.length ? table(shown) : h('p', { class: 'card empty' }, rows.length ? 'Nenhum resultado para esta busca.' : 'Nada cadastrado ainda. Crie o primeiro item.'));
  };
  const controls = R.search ? h('div', { class: 'card' }, h('div', { class: 'row' },
    (() => { const i = h('input', { type: 'search', placeholder: 'Pesquisar por nome ou apelido', 'aria-label': 'Pesquisar', autocomplete: 'off' }); i.oninput = () => { st.q = i.value; draw(); }; return i; })(),
    (() => { const g = h('select', { 'aria-label': 'Graduação' }, [h('option', { value: '' }, 'Todas as graduações'), ...LK.graduations.map((x) => h('option', { value: x.id }, x.name))]); g.onchange = () => { st.grad = g.value; draw(); }; return g; })(),
    (() => { const x = h('select', { 'aria-label': 'Situação' }, [['', 'Todas as situações'], ['ativo', 'Ativos'], ['inativo', 'Inativos']].map(([v, l]) => h('option', { value: v }, l))); x.onchange = () => { st.status = x.value; draw(); }; return x; })(),
    can && h('button', { class: 'btn sm', type: 'button', onclick: () => {
      const lines = [['Nome', 'Apelido', 'Graduação', 'Entrada', 'Situação', 'Telefone'].map(csvCell).join(',')].concat(shown.map((r) => [r.name, r.nickname, gradName(r.graduation_id), r.entry_date, r.status, r.phone].map(csvCell).join(',')));
      const a = h('a', { href: URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' })), download: 'alunos.csv' }); document.body.append(a); a.click(); a.remove();
    } }, 'Baixar lista (CSV)'))) : '';
  draw();
  shell([h('div', { class: 'row between' }, h('h1', {}, R.label), can ? h('a', { class: 'btn fill', href: `#/${key}/new` }, 'Novo') : ''), controls, box], key);
}

async function editView(key, id) {
  const R = RES[key], isNew = id === 'new', item = isNew ? (R.newChecked ? { is_published: 1 } : {}) : (await api(`${R.path}/${id}`)).data;
  const FL = R.fields.filter((f) => isNew || f[4] !== 'new');
  if (!isNew && !me.permissions.includes(R.writePerm || R.perm)) { // somente leitura (ex.: professor)
    return shell([h('h1', {}, item.name || R.label), h('div', { class: 'card' }, FL.filter((f) => f[2] !== T.image && item[f[0]] != null && item[f[0]] !== '').map(([k, l]) => h('p', {}, h('b', {}, l.split(' (')[0] + ': '), k === 'graduation_id' ? gradName(item[k]) : String(item[k])))),
      h('p', { class: 'small' }, 'Você tem acesso somente para consulta.'), h('a', { class: 'btn', href: '#/' + key }, 'Voltar')], key);
  }
  const fields = FL.map((f) => buildField(f, item[f[0]])), err = h('div');
  const save = h('button', { class: 'btn fill', type: 'submit' }, 'Salvar');
  const form = h('form', { class: 'card', onsubmit: async (ev) => {
    ev.preventDefault(); save.disabled = true; err.replaceChildren();
    const body = Object.fromEntries(FL.map((f, i) => [f[0], fields[i].get()]));
    try {
      const send = (q) => api((isNew ? R.path : `${R.path}/${id}`) + q, { method: isNew ? 'POST' : 'PUT', body });
      let r; try { r = await send(''); } catch (e) { if (e.status === 409 && e.fields?.duplicate && (await ask(e.message, { okLabel: 'Cadastrar mesmo assim' }))) r = await send('?force=1'); else throw e; }
      toast('Salvo.'); if (isNew) location.hash = `#/${key}/${r.data.id}`; else route();
    } catch (e) { showErrors(err, e); } finally { save.disabled = false; }
  } }, fields.map((f) => f.el), err, h('div', { class: 'row' }, save, h('a', { class: 'btn', href: '#/' + key }, 'Voltar')));
  const extra = [];
  if (!isNew && R.images) extra.push(imagesBox(R, item));
  if (!isNew && R.schedules) extra.push(schedulesBox(R, item));
  if (!isNew && R.linked) extra.push(await linkedBox(R, item));
  if (!isNew && R.student) extra.push(...studentBoxes(item));
  shell([h('h1', {}, (isNew ? 'Novo: ' : 'Editar: ') + R.label), form, extra], key);
}

async function linkedBox(R, item) {
  const all = (await api('/admin/classes')).data;
  const mine = all.filter((k) => (R.linked === 'unit' ? k.unit_id === item.id : (k.teacher_ids || []).includes(item.id)));
  return h('div', { class: 'card' }, h('h2', {}, R.linked === 'unit' ? 'Turmas desta unidade' : 'Turmas e horários deste professor'),
    mine.length ? mine.map((k) => h('div', { style: 'margin-bottom:.6rem' }, h('a', { href: `#/classes/${k.id}` }, k.name), R.linked === 'teacher' && k.unit_id ? ' · ' + unitName(k.unit_id) : '',
      h('div', { class: 'small' }, k.schedules.length ? k.schedules.map((s) => `${DAYS[s.weekday]} ${s.start_time.slice(0, 5)}–${s.end_time.slice(0, 5)}`).join(' · ') : 'Sem horários'))) : h('p', { class: 'empty' }, 'Nenhuma turma vinculada.'));
}

function studentBoxes(item) {
  const err = h('div'), act = async (fn, msg) => { err.replaceChildren(); try { await fn(); toast(msg); route(); } catch (e) { showErrors(err, e); } };
  const ativo = item.status === 'ativo', today = new Date().toISOString().slice(0, 10);
  const status = h('div', { class: 'card' }, h('h2', {}, 'Situação'), h('p', {}, h('span', { class: 'tag ' + (ativo ? 'on' : 'off') }, ativo ? 'Ativo' : 'Inativo'), ' Desativar não apaga o histórico do aluno.'),
    h('button', { class: 'btn ' + (ativo ? 'danger' : 'fill'), type: 'button', onclick: async () => { if (await ask(ativo ? 'Desativar este aluno? O histórico é mantido.' : 'Reativar este aluno?', { okLabel: ativo ? 'Desativar' : 'Reativar' })) act(() => api(`/admin/students/${item.id}/status`, { method: 'PATCH', body: { status: ativo ? 'inativo' : 'ativo' } }), 'Situação alterada.'); } }, ativo ? 'Desativar aluno' : 'Reativar aluno'));
  const active = LK.graduations.filter((g) => g.is_published !== false);
  const gsel = h('select', { 'aria-label': 'Nova graduação' }, active.map((g) => h('option', { value: g.id }, g.name))), gdate = h('input', { type: 'date', 'aria-label': 'Data da graduação', value: today }), gnote = h('input', { placeholder: 'Observação (opcional)', maxlength: 500, 'aria-label': 'Observação' });
  if (item.graduation_id && active.some((g) => g.id === item.graduation_id)) gsel.value = item.graduation_id;
  const grad = h('div', { class: 'card' }, h('h2', {}, 'Graduação'), h('p', {}, 'Atual: ', h('b', {}, gradName(item.graduation_id))),
    active.length ? [h('div', { class: 'row' }, gsel, gdate), h('div', { class: 'row', style: 'margin-top:.5rem' }, gnote),
      h('div', { class: 'row', style: 'margin-top:.5rem' }, h('button', { class: 'btn fill', type: 'button', onclick: () => act(() => api(`/admin/students/${item.id}/graduate`, { method: 'POST', body: { graduation_id: gsel.value, date: gdate.value, note: gnote.value } }), 'Graduação registrada.') }, 'Registrar graduação'))]
      : h('p', { class: 'small' }, 'Cadastre as graduações no menu "Graduações" para poder registrá-las.'));
  const type = h('select', { 'aria-label': 'Tipo' }, [['evento', 'Evento'], ['troca_corda', 'Troca de corda'], ['participacao', 'Participação'], ['observacao', 'Observação interna']].map(([v, l]) => h('option', { value: v }, l)));
  const hdate = h('input', { type: 'date', 'aria-label': 'Data', value: today }), htitle = h('input', { placeholder: 'Título', maxlength: 120, 'aria-label': 'Título' }), hnote = h('input', { placeholder: 'Detalhes (opcional)', maxlength: 1000, 'aria-label': 'Detalhes' });
  const vis = h('input', { type: 'checkbox', checked: true, id: 'h_vis' }); type.onchange = () => { vis.checked = type.value !== 'observacao'; };
  const hist = [...(item.history || [])].sort((a, b) => b.date.localeCompare(a.date) || b.created_at.localeCompare(a.created_at));
  const tl = h('div', { class: 'card' }, h('h2', {}, 'Histórico de evolução'),
    hist.length ? hist.map((x) => h('div', { style: 'margin-bottom:.7rem' }, h('b', {}, `${fmtDate(x.date)} · ${x.title}`), ' ', h('span', { class: 'tag ' + (x.visible ? 'on' : 'off') }, x.visible ? 'Aluno vê' : 'Interno'), x.note ? h('div', { class: 'small' }, x.note) : '', h('div', { class: 'small' }, `por ${x.by}`))) : h('p', { class: 'empty' }, 'Sem registros.'),
    h('h3', { style: 'margin-top:1rem' }, 'Adicionar registro'), h('div', { class: 'row' }, type, hdate), h('div', { class: 'row', style: 'margin-top:.5rem' }, htitle), h('div', { class: 'row', style: 'margin-top:.5rem' }, hnote),
    h('label', { class: 'check', for: 'h_vis', style: 'margin-top:.5rem' }, vis, 'Visível para o aluno'),
    h('div', { class: 'row', style: 'margin-top:.5rem' }, h('button', { class: 'btn fill', type: 'button', onclick: () => act(() => api(`/admin/students/${item.id}/history`, { method: 'POST', body: { type: type.value, date: hdate.value, title: htitle.value, note: hnote.value, visible: vis.checked } }), 'Registro adicionado.') }, 'Adicionar ao histórico')));
  const em = h('input', { type: 'email', placeholder: 'E-mail do aluno', 'aria-label': 'E-mail do aluno', autocomplete: 'off' }), pw = h('input', { type: 'text', placeholder: 'Senha inicial (10+ caracteres, letras e números)', 'aria-label': 'Senha inicial', autocomplete: 'off' });
  const acc = h('div', { class: 'card' }, h('h2', {}, 'Acesso do aluno ao site'),
    item.user_id ? [h('p', {}, 'Acesso ativo: ', h('b', {}, item.access_email || '—')), h('button', { class: 'btn', type: 'button', onclick: async () => { const p = await ask('Nova senha para o aluno (10+ caracteres, com letras e números):', { typed: 'nova senha', okLabel: 'Salvar' }); if (p) act(() => api(`/admin/students/${item.id}/access`, { method: 'PUT', body: { password: p } }), 'Senha alterada.'); } }, 'Definir nova senha')]
      : [h('p', { class: 'small' }, 'Crie o e-mail e a senha de acesso e passe ao aluno (ou ao responsável). Ele entra em "Área do aluno" no site e vê só os próprios dados.'), h('div', { class: 'row' }, em, pw),
        h('div', { class: 'row', style: 'margin-top:.5rem' }, h('button', { class: 'btn fill', type: 'button', onclick: () => act(() => api(`/admin/students/${item.id}/access`, { method: 'POST', body: { email: em.value, password: pw.value } }), 'Acesso criado. Passe o e-mail e a senha ao aluno.') }, 'Criar acesso'))]);
  return [status, grad, tl, acc, err];
}

function imagesBox(R, item) {
  const file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', 'aria-label': 'Foto' }), txt = h('input', { placeholder: R.images.label, maxlength: 300 }), err = h('div');
  const add = h('button', { class: 'btn fill', type: 'button', onclick: async () => {
    err.replaceChildren(); if (!file.files[0]) return showErrors(err, { message: 'Escolha uma foto.' });
    add.disabled = true;
    try { const fd = new FormData(); fd.append('file', await shrink(file.files[0]), 'foto.jpg'); const { url } = await api('/admin/uploads', { method: 'POST', form: fd });
      await api(R.images.attach(item.id), { method: 'POST', body: { image_url: url, [R.images.key]: txt.value } }); toast('Foto adicionada.'); route(); }
    catch (e) { showErrors(err, e); add.disabled = false; }
  } }, 'Adicionar foto');
  const list = item.images || [];
  return h('div', { class: 'card' }, h('h2', {}, 'Fotografias'),
    list.length ? h('div', { class: 'thumbs' }, list.map((im) => h('figure', {}, h('img', { src: imgUrl(im.image_url), alt: im[R.images.key] || '', loading: 'lazy' }), h('figcaption', {}, im[R.images.key] || ''),
      h('button', { class: 'btn sm danger', onclick: async () => { if (!(await ask('Excluir esta foto?'))) return; try { await api(R.images.del(im.id), { method: 'DELETE' }); toast('Foto excluída.'); route(); } catch (e) { toast(e.message, true); } } }, 'Excluir'))))
      : h('p', { class: 'empty' }, 'Sem fotografias ainda.'),
    h('div', { class: 'row', style: 'margin-top:1rem' }, file, txt, add), err);
}

function schedulesBox(R, item) {
  let editing = null;
  const day = h('select', { 'aria-label': 'Dia' }, DAYS.slice(1).map((d, i) => h('option', { value: i + 1 }, d))), a = h('input', { type: 'time', 'aria-label': 'Início' }), b = h('input', { type: 'time', 'aria-label': 'Fim' });
  const notes = h('input', { placeholder: 'Observações (opcional)', maxlength: 300, 'aria-label': 'Observações' }), err = h('div');
  const go = h('button', { class: 'btn fill', type: 'button' }, 'Adicionar horário'), cancel = h('button', { class: 'btn', type: 'button', hidden: true }, 'Cancelar edição');
  const reset = () => { editing = null; a.value = ''; b.value = ''; notes.value = ''; go.textContent = 'Adicionar horário'; cancel.hidden = true; };
  const done = (r, msg) => { if (r.warnings?.length) toast('Atenção: ' + r.warnings.join(' | '), true); else toast(msg); route(); };
  go.onclick = async () => {
    err.replaceChildren(); const body = { weekday: day.value, start_time: a.value, end_time: b.value, notes: notes.value };
    try { done(editing ? await api(`/admin/schedules/${editing}`, { method: 'PUT', body }) : await api(`/admin/classes/${item.id}/schedules`, { method: 'POST', body }), 'Horário salvo.'); } catch (e) { showErrors(err, e); }
  };
  cancel.onclick = reset;
  const act = async (fn, msg) => { try { done(await fn(), msg); } catch (e) { toast(e.message, true); } };
  const list = item.schedules || [];
  return h('div', { class: 'card' }, h('h2', {}, 'Dias e horários'),
    list.length ? list.map((s) => h('div', { class: 'row', style: 'margin-bottom:.5rem' },
      h('span', {}, `${DAYS[s.weekday]}, ${s.start_time.slice(0, 5)} às ${s.end_time.slice(0, 5)}` + (s.notes ? ` — ${s.notes}` : '')), s.is_active === false ? h('span', { class: 'tag off' }, 'Inativo') : '',
      h('button', { class: 'btn sm', onclick: () => { editing = s.id; day.value = s.weekday; a.value = s.start_time.slice(0, 5); b.value = s.end_time.slice(0, 5); notes.value = s.notes || ''; go.textContent = 'Salvar alteração'; cancel.hidden = false; day.scrollIntoView({ block: 'center' }); } }, 'Editar'),
      h('button', { class: 'btn sm', onclick: () => act(() => api(`/admin/schedules/${s.id}/duplicate`, { method: 'POST', body: { weekday: Number(day.value) } }), `Duplicado para ${DAYS[day.value]}.`) }, 'Duplicar'),
      h('button', { class: 'btn sm', onclick: () => act(() => api(`/admin/schedules/${s.id}`, { method: 'PUT', body: { is_active: s.is_active === false } }), s.is_active === false ? 'Horário ativado.' : 'Horário desativado.') }, s.is_active === false ? 'Ativar' : 'Desativar'),
      h('button', { class: 'btn sm danger', onclick: async () => { if (!(await ask('Remover este horário?'))) return; act(() => api(`/admin/schedules/${s.id}`, { method: 'DELETE' }), 'Horário removido.'); } }, 'Remover')))
      : h('p', { class: 'empty' }, 'Nenhum horário cadastrado.'),
    h('p', { class: 'small' }, 'Para duplicar um horário em outro dia, escolha o dia abaixo e toque em "Duplicar". Conflitos geram apenas um aviso.'),
    h('div', { class: 'row' }, day, a, b), h('div', { class: 'row', style: 'margin-top:.5rem' }, notes), h('div', { class: 'row', style: 'margin-top:.5rem' }, go, cancel), err);
}

async function gridView() {
  const rows = (await api('/admin/schedules')).data, order = [2, 3, 4, 5, 6, 7, 1];
  shell([h('h1', {}, 'Grade de horários'), h('p', { class: 'small' }, 'Visão de todas as turmas da semana. Para criar ou editar um horário, abra a turma.'),
    ...(rows.length ? order.map((d) => { const list = rows.filter((r) => r.weekday === d).sort((x, y) => x.start_time.localeCompare(y.start_time));
      return h('section', { class: 'card' }, h('h2', {}, DAYS[d]), list.length ? list.map((r) => h('div', { class: 'row between', style: 'margin-bottom:.5rem' },
        h('span', {}, `${r.start_time.slice(0, 5)}–${r.end_time.slice(0, 5)} · ${r.class_name}` + (r.unit_name ? ` · ${r.unit_name}` : '') + (r.teachers.length ? ` · ${r.teachers.join(', ')}` : '') + (r.is_active === false ? ' (inativo)' : '')),
        h('div', { class: 'row' }, r.warnings.length ? h('span', { class: 'tag off', title: r.warnings.join('\n') }, 'Conflito') : '', h('a', { class: 'btn sm', href: `#/classes/${r.class_id}` }, 'Abrir turma')))) : h('p', { class: 'small' }, 'Sem aulas.')); })
      : [h('p', { class: 'card empty' }, 'Nenhum horário cadastrado.')])], 'horarios');
}

async function optionsView() {
  await loadLookups();
  const ta = (v) => { const t = h('textarea', { rows: 6 }); t.value = v.join('\n'); return t; }, ages = ta(LK.age_groups), lvls = ta(LK.levels), err = h('div');
  const lines = (t) => t.value.split('\n').map((x) => x.trim()).filter(Boolean);
  shell([h('h1', {}, 'Categorias das turmas'), h('p', { class: 'small' }, 'Uma categoria por linha. Elas aparecem nos campos "Faixa etária" e "Nível" das turmas e nos filtros do site.'),
    h('form', { class: 'card', onsubmit: async (ev) => { ev.preventDefault(); err.replaceChildren(); try { await api('/admin/options', { method: 'PUT', body: { age_groups: lines(ages), levels: lines(lvls) } }); toast('Categorias salvas.'); } catch (e) { showErrors(err, e); } } },
      h('label', {}, 'Faixas etárias', ages), h('label', {}, 'Níveis', lvls), err, h('button', { class: 'btn fill', type: 'submit' }, 'Salvar'))], 'options');
}

// "História": abre (ou cria) a página Nossa História direto para edição.
async function historiaView() {
  const list = (await api('/admin/pages')).data;
  let p = list.find((x) => x.slug === 'nossa-historia');
  if (!p) p = (await api('/admin/pages', { method: 'POST', body: { title: 'Nossa História', slug: 'nossa-historia', content: '', is_published: false } })).data;
  location.replace('#/pages/' + p.id);
}

async function backupView() {
  const err = h('div'), file = h('input', { type: 'file', accept: 'application/json,.json', 'aria-label': 'Arquivo de backup' });
  const dl = h('button', { class: 'btn fill', type: 'button', onclick: async () => {
    dl.disabled = true; err.replaceChildren();
    try {
      const blob = new Blob([JSON.stringify(await api('/admin/export'))], { type: 'application/json' });
      const a = h('a', { href: URL.createObjectURL(blob), download: `backup-nacao-${new Date().toISOString().slice(0, 10)}.json` });
      document.body.append(a); a.click(); a.remove(); toast('Backup baixado.');
    } catch (e) { showErrors(err, e); } finally { dl.disabled = false; }
  } }, 'Baixar backup');
  const rs = h('button', { class: 'btn danger', type: 'button', onclick: async () => {
    err.replaceChildren(); if (!file.files[0]) return showErrors(err, { message: 'Escolha o arquivo de backup.' });
    if (!(await ask('Restaurar substitui unidades, turmas, professores, eventos, galeria, páginas e configurações atuais pelos do backup. Os usuários não mudam. Continuar?', { okLabel: 'Restaurar' }))) return;
    try { toast((await api('/admin/import', { method: 'POST', body: JSON.parse(await file.files[0].text()) })).message); }
    catch (e) { showErrors(err, e.status ? e : { message: 'Arquivo de backup inválido.' }); }
  } }, 'Restaurar backup');
  shell([h('h1', {}, 'Backup'), h('div', { class: 'card' }, h('h2', {}, 'Baixar'), h('p', {}, 'Salva tudo (unidades, turmas, professores, eventos, fotos, textos e configurações) em um arquivo. Os usuários e senhas não entram.'), dl),
    h('div', { class: 'card' }, h('h2', {}, 'Restaurar'), h('p', {}, 'Use para levar os dados do modo teste para o servidor de verdade, ou para recuperar um backup.'), file, h('div', { class: 'row', style: 'margin-top:.6rem' }, rs)), err], 'backup');
}

async function messagesView() {
  const rows = (await api('/admin/messages')).data;
  shell([h('h1', {}, 'Mensagens'), rows.length ? rows.map((m) => h('article', { class: 'card' }, h('div', { class: 'row between' }, h('b', {}, m.name), h('span', { class: 'tag' }, m.status)),
    h('p', {}, h('a', { href: 'mailto:' + m.email }, m.email), m.phone ? ' · ' + m.phone : '', ' · ' + fmtDate(m.created_at)), h('p', { style: 'white-space:pre-wrap' }, m.message),
    h('div', { class: 'row' }, ['lida', 'respondida', 'arquivada'].map((st) => h('button', { class: 'btn sm', onclick: async () => { try { await api('/admin/messages/' + m.id, { method: 'PATCH', body: { status: st } }); route(); } catch (e) { toast(e.message, true); } } }, 'Marcar ' + st)),
      h('button', { class: 'btn sm danger', onclick: async () => { if (!(await ask('Excluir esta mensagem?'))) return; try { await api('/admin/messages/' + m.id, { method: 'DELETE' }); route(); } catch (e) { toast(e.message, true); } } }, 'Excluir')))) : h('p', { class: 'card empty' }, 'Nenhuma mensagem recebida.')], 'messages');
}

async function usersView() {
  const rows = (await api('/admin/users')).data, can = (p) => me.permissions.includes(p);
  const act = async (fn) => { try { await fn(); route(); } catch (e) { toast(e.message, true); } };
  shell([h('h1', {}, 'Usuários'), h('div', { class: 'scroll card' }, h('table', {}, h('thead', {}, h('tr', {}, ['Nome', 'E-mail', 'Permissão', 'Situação', 'Ações'].map((t) => h('th', {}, t)))),
    h('tbody', {}, rows.map((u) => { const sel = h('select', { 'aria-label': 'Permissão', disabled: !can('users.write') || u.id === me.id }, ['aluno', 'professor', 'administrador', 'superadministrador'].map((r) => h('option', { value: r }, r)));
      sel.value = u.roles[0] || 'aluno';
      sel.onchange = () => act(() => api(`/admin/users/${u.id}/role`, { method: 'PUT', body: { role: sel.value } }).then(() => toast('Permissão alterada.')));
      return h('tr', {}, h('td', {}, u.name), h('td', {}, u.email), h('td', {}, sel), h('td', {}, h('span', { class: 'tag ' + (u.status === 'ativo' ? 'on' : 'off') }, u.status)),
        h('td', {}, u.id === me.id ? 'Você' : h('div', { class: 'row' },
          can('users.write') && h('button', { class: 'btn sm', onclick: async () => { const p = await ask(`Nova senha para ${u.name} (mín. 10 caracteres, com letra e número):`, { typed: 'nova senha', okLabel: 'Salvar' }); if (p) act(() => api(`/admin/users/${u.id}/password`, { method: 'PUT', body: { password: p } }).then(() => toast('Senha alterada.'))); } }, 'Nova senha'),
          can('users.write') && h('button', { class: 'btn sm', onclick: () => act(() => api(`/admin/users/${u.id}/status`, { method: 'PATCH', body: { status: u.status === 'ativo' ? 'suspenso' : 'ativo' } }).then(() => toast('Situação alterada.'))) }, u.status === 'ativo' ? 'Suspender' : 'Reativar'),
          can('users.delete') && h('button', { class: 'btn sm danger', onclick: async () => { const t = await ask(`Para excluir ${u.name}, digite o e-mail da conta:`, { typed: u.email }); if (t) act(() => api(`/admin/users/${u.id}`, { method: 'DELETE', body: { confirmEmail: t } }).then(() => toast('Conta excluída.'))); } }, 'Excluir')))); })))) ], 'users');
}

async function settingsView() {
  const cur = (await api('/settings')).data, err = h('div'), inputs = {};
  const form = h('form', { class: 'card', onsubmit: async (ev) => { ev.preventDefault(); err.replaceChildren();
    try { await api('/admin/settings', { method: 'PUT', body: Object.fromEntries(SETTINGS.map(([k]) => [k, inputs[k].value])) }); toast('Configurações salvas.'); } catch (e) { showErrors(err, e); } } },
    SETTINGS.map(([k, l]) => { inputs[k] = h('input', { id: 's_' + k }); inputs[k].value = cur[k] || ''; return h('label', { for: 's_' + k }, l, inputs[k]); }), err, h('button', { class: 'btn fill', type: 'submit' }, 'Salvar'));
  shell([h('h1', {}, 'Configurações'), form], 'settings');
}

// ---------- roteamento ----------
async function route() {
  if (!me) return;
  const [, page = 'dashboard', id] = location.hash.split('/');
  try {
    if (page === 'dashboard') await dashboard();
    else if (RES[page]) { await loadLookups(); await (id ? editView(page, id) : listView(page)); }
    else if (page === 'horarios') await gridView();
    else if (page === 'options') await optionsView();
    else if (page === 'historia') await historiaView();
    else if (page === 'backup') await backupView();
    else if (page === 'messages') await messagesView();
    else if (page === 'users') await usersView();
    else if (page === 'settings') await settingsView();
    else await dashboard();
  } catch (e) {
    if (e.status === 401) { tok.set(null); me = null; return loginView(); }
    shell(h('p', { class: 'card errs' }, e.status === 403 ? 'Você não tem permissão para acessar esta área.' : e.message), page);
  }
}
async function boot() {
  if (tok.get()) {
    try { me = (await api('/auth/me')).user; }
    catch (e) { if (e.status === 401) { tok.set(null); me = null; } else { app.replaceChildren(h('p', { class: 'loading errs' }, e.message)); return; } }
  }
  if (!me) return loginView();
  if (!me.roles.some((r) => r !== 'aluno')) { app.replaceChildren(h('p', { class: 'loading' }, 'Esta área é exclusiva para administradores.')); return; }
  route();
}
window.addEventListener('hashchange', route);
boot();

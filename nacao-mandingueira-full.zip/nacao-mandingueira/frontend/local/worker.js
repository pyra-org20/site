// Nação Mandingueira — API em Cloudflare Worker + KV (dados em JSON).
// Binding KV: DB | Secrets: JWT_SECRET, SETUP_KEY | Variável opcional: ALLOWED_ORIGINS
const enc = new TextEncoder();
const ITER = 100000; // máximo aceito pelo WebCrypto do Workers
class HttpErr extends Error { constructor(status, message, fields) { super(message); this.status = status; this.fields = fields; } }
const iso = () => new Date().toISOString();
const hex = (n) => [...crypto.getRandomValues(new Uint8Array(n))].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64u = (buf) => { let s = ''; for (const b of new Uint8Array(buf)) s += String.fromCharCode(b); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (s.length % 4)) % 4)), (c) => c.charCodeAt(0));
const same = (a, b) => { a = String(a); b = String(b); let d = a.length ^ b.length; for (let i = 0; i < Math.max(a.length, b.length); i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0); return d === 0; };
const slugify = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 100) || 'item';

// Segredo da sessão: usa JWT_SECRET se existir; senão gera e guarda no KV (sem configuração manual).
let cachedSecret;
async function secretOf(env) {
  if (env.JWT_SECRET) return env.JWT_SECRET;
  if (cachedSecret) return cachedSecret;
  let k = await env.DB.get('sys:secret');
  if (!k) { k = hex(32); await env.DB.put('sys:secret', k); }
  return (cachedSecret = k);
}

// ---------- senha e sessão ----------
async function hashPw(pw, salt = crypto.getRandomValues(new Uint8Array(16))) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: ITER }, key, 256);
  return `${b64u(salt)}.${b64u(bits)}`;
}
async function checkPw(pw, stored) { const [s] = stored.split('.'); return same(await hashPw(pw, unb64u(s)), stored); }
const hmacKey = (secret) => crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
async function signToken(p, secret) { const body = b64u(enc.encode(JSON.stringify(p))); return `${body}.${b64u(await crypto.subtle.sign('HMAC', await hmacKey(secret), enc.encode(body)))}`; }
async function readToken(t, secret) {
  const [body, sig] = String(t).split('.');
  if (!body || !sig || !(await crypto.subtle.verify('HMAC', await hmacKey(secret), unb64u(sig), enc.encode(body)))) return null;
  const p = JSON.parse(new TextDecoder().decode(unb64u(body)));
  return p.exp > Date.now() / 1000 ? p : null;
}
function checkPassword(p) {
  const f = [];
  if (typeof p !== 'string' || p.length < 10) f.push({ field: 'password', message: 'Mínimo de 10 caracteres' });
  else if (p.length > 100 || !/[A-Za-z]/.test(p) || !/\d/.test(p)) f.push({ field: 'password', message: 'Use letras e números (até 100 caracteres)' });
  if (f.length) throw new HttpErr(422, 'Dados inválidos.', f);
}

// ---------- permissões ----------
const LEVEL = { aluno: 10, professor: 30, administrador: 50, superadministrador: 100 };
const ADMIN_PERMS = ['students.read', 'students.write', 'graduations.write', 'units.write', 'events.write', 'gallery.write', 'teachers.write', 'classes.write', 'content.write', 'messages.read', 'users.read'];
const PERMS = { aluno: [], professor: ['students.read'], administrador: ADMIN_PERMS, superadministrador: [...ADMIN_PERMS, 'users.write', 'users.delete', 'settings.write', 'audit.read'] };

// ---------- validação ----------
const strip = (s) => String(s).replace(/<[^>]*>/g, '').replace(/[<>]/g, '').trim();
const F = {
  text: (max, o = {}) => ({ t: 'text', max, ...o }), date: (o = {}) => ({ t: 'date', ...o }), time: () => ({ t: 'time' }), img: () => ({ t: 'img' }),
  bool: () => ({ t: 'bool' }), ids: () => ({ t: 'ids' }), num: (lo, hi) => ({ t: 'num', lo, hi }), int: (lo, hi, def = null) => ({ t: 'int', lo, hi, def }), enm: (opts, def) => ({ t: 'enum', opts, def }), slug: () => ({ t: 'slug' }),
};
function one(k, s, v) {
  const empty = v === undefined || v === null || v === '';
  if (s.t === 'ids') {
    if (empty) return [];
    if (!Array.isArray(v) || v.length > 30) throw [k, 'Lista inválida'];
    const ids = [...new Set(v.map(Number))];
    if (ids.some((n) => !Number.isInteger(n) || n < 1)) throw [k, 'Lista inválida'];
    return ids;
  }
  if (s.t === 'bool') return v === true || v === 1 || v === '1' || v === 'true';
  if (empty) { if (s.req) throw [k, 'Campo obrigatório']; return s.t === 'enum' ? s.def : s.t === 'int' ? s.def : null; }
  if (s.t === 'text') { const x = strip(v); if (x.length < (s.min || 0)) throw [k, `Mínimo de ${s.min} caracteres`]; if (x.length > s.max) throw [k, `Máximo de ${s.max} caracteres`]; return x; }
  if (s.t === 'date') { if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw [k, 'Data inválida (AAAA-MM-DD)']; return v; }
  if (s.t === 'time') { if (!/^\d{2}:\d{2}(:\d{2})?$/.test(v)) throw [k, 'Horário inválido (HH:MM)']; return String(v).slice(0, 5); }
  if (s.t === 'img') { if (!/^(\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)|https:\/\/[^\s]{1,240})$/.test(v)) throw [k, 'URL de imagem inválida']; return v; }
  if (s.t === 'int') { const n = Number(v); if (!Number.isInteger(n) || n < s.lo || n > s.hi) throw [k, `Número entre ${s.lo} e ${s.hi}`]; return n; }
  if (s.t === 'num') { const n = Number(String(v).replace(',', '.')); if (!Number.isFinite(n) || n < s.lo || n > s.hi) throw [k, `Valor entre ${s.lo} e ${s.hi}`]; return n; }
  if (s.t === 'enum') { if (!s.opts.includes(v)) throw [k, 'Valor inválido']; return v; }
  if (s.t === 'slug') { if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(v) || v.length > 140) throw [k, 'Endereço inválido (use letras minúsculas, números e hífen)']; return v; }
}
function validate(spec, body, partial) {
  const out = {}, errs = [];
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HttpErr(400, 'Corpo inválido.');
  for (const [k, s] of Object.entries(spec)) {
    if (partial && !(k in body)) continue;
    try { out[k] = one(k, s, body[k]); } catch (e) { if (Array.isArray(e)) errs.push({ field: e[0], message: e[1] }); else throw e; }
  }
  if (errs.length) throw new HttpErr(422, 'Dados inválidos.', errs);
  return out;
}
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const SPEC = {
  events: { perm: 'events.write', slugFrom: 'title', kids: { images: [] }, f: { title: F.text(160, { req: 1, min: 3 }), description: F.text(5000), event_date: F.date({ req: 1 }), start_time: F.time(), end_time: F.time(), location: F.text(200), cover_image_url: F.img(), extra_info: F.text(3000), is_published: F.bool() } },
  teachers: { perm: 'teachers.write', slugFrom: 'name', f: { name: F.text(120, { req: 1, min: 2 }), graduation: F.text(80), specialty: F.text(120), bio: F.text(8000), experience_years: F.int(0, 100), extra_info: F.text(3000), photo_url: F.img(), sort_order: F.int(-1000, 1000, 0), nickname: F.text(80), phone: F.text(30), whatsapp: F.text(30), show_contact: F.bool(), is_published: F.bool() },
    async onDelete(c, x) { await unlinkTeacher(c.env, x.id); } },
  pages: { perm: 'content.write', slugFrom: 'title', f: { slug: F.slug(), title: F.text(160, { req: 1, min: 2 }), content: F.text(100000), seo_title: F.text(160), seo_description: F.text(300), is_published: F.bool() } },
  albums: { perm: 'gallery.write', slugFrom: 'title', kids: { images: [] }, f: { title: F.text(160, { req: 1, min: 2 }), category: F.enm(['evento', 'treino', 'roda', 'apresentacao', 'historico', 'outro'], 'outro'), description: F.text(3000), cover_image_url: F.img(), is_published: F.bool() } },
  classes: { perm: 'classes.write', kids: { schedules: [] }, f: { name: F.text(120, { req: 1, min: 2 }), description: F.text(5000), beginner_info: F.text(3000), student_info: F.text(3000), how_to_join: F.text(3000), location: F.text(200),
    unit_id: F.int(1, 1e9), age_group: F.text(60), level: F.text(60), modality: F.text(80), capacity: F.int(1, 1000), teacher_ids: F.ids(), is_published: F.bool() },
    async check(c, d) {
      if (d.unit_id != null && !find(await col(c.env, 'units'), d.unit_id)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'unit_id', message: 'Unidade inexistente' }]);
      if (d.teacher_ids?.length) { const t = (await col(c.env, 'teachers')).items; if (d.teacher_ids.some((i) => !t.some((x) => x.id === i))) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'teacher_ids', message: 'Professor inexistente' }]); }
    } },
  graduations: { perm: 'graduations.write', readPerm: 'students.read', order: (a, b) => a.position - b.position || a.name.localeCompare(b.name),
    f: { name: F.text(80, { req: 1, min: 2 }), position: F.int(0, 1000, 0), color: F.text(30), description: F.text(1000), is_published: F.bool() },
    async onDelete(c, x) {
      const n = (await col(c.env, 'students')).items.filter((st) => st.graduation_id === x.id || st.history.some((h) => h.graduation_id === x.id)).length;
      if (n) throw new HttpErr(409, `Esta graduação consta no histórico de ${n} aluno(s). Desative-a em vez de excluir.`);
    } },
  students: { perm: 'students.write', readPerm: 'students.read', noPublish: true, noDelete: true, kids: { history: [] }, order: (a, b) => a.name.localeCompare(b.name),
    f: { name: F.text(120, { req: 1, min: 2 }), nickname: F.text(80), phone: F.text(30), birth_date: F.date(), entry_date: F.date(), graduation_id: F.int(1, 1e9),
      guardian_name: F.text(120), guardian_phone: F.text(30), notes: F.text(3000), photo_url: F.img() },
    redact(c, r) { if (PERMS[c.user.role].includes('students.write')) return r; const { phone, birth_date, guardian_name, guardian_phone, notes, history, user_id, ...rest } = r; return rest; },
    async viewOne(c, r) { if (!r.user_id) return r; return { ...r, access_email: find(await col(c.env, 'users'), r.user_id)?.email || null }; },
    onCreate(c, rec) {
      const day = rec.entry_date || today(), mk = (o) => ({ id: hex(6), note: null, visible: true, by: c.user.name, created_at: iso(), date: day, ...o });
      rec.status = 'ativo'; rec.history = [mk({ type: 'entrada', title: 'Entrada no grupo' })];
      if (rec.graduation_id) rec.history.push(mk({ type: 'graduacao', title: 'Graduação inicial', graduation_id: rec.graduation_id }));
    },
    async check(c, d, x) {
      if (d.graduation_id != null) {
        if (!find(await col(c.env, 'graduations'), d.graduation_id)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'graduation_id', message: 'Graduação inexistente' }]);
        if (x && d.graduation_id !== x.graduation_id) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'graduation_id', message: 'Para mudar a graduação use "Registrar graduação"' }]);
      }
      const name = d.name ?? x?.name; if (!name || c.url.searchParams.get('force') === '1') return;
      const norm = (v) => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(), birth = d.birth_date ?? x?.birth_date ?? null;
      const dup = (await col(c.env, 'students')).items.find((y) => (!x || y.id !== x.id) && norm(y.name) === norm(name) && !(birth && y.birth_date && birth !== y.birth_date));
      if (dup) throw new HttpErr(409, `Já existe um aluno chamado "${dup.name}" (cadastro nº ${dup.id}). Se for outra pessoa, confirme para cadastrar mesmo assim.`, { duplicate: { id: dup.id, name: dup.name } });
    } },
  units: { perm: 'units.write', slugFrom: 'name', kids: { images: [] }, f: { name: F.text(160, { req: 1, min: 2 }), type: F.enm(['sede', 'nucleo'], 'nucleo'), description: F.text(5000), image_url: F.img(),
    address: F.text(200), neighborhood: F.text(100), city: F.text(100), state: F.text(40), cep: F.text(10), reference: F.text(200), latitude: F.num(-90, 90), longitude: F.num(-180, 180),
    phone: F.text(30), whatsapp: F.text(30), responsible_id: F.int(1, 1e9), founded_at: F.date(), is_published: F.bool() },
    async check(c, d, x) {
      if (d.responsible_id != null && !find(await col(c.env, 'teachers'), d.responsible_id)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'responsible_id', message: 'Responsável inexistente' }]);
      if (d.type === 'sede') { const o = (await col(c.env, 'units')).items.find((y) => y.type === 'sede' && (!x || y.id !== x.id)); if (o) throw new HttpErr(409, `Já existe uma sede principal (${o.name}). Mude o tipo dela para núcleo antes.`); }
    },
    async onDelete(c, x) {
      const cc = await col(c.env, 'classes'), mine = cc.items.filter((k) => k.unit_id === x.id);
      if (mine.length && c.url.searchParams.get('force') !== '1') throw new HttpErr(409, 'Esta unidade tem turmas e horários vinculados.', { classes: mine.length, schedules: mine.reduce((n, k) => n + k.schedules.length, 0) });
      if (mine.length) { cc.items = cc.items.filter((k) => k.unit_id !== x.id); await save(c.env, 'classes', cc); }
    } },
};
const SETTING_KEYS = ['group_name', 'tagline', 'city', 'whatsapp', 'instagram', 'address', 'map_embed_url', 'emblem_url', 'seo_title', 'seo_description'];
const DEFAULT_SETTINGS = { group_name: 'Grupo Nação Mandingueira', tagline: 'Capoeira, tradição e comunidade em Fortaleza, Ceará.', city: 'Fortaleza, Ceará, Brasil', whatsapp: '', instagram: '', address: '', map_embed_url: '', emblem_url: '', seo_title: 'Grupo Nação Mandingueira — Capoeira em Fortaleza, Ceará', seo_description: 'Site oficial do Grupo Nação Mandingueira, grupo de capoeira de Fortaleza, Ceará.' };

// ---------- armazenamento (KV com JSON) ----------
const col = async (env, n) => (await env.DB.get('c:' + n, 'json')) || { seq: 0, items: [] };
const save = (env, n, c) => env.DB.put('c:' + n, JSON.stringify(c));
async function audit(c, action, entity, id) {
  const a = (await c.env.DB.get('audit', 'json')) || [];
  a.unshift({ action, entity, entity_id: String(id ?? ''), name: c.user?.name || 'Sistema', created_at: iso() });
  await c.env.DB.put('audit', JSON.stringify(a.slice(0, 200)));
}
const find = (cl, key) => cl.items.find((x) => (/^\d+$/.test(String(key)) ? x.id === Number(key) : x.slug === key));
const uniq = (items, base) => { let s = slugify(base); while (items.some((x) => x.slug === s)) s = `${slugify(base).slice(0, 90)}-${hex(2)}`; return s; };
const UP = /^\/uploads\/([a-f0-9]{32}\.(jpg|png|webp))$/;
const purge = (env, urls) => Promise.all(urls.map((u) => UP.exec(u || '')).filter(Boolean).map((m) => env.DB.delete('up:' + m[1])));
const urlsOf = (it) => [it.cover_image_url, it.photo_url, it.image_url, ...(it.images || []).map((i) => i.image_url)];

// ---------- roteador ----------
const routes = [];
const route = (method, pattern, handler, opts = {}) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler, ...opts });
const reply = (c, data, status = 200, extra = {}) => new Response(status === 204 ? null : JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...c.cors, ...extra } });
const body = async (c, max = 300000) => {
  if (Number(c.req.headers.get('content-length') || 0) > max) throw new HttpErr(413, 'Conteúdo grande demais.');
  try { return await c.req.json(); } catch { throw new HttpErr(400, 'JSON inválido.'); }
};
const pub = (items) => items.filter((x) => x.is_published);
const today = () => new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10); // Fortaleza (UTC-3)

route('GET', '/api/health', (c) => reply(c, { ok: true }));
route('GET', '/api/status', async (c) => reply(c, { needsSetup: (await col(c.env, 'users')).items.length === 0, needsKey: Boolean(c.env.SETUP_KEY) }));
route('GET', '/api/settings', async (c) => reply(c, { data: { ...DEFAULT_SETTINGS, ...((await c.env.DB.get('settings', 'json')) || {}) } }));
route('GET', '/api/events', async (c) => {
  let l = pub((await col(c.env, 'events')).items); const w = c.url.searchParams.get('when');
  if (w === 'upcoming') l = l.filter((e) => e.event_date >= today()).sort((a, b) => (a.event_date + (a.start_time || '')).localeCompare(b.event_date + (b.start_time || '')));
  else { if (w === 'past') l = l.filter((e) => e.event_date < today()); l.sort((a, b) => b.event_date.localeCompare(a.event_date)); }
  return reply(c, { data: l });
});
route('GET', '/api/events/:key', async (c) => { const e = find(await col(c.env, 'events'), c.params.key); if (!e?.is_published) throw new HttpErr(404, 'Não encontrado.'); return reply(c, { data: e }); });
route('GET', '/api/teachers', async (c) => reply(c, { data: pub((await col(c.env, 'teachers')).items).map(pubTeacher).sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name)) }));
route('GET', '/api/pages/:key', async (c) => { const p = find(await col(c.env, 'pages'), c.params.key); if (!p?.is_published) throw new HttpErr(404, 'Não encontrado.'); return reply(c, { data: p }); });
route('GET', '/api/classes', async (c) => reply(c, { data: pub((await col(c.env, 'classes')).items).map((x) => ({ ...x, schedules: [...x.schedules].sort((a, b) => a.weekday - b.weekday || a.start_time.localeCompare(b.start_time)) })) }));
route('GET', '/api/gallery/albums', async (c) => reply(c, { data: pub((await col(c.env, 'albums')).items).map(({ images, ...a }) => a) }));
route('GET', '/api/gallery/albums/:key', async (c) => { const a = find(await col(c.env, 'albums'), c.params.key); if (!a?.is_published) throw new HttpErr(404, 'Não encontrado.'); return reply(c, { data: a }); });

const DIAS = ['', 'domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
const OPT_DEFAULT = { age_groups: ['Infantil', 'Juvenil', 'Adulto', 'Todas as idades'], levels: ['Iniciante', 'Intermediário', 'Avançado', 'Todos os níveis'] };
const pubTeacher = (t) => { const { phone, whatsapp, show_contact, ...r } = t; return show_contact ? { ...r, phone, whatsapp, show_contact } : r; };
const miniTeacher = (t) => ({ id: t.id, name: t.name, nickname: t.nickname || null, graduation: t.graduation || null, photo_url: t.photo_url || null, ...(t.show_contact ? { phone: t.phone || null, whatsapp: t.whatsapp || null } : {}) });
const byDay = (a, b) => ((a.weekday + 5) % 7) - ((b.weekday + 5) % 7) || a.start_time.localeCompare(b.start_time); // segunda primeiro
async function unlinkTeacher(env, id) {
  const cc = await col(env, 'classes'); let ch = false;
  for (const k of cc.items) if ((k.teacher_ids || []).includes(id)) { k.teacher_ids = k.teacher_ids.filter((i) => i !== id); ch = true; }
  if (ch) await save(env, 'classes', cc);
  const uu = await col(env, 'units'); ch = false;
  for (const u of uu.items) if (u.responsible_id === id) { u.responsible_id = null; ch = true; }
  if (ch) await save(env, 'units', uu);
}
function unitView(u, cc, teachers, full) {
  const classes = cc.items.filter((k) => k.unit_id === u.id && k.is_published).map((k) => ({ id: k.id, name: k.name, description: k.description, age_group: k.age_group ?? null, level: k.level ?? null, modality: k.modality ?? null, capacity: k.capacity ?? null,
    teachers: (k.teacher_ids || []).map((i) => teachers.find((t) => t.id === i)).filter(Boolean).map(miniTeacher),
    schedules: k.schedules.filter((s) => s.is_active !== false).sort(byDay).map(({ id, weekday, start_time, end_time, notes }) => ({ id, weekday, start_time, end_time, notes: notes || null })) }));
  const { images, responsible_id, ...rest } = u, resp = teachers.find((t) => t.id === responsible_id);
  return { ...rest, responsible: resp ? miniTeacher(resp) : null, classes, ...(full ? { images } : {}) };
}
async function unitsData(env) {
  const [uu, cc, tt] = await Promise.all(['units', 'classes', 'teachers'].map((n) => col(env, n)));
  return { uu, cc, teachers: tt.items.filter((t) => t.is_published) };
}
route('GET', '/api/units', async (c) => {
  const { uu, cc, teachers } = await unitsData(c.env);
  const list = uu.items.filter((u) => u.is_published).sort((a, b) => (b.type === 'sede') - (a.type === 'sede') || a.name.localeCompare(b.name)).map((u) => unitView(u, cc, teachers, false));
  return reply(c, { data: list });
});
route('GET', '/api/units/:key', async (c) => {
  const { uu, cc, teachers } = await unitsData(c.env), u = find(uu, c.params.key);
  if (!u?.is_published) throw new HttpErr(404, 'Unidade não encontrada.');
  return reply(c, { data: unitView(u, cc, teachers, true) });
});
route('GET', '/api/options', async (c) => reply(c, { data: { ...OPT_DEFAULT, ...((await c.env.DB.get('options', 'json')) || {}) } }));
route('PUT', '/api/admin/options', async (c) => {
  const d = await body(c), out = {};
  for (const k of ['age_groups', 'levels']) {
    if (!Array.isArray(d[k]) || !d[k].length || d[k].length > 20) throw new HttpErr(422, 'Dados inválidos.', [{ field: k, message: 'Informe de 1 a 20 itens' }]);
    out[k] = [...new Set(d[k].map((x) => strip(String(x)).slice(0, 40)).filter(Boolean))];
    if (!out[k].length) throw new HttpErr(422, 'Dados inválidos.', [{ field: k, message: 'Informe ao menos um item' }]);
  }
  await c.env.DB.put('options', JSON.stringify(out)); await audit(c, 'options.update', 'options', null);
  return reply(c, { message: 'Categorias salvas.' });
}, { perm: 'units.write' });

route('POST', '/api/contact', async (c) => {
  const d = await body(c);
  if (d.website) return reply(c, { message: 'Mensagem enviada.' }, 201); // armadilha para robôs
  const rk = 'rl:c:' + c.ip, n = Number(await c.env.DB.get(rk)) || 0;
  if (n >= 5) throw new HttpErr(429, 'Muitas mensagens. Tente novamente mais tarde.');
  const v = validate({ name: F.text(120, { req: 1, min: 2 }), email: F.text(190, { req: 1 }), phone: F.text(30), message: F.text(3000, { req: 1, min: 10 }) }, d, false);
  if (!EMAIL.test(v.email)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'email', message: 'E-mail inválido' }]);
  const cl = await col(c.env, 'messages');
  cl.items.unshift({ id: ++cl.seq, ...v, status: 'nova', created_at: iso() }); cl.items = cl.items.slice(0, 500);
  await save(c.env, 'messages', cl); await c.env.DB.put(rk, String(n + 1), { expirationTtl: 3600 });
  return reply(c, { message: 'Mensagem enviada. Obrigado pelo contato!' }, 201);
});

// ---------- login ----------
const newUser = async (v, role) => ({ name: v.name, email: v.email, hash: await hashPw(v.password), role, status: 'ativo', pv: 0, created_at: iso() });
route('POST', '/api/setup', async (c) => {
  const d = await body(c), cl = await col(c.env, 'users');
  if (cl.items.length) throw new HttpErr(403, 'A configuração inicial já foi feita.');
  if (c.env.SETUP_KEY && !same(d.setupKey || '', c.env.SETUP_KEY)) throw new HttpErr(403, 'Código de instalação incorreto.');
  const v = validate({ name: F.text(120, { req: 1, min: 2 }), email: F.text(190, { req: 1 }) }, d, false);
  if (!EMAIL.test(v.email)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'email', message: 'E-mail inválido' }]);
  checkPassword(d.password);
  cl.items.push({ id: ++cl.seq, ...(await newUser({ ...v, email: v.email.toLowerCase(), password: d.password }, 'superadministrador')) });
  await save(c.env, 'users', cl); await secretOf(c.env);
  return reply(c, { message: 'Administrador criado. Faça login.' }, 201);
});
route('POST', '/api/auth/login', async (c) => {
  const d = await body(c), email = String(d.email || '').trim().toLowerCase(), rk = `rl:l:${c.ip}:${email}`.slice(0, 200);
  if ((Number(await c.env.DB.get(rk)) || 0) >= 8) throw new HttpErr(429, 'Muitas tentativas. Aguarde alguns minutos.');
  const u = (await col(c.env, 'users')).items.find((x) => x.email === email);
  const ok = u ? await checkPw(String(d.password || ''), u.hash) : (await hashPw('x'), false);
  if (!ok) { await c.env.DB.put(rk, String((Number(await c.env.DB.get(rk)) || 0) + 1), { expirationTtl: 900 }); throw new HttpErr(401, 'E-mail ou senha incorretos.'); }
  if (u.status !== 'ativo') throw new HttpErr(403, 'Conta suspensa.');
  await c.env.DB.delete(rk);
  const token = await signToken({ sub: u.id, pv: u.pv, exp: Math.floor(Date.now() / 1000) + 7 * 86400 }, (await secretOf(c.env)));
  return reply(c, { token });
});
route('GET', '/api/auth/me', (c) => reply(c, { user: me(c.user) }), { auth: 1 });
const me = (u) => ({ id: u.id, name: u.name, email: u.email, roles: [u.role], permissions: PERMS[u.role] });
route('POST', '/api/auth/change-password', async (c) => {
  const d = await body(c); checkPassword(d.newPassword);
  const cl = await col(c.env, 'users'), u = find(cl, c.user.id);
  if (!(await checkPw(String(d.currentPassword || ''), u.hash))) throw new HttpErr(401, 'Senha atual incorreta.');
  u.hash = await hashPw(d.newPassword); u.pv++; await save(c.env, 'users', cl);
  const token = await signToken({ sub: u.id, pv: u.pv, exp: Math.floor(Date.now() / 1000) + 7 * 86400 }, (await secretOf(c.env)));
  return reply(c, { message: 'Senha alterada. Outras sessões foram encerradas.', token });
}, { auth: 1 });

// ---------- CRUD administrativo ----------
for (const [name, S] of Object.entries(SPEC)) {
  const base = `/api/admin/${name}`, opt = { perm: S.perm }, optR = { perm: S.readPerm || S.perm }, red = (c, r) => (S.redact ? S.redact(c, r) : r);
  route('GET', base, async (c) => reply(c, { data: (S.order ? (await col(c.env, name)).items.slice().sort(S.order) : (await col(c.env, name)).items.slice().reverse()).map((r) => red(c, r)) }), optR);
  route('GET', `${base}/:id`, async (c) => { const x = find(await col(c.env, name), c.params.id); if (!x) throw new HttpErr(404, 'Não encontrado.'); return reply(c, { data: S.viewOne ? await S.viewOne(c, red(c, x)) : red(c, x) }); }, optR);
  route('POST', base, async (c) => {
    const d = validate(S.f, await body(c), false), cl = await col(c.env, name), now = iso();
    if (S.check) await S.check(c, d, null);
    const rec = { id: ++cl.seq, ...d, ...JSON.parse(JSON.stringify(S.kids || {})), created_at: now, updated_at: now };
    if (S.onCreate) S.onCreate(c, rec);
    if (name === 'pages' && d.slug && cl.items.some((x) => x.slug === d.slug)) throw new HttpErr(409, 'Já existe uma página com esse endereço.');
    if (S.slugFrom) rec.slug = d.slug || uniq(cl.items, d[S.slugFrom]);
    cl.items.push(rec); await save(c.env, name, cl); await audit(c, `${name}.create`, name, rec.id);
    return reply(c, { data: rec }, 201);
  }, opt);
  route('PUT', `${base}/:id`, async (c) => {
    const d = validate(S.f, await body(c), true), cl = await col(c.env, name), x = find(cl, c.params.id);
    if (!x) throw new HttpErr(404, 'Não encontrado.');
    if (S.check) await S.check(c, d, x);
    if (d.slug === null) delete d.slug;
    if (d.slug && cl.items.some((y) => y.slug === d.slug && y.id !== x.id)) throw new HttpErr(409, 'Já existe um item com esse endereço.');
    Object.assign(x, d, { updated_at: iso() }); await save(c.env, name, cl); await audit(c, `${name}.update`, name, x.id);
    return reply(c, { data: x });
  }, opt);
  if (!S.noPublish) route('PATCH', `${base}/:id/publish`, async (c) => {
    const d = await body(c), cl = await col(c.env, name), x = find(cl, c.params.id);
    if (!x) throw new HttpErr(404, 'Não encontrado.');
    x.is_published = d.is_published === true; await save(c.env, name, cl); await audit(c, `${name}.${x.is_published ? 'publish' : 'unpublish'}`, name, x.id);
    return reply(c, { data: x });
  }, opt);
  if (!S.noDelete) route('DELETE', `${base}/:id`, async (c) => {
    const cl = await col(c.env, name), x = find(cl, c.params.id);
    if (!x) throw new HttpErr(404, 'Não encontrado.');
    if (S.onDelete) await S.onDelete(c, x);
    cl.items = cl.items.filter((y) => y !== x); await save(c.env, name, cl); await purge(c.env, urlsOf(x)); await audit(c, `${name}.delete`, name, x.id);
    return reply(c, null, 204);
  }, opt);
}
// fotos de eventos/álbuns e horários das aulas
for (const [parent, perm, kids, del, textKey] of [['events', 'events.write', 'images', 'event_images', 'caption'], ['albums', 'gallery.write', 'images', 'gallery_images', 'description'], ['units', 'units.write', 'images', 'unit_images', 'description']]) {
  route('POST', `/api/admin/${parent}/:id/images`, async (c) => {
    const d = validate({ image_url: { ...F.img(), req: 1 }, [textKey]: F.text(300), sort_order: F.int(-1000, 1000, 0) }, await body(c), false);
    if (!UP.test(d.image_url)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'image_url', message: 'Envie a foto pelo painel' }]);
    const cl = await col(c.env, parent), x = find(cl, c.params.id);
    if (!x) throw new HttpErr(404, 'Não encontrado.');
    const im = { id: hex(6), ...d }; x[kids].push(im); await save(c.env, parent, cl); await audit(c, `${del}.create`, del, im.id);
    return reply(c, { id: im.id }, 201);
  }, { perm });
  route('DELETE', `/api/admin/${del}/:id`, async (c) => {
    const cl = await col(c.env, parent);
    for (const x of cl.items) { const im = x[kids].find((i) => i.id === c.params.id); if (im) { x[kids] = x[kids].filter((i) => i !== im); await save(c.env, parent, cl); await purge(c.env, [im.image_url]); await audit(c, `${del}.delete`, del, im.id); return reply(c, null, 204); } }
    throw new HttpErr(404, 'Imagem não encontrada.');
  }, { perm });
}
const SCH = { weekday: F.int(1, 7), start_time: { ...F.time(), req: 1 }, end_time: { ...F.time(), req: 1 }, location: F.text(200), notes: F.text(300), is_active: F.bool() };
const okSch = (d) => { if (d.weekday == null) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'weekday', message: 'Escolha o dia' }]); if (d.end_time <= d.start_time) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'end_time', message: 'O fim deve ser depois do início' }]); };
// Conflitos geram apenas AVISO (mesma turma, mesma unidade ou mesmo professor no mesmo horário).
function conflictsOf(classes, k, s) {
  const out = [];
  for (const o of classes) for (const t of o.schedules) {
    if (t.id === s.id || t.is_active === false || t.weekday !== s.weekday || !(s.start_time < t.end_time && t.start_time < s.end_time)) continue;
    const teacher = (k.teacher_ids || []).some((i) => (o.teacher_ids || []).includes(i)), unit = k.unit_id != null && o.unit_id === k.unit_id;
    if (teacher || unit || o.id === k.id) out.push(`Conflito com «${o.name}» (${DIAS[t.weekday]}, ${t.start_time}–${t.end_time}): ${teacher ? 'mesmo professor' : unit ? 'mesma unidade' : 'mesma turma'}`);
  }
  return out;
}
const findSch = (cc, id) => { for (const k of cc.items) { const s = k.schedules.find((x) => x.id === id); if (s) return [k, s]; } return [null, null]; };
route('POST', '/api/admin/classes/:id/schedules', async (c) => {
  const b = await body(c), d = validate(SCH, b, false); if (!('is_active' in b)) d.is_active = true; okSch(d);
  const cl = await col(c.env, 'classes'), x = find(cl, c.params.id);
  if (!x) throw new HttpErr(404, 'Não encontrado.');
  const s = { id: hex(6), ...d }; x.schedules.push(s); await save(c.env, 'classes', cl); await audit(c, 'schedule.create', 'class_schedule', s.id);
  return reply(c, { id: s.id, warnings: conflictsOf(cl.items, x, s) }, 201);
}, { perm: 'classes.write' });
route('PUT', '/api/admin/schedules/:id', async (c) => {
  const d = validate(SCH, await body(c), true), cl = await col(c.env, 'classes'), [k, s] = findSch(cl, c.params.id);
  if (!s) throw new HttpErr(404, 'Horário não encontrado.');
  const m = { ...s, ...d }; okSch(m); Object.assign(s, d); await save(c.env, 'classes', cl); await audit(c, 'schedule.update', 'class_schedule', s.id);
  return reply(c, { message: 'Horário atualizado.', warnings: conflictsOf(cl.items, k, s) });
}, { perm: 'classes.write' });
route('POST', '/api/admin/schedules/:id/duplicate', async (c) => {
  const b = await body(c).catch(() => ({})), cl = await col(c.env, 'classes'), [k, s] = findSch(cl, c.params.id);
  if (!s) throw new HttpErr(404, 'Horário não encontrado.');
  const day = validate({ weekday: F.int(1, 7) }, { weekday: b.weekday ?? s.weekday }, false).weekday;
  const n = { ...s, id: hex(6), weekday: day }; k.schedules.push(n); await save(c.env, 'classes', cl); await audit(c, 'schedule.duplicate', 'class_schedule', n.id);
  return reply(c, { id: n.id, warnings: conflictsOf(cl.items, k, n) }, 201);
}, { perm: 'classes.write' });
route('GET', '/api/admin/schedules', async (c) => {
  const [cl, uu, tt] = await Promise.all(['classes', 'units', 'teachers'].map((n) => col(c.env, n))), rows = [];
  for (const k of cl.items) for (const s of k.schedules) rows.push({ ...s, class_id: k.id, class_name: k.name, unit_id: k.unit_id ?? null, unit_name: uu.items.find((u) => u.id === k.unit_id)?.name || null,
    teachers: (k.teacher_ids || []).map((i) => tt.items.find((t) => t.id === i)?.name).filter(Boolean), warnings: conflictsOf(cl.items, k, s) });
  return reply(c, { data: rows });
}, { perm: 'classes.write' });
route('DELETE', '/api/admin/schedules/:id', async (c) => {
  const cl = await col(c.env, 'classes'), [k, s] = findSch(cl, c.params.id);
  if (!s) throw new HttpErr(404, 'Horário não encontrado.');
  k.schedules = k.schedules.filter((x) => x !== s); await save(c.env, 'classes', cl); await audit(c, 'schedule.delete', 'class_schedule', s.id);
  return reply(c, null, 204);
}, { perm: 'classes.write' });


// ---------- alunos: graduação, histórico, situação e acesso ----------
const HIST_TYPES = ['evento', 'troca_corda', 'participacao', 'observacao'];
const histEntry = (c, o) => ({ id: hex(6), note: null, visible: true, by: c.user.name, created_at: iso(), ...o });
async function studentOf(c) { const cl = await col(c.env, 'students'), x = find(cl, c.params.id); if (!x) throw new HttpErr(404, 'Aluno não encontrado.'); return [cl, x]; }
route('POST', '/api/admin/students/:id/graduate', async (c) => {
  const d = validate({ graduation_id: { ...F.int(1, 1e9), req: 1 }, date: F.date(), note: F.text(500) }, await body(c), false), [cl, x] = await studentOf(c);
  const gr = find(await col(c.env, 'graduations'), d.graduation_id);
  if (!gr) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'graduation_id', message: 'Graduação inexistente' }]);
  if (gr.is_published === false) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'graduation_id', message: 'Graduação desativada' }]);
  const from = find(await col(c.env, 'graduations'), x.graduation_id)?.name;
  x.graduation_id = gr.id; x.history.push(histEntry(c, { type: 'graduacao', date: d.date || today(), title: from ? `${from} → ${gr.name}` : gr.name, graduation_id: gr.id, note: d.note }));
  x.updated_at = iso(); await save(c.env, 'students', cl); await audit(c, 'student.graduate', 'student', x.id);
  return reply(c, { data: x });
}, { perm: 'students.write' });
route('POST', '/api/admin/students/:id/history', async (c) => {
  const b = await body(c), d = validate({ type: F.enm(HIST_TYPES, 'observacao'), date: F.date(), title: F.text(120, { req: 1, min: 2 }), note: F.text(1000) }, b, false), [cl, x] = await studentOf(c);
  const visible = 'visible' in b ? b.visible === true : d.type !== 'observacao';
  x.history.push(histEntry(c, { type: d.type, date: d.date || today(), title: d.title, note: d.note, visible }));
  x.updated_at = iso(); await save(c.env, 'students', cl); await audit(c, 'student.history', 'student', x.id);
  return reply(c, { data: x }, 201);
}, { perm: 'students.write' });
route('PATCH', '/api/admin/students/:id/status', async (c) => {
  const d = validate({ status: { ...F.enm(['ativo', 'inativo'], null), req: 1 }, note: F.text(500) }, await body(c), false), [cl, x] = await studentOf(c);
  if (x.status === d.status) return reply(c, { data: x });
  x.status = d.status; x.history.push(histEntry(c, { type: 'situacao', date: today(), title: d.status === 'ativo' ? 'Aluno reativado' : 'Aluno desativado', note: d.note, visible: false }));
  x.updated_at = iso(); await save(c.env, 'students', cl); await audit(c, d.status === 'ativo' ? 'student.reactivate' : 'student.deactivate', 'student', x.id);
  return reply(c, { data: x });
}, { perm: 'students.write' });
route('POST', '/api/admin/students/:id/access', async (c) => {
  const d = await body(c), [cl, x] = await studentOf(c);
  if (x.user_id) throw new HttpErr(409, 'Este aluno já tem acesso.');
  const email = String(d.email || '').trim().toLowerCase();
  if (!EMAIL.test(email)) throw new HttpErr(422, 'Dados inválidos.', [{ field: 'email', message: 'E-mail inválido' }]);
  checkPassword(d.password);
  const us = await col(c.env, 'users');
  if (us.items.some((u) => u.email === email)) throw new HttpErr(409, 'Já existe uma conta com esse e-mail.');
  const u = { id: ++us.seq, ...(await newUser({ name: x.name, email, password: d.password }, 'aluno')), student_id: x.id };
  us.items.push(u); await save(c.env, 'users', us); x.user_id = u.id; await save(c.env, 'students', cl); await audit(c, 'student.access_create', 'student', x.id);
  return reply(c, { message: 'Acesso criado. Passe o e-mail e a senha ao aluno.' }, 201);
}, { perm: 'students.write' });
route('PUT', '/api/admin/students/:id/access', async (c) => {
  const d = await body(c), [, x] = await studentOf(c); checkPassword(d.password);
  const us = await col(c.env, 'users'), u = x.user_id && find(us, x.user_id);
  if (!u) throw new HttpErr(404, 'Este aluno ainda não tem acesso.');
  u.hash = await hashPw(d.password); u.pv++; await save(c.env, 'users', us); await audit(c, 'student.access_reset', 'student', x.id);
  return reply(c, { message: 'Senha alterada.' });
}, { perm: 'students.write' });
// área do aluno: cada aluno vê somente o próprio cadastro
route('GET', '/api/me/student', async (c) => {
  const x = (await col(c.env, 'students')).items.find((s) => s.user_id === c.user.id);
  if (!x) throw new HttpErr(404, 'Seu acesso ainda não está ligado a um cadastro de aluno. Fale com o grupo.');
  const grs = await col(c.env, 'graduations'), g = find(grs, x.graduation_id);
  return reply(c, { data: { name: x.name, nickname: x.nickname || null, photo_url: x.photo_url || null, phone: x.phone || null, birth_date: x.birth_date || null, entry_date: x.entry_date || null, status: x.status,
    graduation: g ? { name: g.name, color: g.color || null } : null,
    history: x.history.filter((h) => h.visible).sort((a, b) => b.date.localeCompare(a.date) || b.created_at.localeCompare(a.created_at)).map((h) => ({ type: h.type, date: h.date, title: h.title, note: h.note })) } });
}, { auth: 1 });

// ---------- upload ----------
function sniff(b) {
  if (b.length > 12 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return ['jpg', 'image/jpeg'];
  if (b.length > 12 && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((v, i) => b[i] === v)) return ['png', 'image/png'];
  if (b.length > 12 && String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP') return ['webp', 'image/webp'];
  return null;
}
route('POST', '/api/admin/uploads', async (c) => {
  let f; try { f = (await c.req.formData()).get('file'); } catch { throw new HttpErr(400, 'Envio inválido.'); }
  if (!f || typeof f === 'string') throw new HttpErr(400, 'Envie um arquivo no campo "file".');
  if (f.size > 1.5 * 1024 * 1024) throw new HttpErr(413, 'Imagem maior que 1,5 MB.');
  const buf = new Uint8Array(await f.arrayBuffer()), t = sniff(buf);
  if (!t) throw new HttpErr(415, 'Arquivo inválido. Envie JPG, PNG ou WebP.');
  const name = `${hex(16)}.${t[0]}`;
  await c.env.DB.put('up:' + name, buf, { metadata: { type: t[1] } }); await audit(c, 'upload.create', 'upload', name);
  return reply(c, { url: `/uploads/${name}` }, 201);
}, { anyPerm: ['events.write', 'gallery.write', 'teachers.write', 'settings.write'] });


// ---------- backup (exportar / restaurar) ----------
const toB64 = (buf) => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const COLS = new Set(['events', 'teachers', 'pages', 'albums', 'classes', 'units', 'messages', 'students', 'graduations']);
route('GET', '/api/admin/export', async (c) => {
  const items = [];
  for (const prefix of ['c:', 'settings', 'options', 'up:']) {
    let cursor;
    do {
      const r = await c.env.DB.list({ prefix, cursor });
      for (const { name } of r.keys) {
        if (name === 'c:users') continue;
        if (name.startsWith('up:')) { const { value, metadata } = await c.env.DB.getWithMetadata(name, 'arrayBuffer'); if (value) items.push({ k: name, b: toB64(value), m: metadata?.type }); }
        else { const v = await c.env.DB.get(name); if (v != null) items.push({ k: name, v }); }
      }
      cursor = r.list_complete ? null : r.cursor;
    } while (cursor);
  }
  await audit(c, 'backup.export', 'backup', null);
  return reply(c, { version: 1, created_at: iso(), items });
}, { perm: 'settings.write' });
route('POST', '/api/admin/import', async (c) => {
  const d = await body(c, 80e6);
  if (d.version !== 1 || !Array.isArray(d.items)) throw new HttpErr(422, 'Arquivo de backup inválido.');
  const jobs = [];
  for (const it of d.items) {
    const k = String(it.k || '');
    if (k === 'settings' || k === 'options') { JSON.parse(it.v); jobs.push(() => c.env.DB.put(k, it.v)); }
    else if (/^c:\w+$/.test(k) && COLS.has(k.slice(2))) { const j = JSON.parse(it.v); if (!Array.isArray(j.items) || typeof j.seq !== 'number') throw new HttpErr(422, 'Backup com dados inválidos.'); if (k === 'c:students') { j.items.forEach((st) => { delete st.user_id; }); it.v = JSON.stringify(j); } jobs.push(() => c.env.DB.put(k, it.v)); }
    else if (/^up:[a-f0-9]{32}\.(jpg|png|webp)$/.test(k)) {
      const bytes = Uint8Array.from(atob(it.b), (ch) => ch.charCodeAt(0)), t = sniff(bytes);
      if (!t) throw new HttpErr(422, 'Backup com imagem inválida.');
      jobs.push(() => c.env.DB.put(k, bytes, { metadata: { type: t[1] } }));
    } else throw new HttpErr(422, 'Backup com item não permitido.');
  }
  for (const j of jobs) await j();
  await audit(c, 'backup.import', 'backup', null);
  return reply(c, { message: `Backup restaurado (${jobs.length} itens).` });
}, { perm: 'settings.write' });

// ---------- mensagens, configurações, painel, usuários ----------
route('GET', '/api/admin/messages', async (c) => reply(c, { data: (await col(c.env, 'messages')).items }), { perm: 'messages.read' });
route('PATCH', '/api/admin/messages/:id', async (c) => {
  const d = await body(c); if (!['nova', 'lida', 'respondida', 'arquivada'].includes(d.status)) throw new HttpErr(422, 'Situação inválida.');
  const cl = await col(c.env, 'messages'), m = find(cl, c.params.id); if (!m) throw new HttpErr(404, 'Não encontrado.');
  m.status = d.status; await save(c.env, 'messages', cl); return reply(c, { message: 'Atualizada.' });
}, { perm: 'messages.read' });
route('DELETE', '/api/admin/messages/:id', async (c) => {
  const cl = await col(c.env, 'messages'); cl.items = cl.items.filter((m) => m.id !== Number(c.params.id)); await save(c.env, 'messages', cl); await audit(c, 'message.delete', 'message', c.params.id); return reply(c, null, 204);
}, { perm: 'messages.read' });
route('PUT', '/api/admin/settings', async (c) => {
  const d = await body(c), bad = Object.keys(d).filter((k) => !SETTING_KEYS.includes(k));
  if (bad.length) throw new HttpErr(422, `Chaves não permitidas: ${bad.join(', ')}`);
  const cur = (await c.env.DB.get('settings', 'json')) || {};
  for (const k of Object.keys(d)) cur[k] = strip(String(d[k]).slice(0, 2000));
  await c.env.DB.put('settings', JSON.stringify(cur)); await audit(c, 'settings.update', 'settings', null);
  return reply(c, { message: 'Configurações salvas.' });
}, { perm: 'settings.write' });
route('GET', '/api/admin/stats', async (c) => {
  const [us, ev, al, cm, un, cl, tc, sd] = await Promise.all(['users', 'events', 'albums', 'messages', 'units', 'classes', 'teachers', 'students'].map((n) => col(c.env, n)));
  const now = new Date(Date.now() - 3 * 3600e3), dow = now.getUTCDay() + 1, mins = now.getUTCHours() * 60 + now.getUTCMinutes(), up = [];
  for (const k of cl.items.filter((x) => x.is_published)) for (const s of k.schedules.filter((x) => x.is_active !== false)) {
    const [H, M] = s.start_time.split(':').map(Number); let delta = ((s.weekday - dow + 7) % 7) * 1440 + H * 60 + M - mins; if (delta < 0) delta += 7 * 1440;
    up.push({ delta, class_name: k.name, unit_name: un.items.find((u) => u.id === k.unit_id)?.name || null, weekday: s.weekday, start_time: s.start_time, end_time: s.end_time });
  }
  return reply(c, { data: { users: us.items.length, students: sd.items.filter((x) => x.status === 'ativo').length, students_total: sd.items.length, students_inactive: sd.items.filter((x) => x.status === 'inativo').length, events: ev.items.length,
    photos: [...ev.items, ...al.items, ...un.items].reduce((n, x) => n + x.images.length, 0), messages: cm.items.length, newMessages: cm.items.filter((m) => m.status === 'nova').length,
    units: un.items.length, nuclei_active: un.items.filter((u) => u.type === 'nucleo' && u.is_published).length, teachers: tc.items.length, classes: cl.items.length, schedules: cl.items.reduce((n, k) => n + k.schedules.length, 0),
    upcoming: up.sort((a, b) => a.delta - b.delta).slice(0, 5), recent: ((await c.env.DB.get('audit', 'json')) || []).slice(0, 15) } });
}, { anyPerm: ['users.read', 'messages.read'] });
route('GET', '/api/admin/audit', async (c) => reply(c, { data: (await c.env.DB.get('audit', 'json')) || [] }), { perm: 'audit.read' });

const pubUser = (u) => ({ id: u.id, name: u.name, email: u.email, status: u.status, roles: [u.role], created_at: u.created_at });
route('GET', '/api/admin/users', async (c) => reply(c, { data: (await col(c.env, 'users')).items.slice().reverse().map(pubUser) }), { perm: 'users.read' });
async function target(c, cl) {
  const t = find(cl, c.params.id);
  if (!t) throw new HttpErr(404, 'Usuário não encontrado.');
  if (t.id === c.user.id) throw new HttpErr(403, 'Você não pode fazer isso na própria conta.');
  if (LEVEL[t.role] >= LEVEL[c.user.role]) throw new HttpErr(403, 'Você não pode gerenciar um usuário de nível igual ou superior ao seu.');
  return t;
}
route('PUT', '/api/admin/users/:id/role', async (c) => {
  const d = await body(c), cl = await col(c.env, 'users'), t = await target(c, cl);
  if (!LEVEL[d.role]) throw new HttpErr(422, 'Permissão inválida.');
  if (LEVEL[d.role] >= LEVEL[c.user.role]) throw new HttpErr(403, 'Você não pode conceder um nível igual ou superior ao seu.');
  t.role = d.role; await save(c.env, 'users', cl); await audit(c, 'user.set_role', 'user', t.id); return reply(c, { message: 'Permissão alterada.' });
}, { perm: 'users.write' });
route('PATCH', '/api/admin/users/:id/status', async (c) => {
  const d = await body(c), cl = await col(c.env, 'users'), t = await target(c, cl);
  if (!['ativo', 'suspenso'].includes(d.status)) throw new HttpErr(422, 'Situação inválida.');
  t.status = d.status; await save(c.env, 'users', cl); await audit(c, d.status === 'ativo' ? 'user.reactivate' : 'user.suspend', 'user', t.id);
  return reply(c, { message: 'Situação alterada.' });
}, { perm: 'users.write' });
route('PUT', '/api/admin/users/:id/password', async (c) => {
  const d = await body(c), cl = await col(c.env, 'users'), t = await target(c, cl); checkPassword(d.password);
  t.hash = await hashPw(d.password); t.pv++; await save(c.env, 'users', cl); await audit(c, 'user.reset_password', 'user', t.id);
  return reply(c, { message: 'Senha alterada.' });
}, { perm: 'users.write' });
route('DELETE', '/api/admin/users/:id', async (c) => {
  const d = await body(c), cl = await col(c.env, 'users'), t = await target(c, cl);
  if (String(d.confirmEmail || '').trim().toLowerCase() !== t.email) throw new HttpErr(422, 'Digite o e-mail da conta para confirmar a exclusão.');
  cl.items = cl.items.filter((u) => u !== t); await save(c.env, 'users', cl); await audit(c, 'user.delete', 'user', t.id);
  return reply(c, null, 204);
}, { perm: 'users.delete' });

// ---------- entrada ----------
function corsHeaders(req, env) {
  const list = (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean), o = req.headers.get('Origin');
  return { 'Access-Control-Allow-Origin': !list.length ? '*' : list.includes(o) ? o : list[0], 'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'Access-Control-Max-Age': '86400', Vary: 'Origin' };
}
async function authenticate(c) {
  const m = /^Bearer (.+)$/.exec(c.req.headers.get('Authorization') || '');
  if (!m) return null;
  const p = await readToken(m[1], (await secretOf(c.env))).catch(() => null);
  const u = p && find(await col(c.env, 'users'), p.sub);
  return u && u.status === 'ativo' && u.pv === p.pv ? u : null;
}
export default {
  async fetch(req, env) {
    const url = new URL(req.url), c = { req, env, url, cors: corsHeaders(req, env), ip: req.headers.get('CF-Connecting-IP') || 'x', params: {} };
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: c.cors });
    try {
      if (!env.DB) throw new HttpErr(500, 'Servidor não configurado: ligue o KV com o nome DB.');
      const up = /^\/uploads\/([a-f0-9]{32}\.(jpg|png|webp))$/.exec(url.pathname);
      if (up && req.method === 'GET') {
        const { value, metadata } = await env.DB.getWithMetadata('up:' + up[1], 'arrayBuffer');
        if (!value) throw new HttpErr(404, 'Imagem não encontrada.');
        return new Response(value, { headers: { 'Content-Type': metadata?.type || 'application/octet-stream', 'Cache-Control': 'public, max-age=2592000, immutable', 'X-Content-Type-Options': 'nosniff', 'Cross-Origin-Resource-Policy': 'cross-origin', ...c.cors } });
      }
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname); if (!m) continue;
        c.params = { ...m.groups };
        if (r.auth || r.perm || r.anyPerm) {
          c.user = await authenticate(c);
          if (!c.user) throw new HttpErr(401, 'Faça login para continuar.');
          const perms = PERMS[c.user.role];
          if ((r.perm && !perms.includes(r.perm)) || (r.anyPerm && !r.anyPerm.some((p) => perms.includes(p)))) throw new HttpErr(403, 'Você não tem permissão para esta ação.');
        }
        return await r.handler(c);
      }
      throw new HttpErr(404, 'Rota não encontrada.');
    } catch (e) {
      if (e instanceof HttpErr) return reply(c, { error: e.message, fields: e.fields }, e.status);
      console.error(e); return reply(c, { error: 'Erro interno do servidor.' }, 500);
    }
  },
};

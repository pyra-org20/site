// Endereço da API.
//  'local'  = MODO TESTE: funciona já, sem servidor; os dados ficam só neste navegador.
//  'https://nacao-api.sereronildes6.workers.dev' = servidor de verdade (veja worker/GUIA-CLOUDFLARE.md).
window.APP_CONFIG = { API_URL: 'local' };
